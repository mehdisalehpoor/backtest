"use strict";

const sequelize = require("sequelize");

module.exports = {
  up: function (queryInterface, DataTypes) {
    return queryInterface.createTable("binance_futures_symbols", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
      },
      symbol: {
        type: DataTypes.STRING(30),
        unique: true,
        allowNull: false,
      },
      created_at: {
        allowNull: false,
        type: DataTypes.DATE,
        defaultValue: sequelize.NOW,
      },
      updated_at: {
        allowNull: true,
        type: "TIMESTAMP",
      },
      deleted_at: {
        type: DataTypes.DATE,
        type: "TIMESTAMP",
      },
    });
  },

  down: function (queryInterface, DataTypes) {
    return queryInterface.dropTable("binance_futures_symbols");
  },
};
