const axios = require("axios");

class TelegramBotService {
  static send(text, users = [], token = null) {
    const envToken = "6288646018:AAE_tQaLEOoyMmTKTCnmUgYq-RNvSqZInjs";
    if (!token && !envToken) {
      return false;
    } else if (!token) {
      token = envToken;
    }

    const users_db = {
      mohar9h: 89726967, // mohar9h
      adel: 5772242944,
      mehdi: 5478781512,
      test: 6840188974,
      hamed: 6665451308,
    };

    if (users.length === 0) {
      for (const user in users_db) {
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {}
      }
    } else {
      for (const user of users) {
        if (!users_db[user]) continue;
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {}
      }
    }
    return true;
  }

  static futuresSend(text, users = [], token = null) {
    var envToken = "6209318037:AAHRcFglo0_oR9BwcwRtNDZ1My9UiESSilU";

    if (!token && !envToken) {
      return false;
    } else if (!token) {
      token = envToken;
    }

    const users_db = {
      mohar9h: 89726967, // mohar9h
      adel: 5772242944,
      mehdi: 5478781512,
      test: 6840188974,
      hamed: 6665451308,
    };

    if (users.length === 0) {
      for (const user in users_db) {
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {
          console.error(exception);
        }
      }
    } else {
      for (const user of users) {
        if (!users_db[user]) continue;
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {}
      }
    }
    return true;
  }

  static futuresLogsSend(text, users = [], token = null) {
    var envToken = "5962281728:AAEEJaMg7e9hGOXcpRPoGrdprrlJVIohw-4";

    if (!token && !envToken) {
      return false;
    } else if (!token) {
      token = envToken;
    }

    const users_db = {
      mohar9h: 89726967, // mohar9h
      adel: 5772242944,
      mehdi: 5478781512,
      test: 6840188974,
      hamed: 6665451308,
    };

    if (users.length === 0) {
      for (const user in users_db) {
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {
          console.error(exception);
        }
      }
    } else {
      for (const user of users) {
        if (!users_db[user]) continue;
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {}
      }
    }
    return true;
  }

  static futuresSignalSend(text, users = [], token = null) {
    var envToken = "6029481337:AAFfhzJFgd955TNTurRInj5LVfG2nGmelCs";

    if (!token && !envToken) {
      return false;
    } else if (!token) {
      token = envToken;
    }

    const users_db = {
      mohar9h: 89726967, // mohar9h
      adel: 5772242944,
      mehdi: 5478781512,
      test: 6840188974,
      hamed: 6665451308,
    };
    if (users.length === 0) {
      for (const user in users_db) {
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {
          console.error(exception);
        }
      }
    } else {
      for (const user of users) {
        if (!users_db[user]) continue;
        const url = `https://api.telegram.org/bot${token}/sendMessage`;
        try {
          this.axiosPost(url, {
            chat_id: users_db[user],
            text: `[${process.env.APP_NAME}]\n===============\n${text}`,
          });
        } catch (exception) {}
      }
    }
    return true;
  }

  static axiosPost(url, params, format = "http") {
    axios
      .post(url, params, {
        headers:
          format === "json"
            ? {
                "Content-Type": "application/json",
                Accept: "application/json",
              }
            : {},
        timeout: 30000,
        httpsAgent:
          format === "json"
            ? undefined
            : new (require("https").Agent)({ rejectUnauthorized: false }),
      })
      .then((response) => {
        // Handle the response if needed
      })
      .catch((error) => {
        // Handle the error if needed
      });
  }

  static sendLogToUser(text, user, token = null) {
    const envToken = "7034416614:AAFB2RLNDU1lr-oOUyxT0_2umjUuuf35NgM";
    if (!token && !envToken) {
      return false;
    } else if (!token) {
      token = envToken;
    }

    const url = `https://api.telegram.org/bot${token}/sendMessage`;
    try {
      this.axiosPost(url, {
        chat_id: user.telegramId,
        text: `[${process.env.APP_NAME}]\n===============\n${text}`,
      });
    } catch (exception) {}

    return true;
  }
}

module.exports = TelegramBotService;
