const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const OrderModel = sequelize.define(
  "orders",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbol: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    side: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM(["NONE", "SOME", "ALL"]),
      defaultValue: "NONE",
      allowNull: false,
    },
    exit: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

module.exports = OrderModel;
