import express from "express";
import "dotenv/config";
import swaggerUi from "swagger-ui-express";
import swaggerDocument from "./app/Helpers/swagger.json";
import Handler from "./app/Exceptions/handler";
import { ErrorCode } from "./app/Exceptions/errorCode";
import dotenv from "dotenv";
import sequelize from "./config/database";
import cors from "cors";
import apiRouter from "./routes";

dotenv.config();

class ApiServer {
  constructor() {
    this.app = express();

    this.setupServer();
    this.connectToDatabse();
    this.initiatConfiguration();
    this.responseHandlerMiddleware();
    this.initiatRoutes();
    this.errorHandlerMiddleware();
  }

  // Setup and Run Server
  setupServer() {
    this.server = this.app.listen(process.env.API_PORT, () => {
      console.log(`server is Running on port ${process.env.API_PORT}`);
    });
    process.on("exit", (code) => {
      // perform some cleanup operations here
      console.log(`Node.js process exiting with code ${code}`);

      // close the server gracefully
      this.server.close(() => {
        console.log("Server closed");
      });
    });
  }

  //   Connect to Database
  connectToDatabse = async () => {
    sequelize
      .sync()
      .then((result) => {
        console.log("Connected to database");
      })
      .catch((error) => console.log(error));
  };

  initiatConfiguration() {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: false }));
    this.app.use(cors({ origin: "*" }));
  }

  // Register Response Handler
  responseHandlerMiddleware() {
    this.app.use((req, res, next) => {
      res.response = function (data) {
        res.json([data]);
      };
      next();
    });
  }

  //   Routes
  initiatRoutes() {
    this.app.use("/", apiRouter);

    this.app.use(
      "/api-docs",
      swaggerUi.serve,
      swaggerUi.setup(swaggerDocument)
    );
  }

  //   Middlewares
  errorHandlerMiddleware() {
    this.app.use((err, req, res, next) => {
      console.log(err);

      if (!(err instanceof Handler)) {
        err = new Handler(ErrorCode.INTERNAL_SERVER_ERROR);
      }

      res.status(err.getStatus()).json(err.toJSON());
    });
  }

}

module.exports = ApiServer;
