const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://www.hotcoin.com/",
        symbol: baseSymbol + "/" + quoteSymbol,
        exchange: "binance",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            const headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'en-US,en;q=0.9',
                'cache-control': 'max-age=0',
                'cookie': '_ga=GA1.1.1862808008.1719737684; tfstk=f6cECbvSrBdUjzkublNz0kGBJgVL1SKjEbZ7r40uRkqhO6soQDnONXNIdYkZqceQxuw7azobXUCWvBCuqm3m48LLVuqrV4DB5IOjJ2F8Z0-XGIwox-JEYMVuqUfgzr-tQdjmJ2FRWcotiz0dUQSMsXVoq52gurPlZ_2lIFz4P7f3E6XGjlUuZumuE52grzClZkfksjebqo1auJY0HXtVFtpYso03x0iSsi2hp2rNZ_cZQWr04l5lZfzEWnoqJsJ7mxEQhuoM16PrSzoQfmAc_52qH4arYB53If0nZWGW_F3TTkPitx7lZVPUx8cLpM-amX3iM526iEui6DgK_4_kZPibj2h3aIYYTWq3_PhWX6qrIYcQp7IHcJ3oQczUigyd2PVgJbHFqTy3WPrX7FbrmTu2mWcuoTB8pAUaceLdeTe3WPrX7FWReJHT7oTpJ; qimo_xstKeywords_f86dc210-6f8c-11ec-a72f-8754094e991d=; href=https%3A%2F%2Fwww.hotcoin.com%2F; accessId=f86dc210-6f8c-11ec-a72f-8754094e991d; acw_sc__v2=6686912036eac143c238957e66a2d60b4d9a7929; qimo_seosource_f86dc210-6f8c-11ec-a72f-8754094e991d=%E7%AB%99%E5%86%85; qimo_seokeywords_f86dc210-6f8c-11ec-a72f-8754094e991d=; _ga_0EXKQE7BYB=GS1.1.1720095007.3.1.1720096643.0.0.0; pageViewNum=4; acw_tc=0bc1a18217200968174114879e7682cf00157e6bf7bb1e0289ff0f48b66b4b; acw_sc__v2=66869831ff4c95e56958915fbf282dac3b3bd199; ssxmod_itna=QqGxgQiQD=BDBDl4Yq0Pb1KTGkImqDkYBb7DfoR07qGXmWGRDCqAPGfDI3fz3hG4hovYCSWd+q9C8iAFN46BPTvCBBmidGoW4B3DE=kGKoD44GTDt4DTD34DYDigQDLDmeD+jHKDdXLvyzXxiWDW5DhxDODY5DXZKD==25eY5xDG5YG0iTDmRkBZc+2D07DiyDBORkD75Dux0HvDkpDDHjubGsBpfo19b8=9YDvxDk2lI1ui8PRxAzpcoPb=24rDnebCeHolGxdiiTFkRDvj04zyrev0cINYnKrebleDoiuv0e4D; ssxmod_itna2=QqGxgQiQD=BDBDl4Yq0Pb1KTGkImqDkYBb7DfoR0DGtG9YDBwP7jvhcEu74Ga7Ilw0EzyR6d2XPxTQjy4zVbeerXodzedEofqS2OvXEeg7Bymxiy+U70iDFqG7RznB0m7K+P8ij5YvGqAB7XN0kGi+x67FAXeK7GoeD=;',
                'priority': 'u=0, i',
                'sec-ch-ua': '"Not;A Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
              };
              
            const symbols = await axios.get(url + "hk-web/symbol_label/info",{ headers });
            // const symbolList = symbols.data.data.symbolList;
            console.log(symbols.data);
            return;
            
            const symbolParts = symbol.split('/');
            const foundSymbol = symbolList.find(symbol => symbol.sellShortName === symbolParts[0] && symbol.buyShortName === symbolParts[1]);
            const tradeId = foundSymbol.tradeId;

            const urll = ``
            const params = {
                tradeId,
                period: timeframe,
                from: startTime,
                limit: 500,
                direction: -1
            };

            const response = await axios.get(url + "kline-history/kline/history", { params });
            const data = response.data;

            return data.map(kline => ([
                kline[0],//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
