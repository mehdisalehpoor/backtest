const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + quote.toUpperCase();
};
exports.getConfig = async (symbol) => {
  return {
    exchange: "bitget",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.bitget.com/v2/ws/public`,
    getSubscribeMessage: (symbol) => {
      return {
        op: "subscribe",
        args: [
          {
            instType: "SPOT",
            channel: "books5",
            instId: symbol,
          },
        ],
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.[0]?.asks || [];
      const bids = message?.data?.[0]?.bids || [];
      return { asks, bids };
    },
  };
};
