import ResponseHelper from "../Helpers/ResponseHelper";
import Event from "./Event";

class SendMessageEvent extends Event {
  constructor(io, socket, event, data) {
    super(io, socket, event, data);
  }
  async handle() {
    this.io.authenticatedUsers.find((client, index) => {
      if (client.user_id == this.data.user_id) {
        this.send(
          client.client_id,
          this.event,
          ResponseHelper.success(this.data, 200)
        );
      }
    });
  }
}
export default SendMessageEvent;
