const axios = require("axios");
const ProxyService = require("./ProxyService");

class OrangXService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.orangex.com/api/v1/public/get_order_book",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        instrument_name: `${symbol}-USDT-SPOT`,
        depth: 500,
      },
      // httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.result;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = OrangXService;
