class Router {
  constructor() {
    this.routes = [];
  }

  // set route group
  group(group) {
    // routes.forEach((route) => {
      this.routes.group = group;
    // });
    return this;
  }
  
  // set route middlewares
  middleware(middlewares) {
    if (this.routes.length != 0)
      this.routes[this.routes.length - 1].middlewares = middlewares;

    return this;
  }

  // register route
  register(event_name, handler) {
    this.routes.push({ event_name, handler });
    return this;
  }

  // set route namespace
  namespace(name_space) {
    if (this.routes.length != 0)
      this.routes[this.routes.length - 1].name_space = name_space;

    return this;
  }

  // get all routes with even name and middlewares and namespace
  all() {
    const handler = [...this.routes];
    return handler;
  }
}


export default Router;
