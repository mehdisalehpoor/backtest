const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "-" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "okx",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.okx.com:8443/ws/v5/public`,
    getSubscribeMessage: (symbol) => {
      return {
        op: "subscribe",
        args: [
          {
            channel: "books",
            instId: symbol,
          },
        ],
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.[0]?.asks || [];
      const bids = message?.data?.[0]?.bids || [];
      return { asks, bids };
    },
  };
};
