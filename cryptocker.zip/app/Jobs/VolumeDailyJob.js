const BinanceService = require('../Services/BinanceService');
const fs = require('fs').promises;
const { exchangeModules, loadExchangeConfig } = require('../Services/api/exchanges');
const TelegramBotService = require("../Services/TelegramBotService");
const CoinmarketcapHelpers = require("../Helpers/CoinmarketcapHelpers");
const { symbol, array } = require('joi');
const { RSI } = require('technicalindicators');

const runVolumeJob = async () => {
    try {
        // Create a request to get all futures symbols
        const [kucoinResponse, coinmarketcapResponse] = await Promise.all([
            BinanceService.getSpotSymbols(),
            CoinmarketcapHelpers.coinmarketcapFilterSymbolsList("binance"),
        ]);

        // const usdtSymbols = kucoinResponse.map(symbolInfo => symbolInfo.symbol);

        const usdtSymbols = [
            "BTC"
            //  "SXP",
            //     // "POLX",
            //     // "AI",
            //     //  "FTG",
            //     // "VXV",
            //     // "MJT",
            //     // "RBP",
            //     // "SRBP",
            //     // "FT",
            //     // "HIENS4",
            //     // "HIENS3",
            //     // "MC",
            //     // "HIODBS",
            //     // "PIX",
            //     // "GEM",
            //     //"BEAT",
            //     //  "HIFLUF",
            //     // "HIBIRDS",
            //     // "HIMFERS",
            //     // "HIUNDEAD",
            //     // "HIFRIENDS",
            //     // "HISEALS",
            //     // "HIBEANZ",
            //     // "OTK",
            //     // "HIBAKC",
            //     // "VERSE",
            //     // "MM",
            //     // "UQC",
            //     // "TUNE",
            // "FORTH"
        ];

        const coinmarketcapSymbols = coinmarketcapResponse.data.marketPairs;
        const data = [];

        for (const symbol of usdtSymbols) {
            try {

                await new Promise(resolve => setTimeout(resolve, 2000));
                const symbolWithoutUsdt = makeSymbolNameWithoutUsdt(symbol);

                const cmcSymbol = coinmarketcapSymbols.find(
                    cmcSymbol => cmcSymbol.baseSymbol === symbolWithoutUsdt && cmcSymbol.quoteSymbol === "USDT"
                );

                if (!cmcSymbol) continue;

                const config = await loadExchangeConfig(cmcSymbol.baseCurrencySlug);
                const { exchanges } = await CoinmarketcapHelpers.coinmarketcapCalculate(
                    cmcSymbol.baseCurrencySlug,
                    []
                );

                console.log(cmcSymbol.baseCurrencySlug);

                const filteredExistsExchangesUsdt = exchanges.filter(exchange =>
                    exchange.quoteSymbol === "USDT"
                    && exchange.exchangeSlug !== "binance-th"
                );


                const filteredExistsExchanges = filteredExistsExchangesUsdt.filter(exchange =>
                    Object.keys(exchangeModules).some(myExchange => myExchange === exchange.exchangeSlug.split('-')[0])
                );

                const percentageExists = (filteredExistsExchanges.length / filteredExistsExchangesUsdt.length) * 100;

                if (percentageExists < 5) {
                    console.log(
                        symbolWithoutUsdt,
                        "filteredExistsExchangesUsdt " + filteredExistsExchangesUsdt.length,
                        "filteredExistsExchanges " + filteredExistsExchanges.length,
                        "percentageExists", percentageExists.toFixed(0)
                    );
                    continue;
                }

                const exchangesCandles = [];
                await getCandleData(filteredExistsExchanges, exchangesCandles);

                const binanceCandles = await getBinanceData(exchangesCandles);
                const rsiFilePath = 'symbols\\rsi\\' + symbol + '.json';
                const filePath = 'symbols\\' + symbol + '.json';

                const volumeFile = await fs.readFile(filePath, 'utf8');
                const jsonData = await fs.readFile(rsiFilePath, 'utf8');
                const rsiData = JSON.parse(jsonData); // Parse the JSON data
                const volumeData = JSON.parse(volumeFile); // Parse the JSON data

                // console.log(binanceCandles[0]);
                rsiData.pop();
                rsiData.push(binanceCandles[0][binanceCandles[0].length - 1]);
                const lastDay = volumeData[volumeData.length - 1];

                data.push(await analyzeVolume(await sum(exchangesCandles), lastDay, rsiData));
                console.log(data);
            } catch (error) {
                console.error(symbol.baseSymbol, error);
            }
        }
        // const filePath = 'data.json'
        return data;
    } catch (error) {
        console.error(error);
        TelegramBotService.futuresSignalSend(error.message);
    }
};

const getBinanceData = (data) => {
    return data.map(innerArray => {
        return innerArray.filter(entry => entry[3].toLowerCase() === 'binance');
    }).filter(innerArray => innerArray.length > 0);
}

const sumIndexTwo = (dataArray) => {
    return dataArray.reduce((sum, current) => {
        return sum + current[2]; // Index 2 is where the value to sum is located
    }, 0);
};

const sum = (candleData) => {
    const combinedData = candleData.flat();
    combinedData.sort((a, b) => new Date(a[0]) - new Date(b[0]));

    const result = combinedData.reduce((acc, current) => {
        const date = current[0];
        const volume = Number(current[2]);
        const symbol = current[1];
        const closePrice = current[5];
        const highPrice = current[6];

        // Check if the date is not today's date

        if (acc[date]) {
            acc[date].volume += volume;
        } else {
            acc[date] = { date, symbol, volume, closePrice, highPrice };
        }


        return acc;
    }, {});

    // Create an array from the result object
    const finalResult = Object.keys(result).map(date => [
        date,
        result[date].symbol,
        result[date].volume,
        result[date].closePrice,
        result[date].highPrice
    ]);

    // Sort the final result by date
    finalResult.sort((a, b) => new Date(a[0]) - new Date(b[0]));
    return finalResult[finalResult.length - 1];
};


const analyzeVolume = async (combinedData, lastDay, binanceCandles) => {

    const closingPrices = binanceCandles.map(candle => parseFloat(candle[7]));
    const rsiValues = await calculateRSI(closingPrices);
    const rsi = rsiValues[rsiValues.length - 1];

    const response = [];
    if (
        combinedData[2] > 2 * lastDay.AverageVolume &&
        rsi >= 70
    ) {
        const textSignal = `[SPOT]\n#Signal\nSymbol=${combinedData[1] + "USDT"}\nRSI=${rsi}\nVolume=${combinedData[2]}`;
        TelegramBotService.futuresSend(textSignal);
        response.push({
            Date: combinedData[0],
            Symbol: combinedData[1] + "USDT",
            Volume: combinedData[2],
            rsi
        });
    }

    return response;
}

/**
 * Converts a Unix timestamp to a human-readable date.
 * 
 * @param {number} timestamp - The Unix timestamp in seconds.
 * @returns {string} - The formatted date string.
 */
const timestampToDate = (timestamp, exchangeSlug) => {
    const date = new Date((exchangeSlug === "binance" || exchangeSlug === "bybit") ? timestamp : timestamp * 1000);

    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2); // Months are zero-based
    const day = ('0' + date.getDate()).slice(-2);
    const hours = ('0' + date.getHours()).slice(-2);
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2);

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

runVolumeJob();

async function getCandleData(filteredExistsExchanges, exchangesCandles) {
    await Promise.all(filteredExistsExchanges.map(async (exchange) => {
        try {
            await new Promise(resolve => setTimeout(resolve, 1500));
            const [exchangeName] = exchange.exchangeSlug.split('-');
            const exchangeConfig = loadExchangeConfig(exchangeName);

            if (!exchangeConfig) throw new Error(`Exchange configuration for ${exchangeName} not found`);

            const getConfig = await exchangeConfig.getConfig(exchange.baseSymbol, exchange.quoteSymbol);

            let candles = await getConfig.getKlines(getConfig.url, getConfig.symbol, "1d");

            const candlestick = candles.map(candleData =>
                [
                    timestampToDate(candleData[0], exchange.exchangeSlug),
                    exchange.baseSymbol,
                    candleData[5],
                    exchange.exchangeSlug,
                    exchange.marketPair,
                    candleData[2],
                    candleData[3],
                    candleData[4],
                ]);

            exchangesCandles.push(candlestick);
        } catch (error) {
            console.log(exchange.marketPair + " " + exchange.exchangeSlug + " " + error);
        }
    }));
}

function makeSymbolNameWithoutUsdt(symbol) {
    return symbol.replace("USDT", "").replace("-", "");
}

const calculateRSI = (closingPrices, period = 14) => {
    return RSI.calculate({ values: closingPrices, period: period });
};

const getBTCUSDRSI = async () => {

    const rsiValues = calculateRSI(closingPrices);
    console.log('RSI Values:', rsiValues);

};
