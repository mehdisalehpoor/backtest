const { Sequelize } = require("sequelize");
const { database } = require("./configs");

const sequelize = new Sequelize(database.database_url, { logging: false });

module.exports = sequelize;
