const axios = require("axios");
const ProxyService = require("./ProxyService");

class GateService {
  static async getOrderbook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.gateio.ws/api/v4/spot/order_book",
    });

    const agent = await ProxyService.getProxyAddress();

    const response = await axiosClient.get("", {
      params: {
        currency_pair: `${symbol}`,
        limit: 5000,
      },
      httpsAgent: agent,
    });

    const formattedResponse = {
      asks: response.data.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: response.data.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };
    return formattedResponse;
  }
}

module.exports = GateService;
