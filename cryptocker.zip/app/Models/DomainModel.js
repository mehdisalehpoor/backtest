const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const DomainModel = sequelize.define(
    "domains",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false,
        },
        host: {
            type: DataTypes.STRING(30),
            unique: true,
            allowNull: false,
        },
        port: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        status: {
            type: DataTypes.BOOLEAN,
            allowNull: false,
            defaultValue: true
        },
    },
    {
        timestamps: true,
        underscored: true,
    }
);

module.exports = DomainModel;
