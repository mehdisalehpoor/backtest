const WebSocket = require('ws');

class BinanceOrderBookWebSocket {
  constructor(symbol) {
    this.symbol = symbol;
    this.url = `wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@depth`;
    this.ws = null;
  }

  connect() {
    this.ws = new WebSocket(this.url);

    this.ws.on('open', () => {
      console.log('WebSocket connection opened');
    });

    this.ws.on('message', (data) => {
      const orderBookData = JSON.parse(data);
      this.handleOrderBookData(orderBookData);
    });

    this.ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });

    this.ws.on('close', () => {
      console.log('WebSocket connection closed');
    });

    process.on('SIGINT', () => {
      this.close();
      process.exit();
    });
  }

  handleOrderBookData(data) {
    // Implement your logic to handle order book data here
    const formattedResponse = {
      asks: data.a.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: data.b.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };
    console.log(formattedResponse);
  }

  close() {
    if (this.ws) {
      this.ws.close();
    }
  }
}

// Example usage
const binanceOrderBook = new BinanceOrderBookWebSocket('BTCUSDT');
binanceOrderBook.connect();
