const binance = require("./binance");
const bybit = require("./bybit");
const bingx = require("./bingx");
const bitfinex = require("./bitfinex");
const bitget = require("./bitget");
const bitrue = require("./bitrue");
const bitstamp = require("./bitstamp");
const bitvenus = require("./bitvenus");
const coinbase = require("./coinbase");
const crypto = require("./crypto");
const gate = require("./gate");
const hotcoin = require("./hotcoin");
const htx = require("./htx");
const kraken = require("./kraken");
const kucoin = require("./kucoin");
const lbank = require("./lbank");
const mexc = require("./mexc");
const nominex = require("./nominex");
const okx = require("./okx");
const orangex = require("./orangex");
const phemex = require("./phemex");
const trubit = require("./trubit");
const xt = require("./xt");

const exchangeModules = {
  binance,
  bybit,
  bingx,
  bitfinex,
  bitget,
  bitrue,
  bitstamp,
  bitvenus,
  coinbase,
  crypto,
  gate,
  hotcoin,
  htx,
  kraken,
  kucoin,
  lbank,
  mexc,
  nominex,
  okx,
  orangex,
  phemex,
  trubit,
  xt,
};

export const loadExchangeConfig = (exchange) => {
  return exchangeModules[exchange] || null;
};
