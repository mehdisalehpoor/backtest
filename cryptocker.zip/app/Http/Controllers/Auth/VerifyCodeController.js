import Handler from "../../../Exceptions/handler";
import { ErrorCode } from "../../../Exceptions/errorCode";
import JwtService from "../../../Services/JwtService";
import UserQueryHelpers from "../../../Helpers/UserQueryHelpers";

class VerifyCodeController {
  static async handle(req, res, next) {
    const { mobile, otp } = req.body;
    try {
      const userData = await UserQueryHelpers.findUserWithMobile(mobile);

      if (!userData) throw new Handler(ErrorCode.USER_NOT_EXISTS);

      const otpData = await UserQueryHelpers.findOtpCode(mobile, otp);

      if(!otpData || otpData.used_at !== null) throw new Handler(ErrorCode.USER_NOT_EXISTS);

      UserQueryHelpers.updateOtpCode(otpData.id);

      const token = JwtService.create(userData.id);

      res.response({ token });
    } catch (error) {
      next(error);
    }
  }
}

export default VerifyCodeController;
