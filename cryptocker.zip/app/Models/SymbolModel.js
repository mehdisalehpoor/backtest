const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const SymbolModel = sequelize.define(
  "symbols",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbol: {
      type: DataTypes.STRING(30),
      unique: true,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    exchangeTicker: {
      type: DataTypes.STRING(100),
      allowNull: true,
    },
    futures: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    spot: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    exchangeVolume: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    initialLeverage: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 10,
    },
    baseAssetPrecision: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    stepAssetPrecision: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    deleted_at: {
      type: DataTypes.DATE,
      type: "TIMESTAMP",
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

module.exports = SymbolModel;
