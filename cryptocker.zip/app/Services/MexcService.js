const axios = require("axios");
const crypto = require("crypto");

const { apiKey } = require("../../config/configs");

class MexcService {
  static async getOrderbook(symbol) {
    const API_BASE_URL = "https://www.mexc.com/open/api/v2/market"; // MXC API base URL
    const TRADING_PAIR = symbol; // BTC/USDT trading pair
    const API_KEY = apiKey.mexc_api_key;
    const API_SECRET = apiKey.mexc_secret_key;
    try {
      const timestamp = Date.now();
      const signature = crypto
        .createHmac("sha256", API_SECRET)
        .update(`${API_KEY}${timestamp}`)
        .digest("hex");

      const response = await axios.get(`${API_BASE_URL}/depth`, {
        params: {
          symbol: TRADING_PAIR,
          depth: 2000, // You can adjust the number of levels you want to retrieve
        },
        headers: {
          "Content-Type": "application/json",
          "API-key": API_KEY,
          "API-signature": signature,
          "API-timestamp": timestamp,
        },
      });

      if (response.data && response.data.data) {
        const orderBook = response.data.data;
        const formattedResponse = {
          asks: orderBook.asks.map((item) => [
            parseFloat(item.price),
            parseFloat(item.quantity),
          ]),
          bids: orderBook.bids.map((item) => [
            parseFloat(item.price),
            parseFloat(item.quantity),
          ]),
        };
        return formattedResponse;
      } else {
        console.error("Unable to retrieve order book data.");
      }
    } catch (error) {
      console.error("An error occurred:", error);
    }
  }
  static async getTicker(symbol) {
    const API_BASE_URL = "https://www.mexc.com/open/api/v2/market"; // MXC API base URL
    const TRADING_PAIR = symbol; // BTC/USDT trading pair
    const API_KEY = apiKey.mexc_api_key;
    const API_SECRET = apiKey.mexc_secret_key;
    try {
      const timestamp = Date.now();
      const signature = crypto
        .createHmac("sha256", API_SECRET)
        .update(`${API_KEY}${timestamp}`)
        .digest("hex");

      const response = await axios.get(`${API_BASE_URL}/ticker`, {
        params: {
          symbol: TRADING_PAIR,
        },
        headers: {
          "Content-Type": "application/json",
          "API-key": API_KEY,
          "API-signature": signature,
          "API-timestamp": timestamp,
        },
      });

      if (response.data && response.data.data) {
        const orderBook = response.data.data;
        console.log(orderBook[0].last);
        return parseFloat(orderBook[0].last);
      } else {
        console.error("Unable to retrieve order book data.");
      }
    } catch (error) {
      console.error("An error occurred:", error);
    }
  }
}

module.exports = MexcService;