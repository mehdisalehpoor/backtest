"use strict";

const sequelize = require("sequelize");

module.exports = {
    up: function (queryInterface, DataTypes) {
        return queryInterface.createTable("otp_codes", {
            id: {
                type: DataTypes.INTEGER,
                autoIncrement: true,
                primaryKey: true,
                allowNull: false,
            },
            mobile: {
                type: DataTypes.STRING(30),
                allowNull: false,
            },
            otp: {
                type: DataTypes.STRING(30),
                allowNull: false,
            },
            hash: {
                type: DataTypes.STRING(30),
                allowNull: false,
            },
            used_at: {
                allowNull: true,
                type: DataTypes.DATE,
            },
            created_at: {
                allowNull: false,
                type: DataTypes.DATE,
                defaultValue: sequelize.NOW
            },
            updated_at: {
                allowNull: true,
                type: DataTypes.DATE,
            },
            deleted_at: {
                type: DataTypes.DATE,
                allowNull: true,
            },
        });
    },

    down: function (queryInterface, DataTypes) {
        return queryInterface.dropTable("otp_codes");
    },
};
