const CoinmarketcapService = require("../Services/CoinmarketcapService");
const axios = require("axios");
// const ExchangeQueryHelpers = require("./ExchangeQueryHelpers");
class CoinmarketcapHelpers {
  static async coinmarketcapCalculate(slug, exchangeSuccessFull) {
    const coinmarketcap = await CoinmarketcapService.getLatestMarketPairs(
      slug
    );

    const exchanges = coinmarketcap.data.marketPairs;

    const depthPositiveTwoSum = coinmarketcap.data.marketPairs.reduce(
      (sum, pair) => sum + pair.depthUsdPositiveTwo,
      0
    );

    const depthUsdNegativeTwo = coinmarketcap.data.marketPairs.reduce(
      (sum, pair) => sum + pair.depthUsdNegativeTwo,
      0
    );

    const coinmarketcapRate =
      depthPositiveTwoSum >= depthUsdNegativeTwo
        ? depthPositiveTwoSum / depthUsdNegativeTwo
        : depthUsdNegativeTwo / depthPositiveTwoSum;

    const coinmarketcapSale =
      depthPositiveTwoSum >= depthUsdNegativeTwo ? "sell" : "buy";

    const myExchanges = exchangeSuccessFull;

    const filteredExistsExchanges = exchanges.filter((exchange) => {
      // Check if exchangeId exists in myExchanges
      const matchingExchange = myExchanges.find(
        (myExchange) => myExchange.exchangeId === exchange.exchangeId
      );

      // Check if quoteSymbol is "USDT"
      return (
        matchingExchange &&
        (exchange.quoteSymbol === "USDT" ||
          exchange.quoteSymbol === "USD" ||
          exchange.quoteSymbol === "USDC")
      );
    });

    const filteredNotExistsExchanges = exchanges.filter((exchange) => {
      // Check if exchangeId does not exist in myExchanges
      const exchangeIdNotInMyExchanges = !myExchanges.some(
        (myExchange) => myExchange.exchangeId === exchange.exchangeId
      );

      // Check if quoteSymbol is not "USDT"
      const quoteSymbolNotUSDT = exchange.quoteSymbol !== "USDT";

      // Return true if both conditions are met (i.e., exchangeId is not in myExchanges and quoteSymbol is not USDT)
      return exchangeIdNotInMyExchanges && quoteSymbolNotUSDT;
    });

    const sumExistsExchangesDepthPositiveTwo = filteredExistsExchanges.reduce(
      (sum, pair) => sum + pair.depthUsdPositiveTwo,
      0
    );

    const sumExistsExchangesDepthNegativeTwo = filteredExistsExchanges.reduce(
      (sum, pair) => sum + pair.depthUsdNegativeTwo,
      0
    );

    const sumExistsExchangesVolume = filteredExistsExchanges.reduce(
      (sum, pair) => sum + pair.volumePercent,
      0
    );

    const sumNotExistsExchangesDepthPositiveTwo =
      filteredNotExistsExchanges.reduce(
        (sum, pair) => sum + pair.depthUsdPositiveTwo,
        0
      );

    const sumNotExistsExchangesDepthNegativeTwo =
      filteredNotExistsExchanges.reduce(
        (sum, pair) => sum + pair.depthUsdNegativeTwo,
        0
      );

    const diffExistsExchangesDepthPositiveTwo =
      (sumExistsExchangesDepthPositiveTwo * 100) / depthPositiveTwoSum;
    const diffExistsExchangesDepthNegativeTwo =
      (sumExistsExchangesDepthNegativeTwo * 100) / depthUsdNegativeTwo;

    const coinmarketcapNotExistsExchangesSale =
      sumNotExistsExchangesDepthPositiveTwo >=
        sumNotExistsExchangesDepthNegativeTwo
        ? "sell"
        : "buy";

    var message = `Symbol Name = ${slug}\nCMCAPSale = ${coinmarketcapSale}\n`;
    message += `CMCAPRate = ${coinmarketcapRate}\nCMCapNESale = ${coinmarketcapNotExistsExchangesSale}\n`;
    message += `CMCAPAsksDiff = ${diffExistsExchangesDepthPositiveTwo}\n`;
    message += `CMCAPBidsDiff = ${diffExistsExchangesDepthNegativeTwo}\n`;

    diffExistsExchangesDepthPositiveTwo;
    diffExistsExchangesDepthNegativeTwo;
    return {
      coinmarketcapSale,
      depthPositiveTwoSum,
      depthUsdNegativeTwo,
      coinmarketcapRate,
      filteredExistsExchanges,
      coinmarketcapNotExistsExchangesSale,
      diffExistsExchangesDepthPositiveTwo,
      diffExistsExchangesDepthNegativeTwo,
      sumNotExistsExchangesDepthPositiveTwo,
      sumNotExistsExchangesDepthNegativeTwo,
      sumExistsExchangesVolume,
      exchanges
    };
  }

  static async checkExchanges(exchanges) {
    const myExchanges = await ExchangeQueryHelpers.getAllExchanges();

    const filteredExistsExchanges = exchanges.filter((exchange) => {
      // Check if exchangeId exists in myExchanges
      const matchingExchange = myExchanges.find(
        (myExchange) => myExchange.exchangeId === exchange.exchangeId
      );

      // Check if quoteSymbol is "USDT"
      return (
        matchingExchange &&
        (exchange.quoteSymbol === "USDT" ||
          exchange.quoteSymbol === "USD" ||
          exchange.quoteSymbol === "USDC")
      );
    });

    const binanceExists = exchanges.some((exchange) => {
      return exchange.exchangeId === 270;
    });

    const filteredNotExistsExchanges = exchanges.filter((exchange) => {
      // Check if exchangeId does not exist in myExchanges
      const exchangeIdNotInMyExchanges = !myExchanges.some(
        (myExchange) => myExchange.exchangeId === exchange.exchangeId
      );

      // Check if quoteSymbol is not "USDT"
      const quoteSymbolNotUSDT =
        exchange.quoteSymbol !== "USDT" ||
        exchange.quoteSymbol !== "USD" ||
        exchange.quoteSymbol !== "USDC";

      // Return true if both conditions are met (i.e., exchangeId is not in myExchanges and quoteSymbol is not USDT)
      return exchangeIdNotInMyExchanges && quoteSymbolNotUSDT;
    });
    return {
      filteredExistsExchanges,
      filteredNotExistsExchanges,
      binanceExists,
    };
  }

  static async coinmarketcapSymbolsList() {
    const coinmarketcapResponseSymbolsList = await axios.get(
      `https://api.coinmarketcap.com/data-api/v3/cryptocurrency/listings/historical?limit=200000&date=2024-06-20&sort=cmc_rank&cryptocurrency_type=all`
    );

    return coinmarketcapResponseSymbolsList;
  }


  static async coinmarketcapFilterSymbolsList(exchange) {
    const coinmarketcapResponseSymbolsList = await axios.get(
      `https://api.coinmarketcap.com/data-api/v3/exchange/market-pairs/latest?slug=${exchange}&category=spot&quoteCurrencyId=825&limit=1000`
    );

    return coinmarketcapResponseSymbolsList.data;
  }

  static async coinmarketcapHistorical(id, timeStart, timeFrame = "30d") {
    const coinmarketcapResponseSymbolsList = await axios.get(
      `https://api.coinmarketcap.com/data-api/v3.1/cryptocurrency/historical?id=${id}&timeStart=${timeStart}&interval=${timeFrame}d&convertId=2781`
    );
    
    return coinmarketcapResponseSymbolsList.data.data;
  }
}

module.exports = CoinmarketcapHelpers;
