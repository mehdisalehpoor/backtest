const { loadExchangeConfig } = require("./exchanges/index");
const WebSocketClient = require("./clients/WebSocketClient");

const cryptockerWs = async (exchangeName, symbol, baseSymbol) => {
  const exchangeConfig = loadExchangeConfig(exchangeName);

  if (!exchangeConfig) {
    console.error(`Exchange ${exchangeName} is not supported.`);
    return null;
  }

  const config = await exchangeConfig.getConfig(symbol);
  if (!config) {
    console.error(
      `No configuration found for symbol ${symbol} on exchange ${exchangeName}`
    );
    return null;
  }

  return new WebSocketClient(config, baseSymbol);
};

module.exports = {
  cryptockerWs,
};
