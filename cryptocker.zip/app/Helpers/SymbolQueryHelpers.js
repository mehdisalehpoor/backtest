const { Op } = require("sequelize");

const DateHelpers = require("./DateHelpers");
const ExchangeModel = require("../Models/ExchangeModel");
const SymbolModel = require("../Models/SymbolModel");
const SignalModel = require("../Models/SignalModel");

class SymbolQueryHelpers {
  static async getKucoinSymbol() {
    const symbolExists = await SymbolModel.findAll({
      include: {
        model: ExchangeModel,
        where: { name: "kucoin" },
      },
    });
    console.log(symbolExists);
    return symbolExists;
  }


  static async getSymbolWithExchangeId(exchangeId) {
    var symbols = await SymbolExchangeModel.findAll({
      // limit: 5,
      where: {
        exchange_id: exchangeId,
      },
    });

    return symbols;
  }

  static async getLastFourHourSignal() {
    const today = DateHelpers.today();
    const signals = await SignalModel.findAll({
      where: {
        exit: false,
        created_at: {
          [Op.between]: [today.startOfToday, today.endOfToday],
        },
      },
    });

    return signals;
  }

  static async getLastTwentyFourHourSignal() {
    const lastTwentyFourHours = DateHelpers.lastTwentyFourHours();
    const signals = await SignalModel.findAll({
      where: {
        exit: false,
        created_at: {
          [Op.between]: [lastTwentyFourHours.startOfLastTwentyFourHours, lastTwentyFourHours.endOfLastTwentyFourHours],
        },
      },
    });

    return signals;
  }
}

module.exports = SymbolQueryHelpers;
