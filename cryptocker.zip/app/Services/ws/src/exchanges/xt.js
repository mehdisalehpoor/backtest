const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toLowerCase() + "_" + quote.toLowerCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "xt",
    symbol: await fixSymbolName(symbol),
    url: `wss://stream.xt.com/public`,
    getSubscribeMessage: (symbol) => {
      return {
        method: "subscribe",
        params: [`depth_update@${symbol}`],
        id: 55, // callback ID
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.a || [];
      const bids = message?.data?.b || [];

      return { asks, bids };
    },
  };
};
