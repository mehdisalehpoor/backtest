const CryptoJS = require("crypto-js");
const axios = require("axios");
const { apiKey } = require("../../config/configs");

class BingxService {
  constructor(symbol) {
    this.API_KEY = apiKey.bingx_api_key;
    this.API_SECRET = apiKey.bingx_key_secret;
    this.HOST = "open-api.bingx.com";
    this.API = {
      uri: "/openApi/spot/v1/market/depth",
      method: "GET",
      payload: {
        symbol: symbol,
        limit: 100,
      },
      protocol: "https",
    };
  }

  async main() {
    const data = await this.bingXOpenApiTest(
      this.API.protocol,
      this.HOST,
      this.API.uri,
      this.API.method
    );
    return data;
  }

  getParameters(timestamp, urlEncode) {
    let parameters = "";
    for (const key in this.API.payload) {
      if (urlEncode) {
        parameters +=
          key + "=" + encodeURIComponent(this.API.payload[key]) + "&";
      } else {
        parameters += key + "=" + this.API.payload[key] + "&";
      }
    }
    if (parameters) {
      parameters = parameters.substring(0, parameters.length - 1);
      parameters = parameters + "&timestamp=" + timestamp;
    } else {
      parameters = "timestamp=" + timestamp;
    }
    return parameters;
  }

  async bingXOpenApiTest(protocol, host, path, method) {
    const timestamp = new Date().getTime();
    const sign = CryptoJS.enc.Hex.stringify(
      CryptoJS.HmacSHA256(this.getParameters(timestamp), this.API_SECRET)
    );
    const url =
      protocol +
      "://" +
      host +
      path +
      "?" +
      this.getParameters(timestamp, true) +
      "&signature=" +
      sign;

    const config = {
      method: method,
      url: url,
      headers: {
        "X-BX-APIKEY": this.API_KEY,
      },
      transformResponse: (resp) => {
        return resp;
      },
    };

    const response = await axios(config);
    const orderBookResponse = JSON.parse(response.data);

    const orderBook = orderBookResponse.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = BingxService;
