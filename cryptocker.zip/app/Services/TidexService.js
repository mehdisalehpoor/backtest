const axios = require("axios");
const ProxyService = require("./ProxyService");

class TidexService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create();

    const agentOne = await ProxyService.getProxyAddress();
    const agentTwo = await ProxyService.getProxyAddress();

    const [buyResponse, sellResponse] = await Promise.all([
      axiosClient.get("https://api.tidex.com/api/v1/public/book", {
        params: {
          market: `${symbol}_USDT`,
          side: "buy",
          offset: 0,
          limit: 1000,
        },
        httpsAgent: agentOne,
      }),

      axiosClient.get("https://api.tidex.com/api/v1/public/book", {
        params: {
          market: `${symbol}_USDT`,
          side: "sell",
          offset: 0,
          limit: 1000,
        },
        httpsAgent: agentTwo,
      }),
    ]);

    const buyOrderBook = buyResponse.data;
    const sellOrderBook = sellResponse.data;

    const formattedResponse = {
      bids: buyOrderBook.result.orders.map((item) => [
        parseFloat(item['price']),
        parseFloat(item['amount']),
      ]),
      asks: sellOrderBook.result.orders.map((item) => [
        parseFloat(item['price']),
        parseFloat(item['amount']),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = TidexService;
