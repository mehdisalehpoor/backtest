const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "_" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "gate-io",
    symbol: await fixSymbolName(symbol),
    url: `wss://api.gateio.ws/ws/v4/`,
    getSubscribeMessage: (symbol) => {
      return {
        channel: "spot.order_book",
        event: "subscribe",
        payload: [symbol, "100", "100ms"],
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.result?.asks || [];
      const bids = message?.result?.bids || [];
      return { asks, bids };
    },
  };
};
