const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://api-cloud.bitmart.com/spot/quotation/v3/",
        symbol: baseSymbol + "_" + quoteSymbol,
        exchange: "bitmart",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            let step = 1;
            if (timeframe === "1d") {
                step = 1440;
            }
            const params = {
                symbol: symbol,
                step: step,
            };

            if (startTime){
                params.startTime = startTime;
            }
            if (endTime){
                params.endTime = endTime;
            }

            const response = await axios.get(url + "klines", { params });
            const data = response.data.data;
            
            return data.map(kline => ([
                kline[0],//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
