import sequelize, { Sequelize, Op } from "sequelize";
import SymbolModel from "../../../Models/SymbolModel";
import SymbolVolumeModel from "../../../Models/SymbolVolumeModel";
import moment from "moment-timezone";
import BinanceService from "../../../Services/BinanceService";
export class BackTestController {
  static async handle(req, res, nex) {
    try {
      console.log("Testing");
      const { symbol, type } = req.body;
      const date = req.body.date ?? null;
      const volume = req.body.volume ?? 2700000;
      const money = req.body.money ?? 100;
      const stopLoss = req.body.stopLoss ?? 0.006;
      const takeProfit = req.body.takeProfit ?? 0.03;
      const saveProfit = req.body.saveProfit == "1" ? true : false;

      var symbolVolumes = null;
      var matchingDensityDetails = [];
      
      if (type == "volume_1" || type == "volume_2" || type == "volume_3") {
        await SymbolVolumeModel.sequelize
          .query(
            `SELECT
            symbol_volumes.id,
            symbol_volumes.symbol_id,
            symbol_volumes.spot_price,
            symbol_volumes.payload,
            symbol_volumes.created_at,
            symbols.symbol,
            NULLIF(CAST((payload::jsonb -> 0 ->> 'difference') AS NUMERIC), 'NaN') AS difference,
            (payload::jsonb -> 0 ->> 'sale')::varchar AS status,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxStatus')::varchar AS densityVolumeStatus,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityDiff')::varchar AS densityDiff,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxRate')::varchar AS densityBoxRate
        FROM
            symbol_volumes
                JOIN LATERAL jsonb_array_elements(symbol_volumes.payload::jsonb) AS payload ON TRUE
                JOIN symbols ON symbol_volumes.symbol_id = symbols.id
        GROUP BY
            symbol_volumes.id,
            symbols.symbol
        HAVING
                NULLIF(CAST((payload::jsonb -> 0 ->> 'difference') AS NUMERIC), 'NaN') >= ${parseFloat(volume)}
        ORDER BY
            symbol_volumes.id;`,
            {
              type: SymbolVolumeModel.sequelize.QueryTypes.SELECT,
            }
          )
          .then((volumes) => {
            symbolVolumes = volumes;
          });
      }

      if (type == "box") {
        await SymbolVolumeModel.sequelize
          .query(
            `SELECT sv.id,
            sv.symbol_id,
            sv.spot_price,
            sv.payload,
            sv.created_at,
            s.symbol,
            NULLIF(CAST((payload::jsonb -> 0 ->> 'difference') AS NUMERIC), 'NaN') AS difference,
            (payload::jsonb -> 0 ->> 'sale')::varchar                                         AS status,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityVolumeStatus')::varchar AS densityVolumeStatus,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityDiff')::varchar         AS densityDiff,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxRate')::varchar      AS densityBoxRate
     FROM symbol_volumes sv
              JOIN LATERAL jsonb_array_elements(sv.payload::jsonb) AS payload ON TRUE
              JOIN symbols s ON sv.symbol_id = s.id
     WHERE NULLIF(CAST((payload::jsonb -> 0 ->> 'difference') AS NUMERIC), 'NaN') <= ${volume}
       AND (
                 (payload::jsonb -> 0 ->> 'sale')::varchar = 'buy'
             AND sv.id NOT IN (SELECT sv_inner.id
                               FROM unnest(ARRAY [1, 2, 3, 4, 5, 6, 7, 8, 9]) AS i
                                        JOIN symbol_volumes sv_inner ON sv_inner.id = sv.id
                               WHERE (sv_inner.payload::jsonb -> i ->> 'sale')::varchar = 'buy')
         )
     GROUP BY sv.id,
              sv.symbol_id,
              s.symbol
     `,
            {
              type: SymbolVolumeModel.sequelize.QueryTypes.SELECT,
            }
          )
          .then((volumes) => {
            symbolVolumes = volumes;
          });
      }

      if (type == "db_1") {
        await SymbolVolumeModel.sequelize
          .query(
            `SELECT
            symbol_volumes.id,
            symbol_volumes.symbol_id,
            symbol_volumes.spot_price,
            symbol_volumes.payload,
            symbol_volumes.created_at,
            symbols.symbol,
            NULLIF(CAST((payload::jsonb -> 0 ->> 'difference') AS NUMERIC), 'NaN') AS difference,
            (payload::jsonb -> 0 ->> 'sale')::varchar AS status,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxRate')::int AS densityBoxRate,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxStatus')::varchar AS densityVolumeStatus,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityDiff')::varchar AS densityDiff,
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityVolumeStatus')::varchar AS densityVolumeStatus,
            (SELECT COUNT(*)
             FROM jsonb_array_elements(symbol_volumes.payload::jsonb) AS inner_payload
             WHERE (inner_payload ->> 'sale')::varchar = (payload::jsonb -> 0 ->> 'sale')::varchar) AS sale_count
        FROM
            symbol_volumes
        JOIN LATERAL jsonb_array_elements(symbol_volumes.payload::jsonb) AS payload ON TRUE
        JOIN symbols ON symbol_volumes.symbol_id = symbols.id
        WHERE
            (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxRate')::int >= 80
            AND (payload::jsonb -> 0 ->> 'sale')::varchar = (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityBoxStatus')::varchar
            AND (payload::jsonb -> 0 ->> 'sale')::varchar = (payload::jsonb -> 0 -> 'densityDetails' -> 0 ->> 'densityVolumeStatus')::varchar
            AND (SELECT COUNT(*)
                 FROM jsonb_array_elements(symbol_volumes.payload::jsonb) AS inner_payload
                 WHERE (inner_payload ->> 'sale')::varchar = (payload::jsonb -> 0 ->> 'sale')::varchar) > 1
        GROUP BY
            symbol_volumes.id,
            symbols.symbol
        ORDER BY
            symbol_volumes.id`,
            {
              type: SymbolVolumeModel.sequelize.QueryTypes.SELECT,
            }
          )
          .then((volumes) => {
            symbolVolumes = volumes;
          });
      }
      console.log(symbolVolumes.length);
      if (type == "box_check") {
        await BackTestController.boxCheck(
          symbolVolumes,
          matchingDensityDetails
        );
      }

      if (type == "volume_1" || type == "volume_2") {
        console.log("volumeCheck");
        await BackTestController.volumeCheck(
          symbolVolumes,
          matchingDensityDetails,
          parseFloat(volume),
          type
        );
      }

      matchingDensityDetails.sort(function (a, b) {
        return a.id - b.id;
      });

      const backTestDetails = [];

      if (type == "db_1") {
        console.log("dbVolumeCheck");
        await BackTestController.dbVolumeCheck(
          symbolVolumes,
          matchingDensityDetails,
          parseFloat(volume),
          type,
          backTestDetails,
          parseFloat(money),
          parseFloat(stopLoss),
          parseFloat(takeProfit),
          saveProfit
        );
      }

      if (type == "box") {
        console.log("boxTwoPercentCheck");
        await BackTestController.boxTwoPercentCheck(
          symbolVolumes,
          matchingDensityDetails,
          parseFloat(volume),
          type
        );
      }

      console.log(matchingDensityDetails.length);

      if (type !== "db_1") {
        console.log("profitCheck");

        await BackTestController.profitCheck(
          matchingDensityDetails,
          backTestDetails,
          parseFloat(money),
          type,
          parseFloat(stopLoss),
          parseFloat(takeProfit),
          saveProfit
        );
      }

      res.send(backTestDetails);
    } catch (error) {
      console.log(error);
      res.send(error);
    }
  }

  static async profitCheck(
    matchingDensityDetails,
    backTestDetails,
    moneyAmount = 100,
    type,
    stop = 0.01,
    profit = 0.03,
    profitSave = true
  ) {
    for (const [indexItem, item] of matchingDensityDetails.entries()) {
      try {
        let startPrice = item.startPrice;
        let stopLossPrice =
          item.status == "buy"
            ? startPrice - startPrice * stop
            : startPrice + startPrice * stop;
        let startDate = new Date(item.timestamp).toLocaleString("en-US", {
          timeZone: "Asia/Tehran",
          hour12: false,
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        });
        let startDateUnix = item.timestamp;

        let index = null;
        let percent = 0;
        const lastSymbol =
          backTestDetails.length > 0
            ? backTestDetails[backTestDetails.length - 1].symbolName
            : null;

        const lastStop =
          backTestDetails.length > 0
            ? backTestDetails[backTestDetails.length - 1].stopDateUnix
            : null;
        console.log(item.symbolName, lastSymbol, startDateUnix, lastStop);
        if (
          backTestDetails.length == 0 ||
          item.symbolName != lastSymbol ||
          (startDateUnix - lastStop > 0 && item.symbolName == lastSymbol)
          // backTestDetails.length == 0 ||
          // (backTestDetails.length > 0 &&
          //   backTestDetails[backTestDetails.length - 1].symbolName !=
          //     item.symbolName) ||
          // (backTestDetails.length > 0 &&
          //   backTestDetails[backTestDetails.length - 1].symbolName !=
          //     item.symbolName &&
          //   backTestDetails[backTestDetails.length - 1].stopDateUnix <
          //     startDateUnix)
        ) {
          let profitMoneyAmount =
            backTestDetails.length > 0
              ? backTestDetails[backTestDetails.length - 1].profitMoneyAmount
              : parseFloat(moneyAmount);

          // Get all elements except the first one
          const candles = item.range.slice(1);

          const stopLossIndex = candles.findIndex((candle) =>
            item.status == "buy"
              ? candle.lowPrice <= stopLossPrice
              : candle.highPrice >= stopLossPrice
          );

          var profitOneCheckIndex = candles.findIndex((candle) =>
            item.status == "buy"
              ? candle.highPrice >= startPrice + startPrice * 0.015
              : candle.lowPrice <= startPrice - startPrice * 0.015
          );

          if (
            (stopLossIndex !== -1 && profitOneCheckIndex == -1) ||
            (stopLossIndex !== -1 &&
              profitOneCheckIndex !== -1 &&
              stopLossIndex < profitOneCheckIndex)
          ) {
            type = "loss";
            index = stopLossIndex;
            percent = stop;
          } else {
            type = "no-profit";
            index = profitOneCheckIndex;
            percent = 0;
          }

          var profitThreeCheckIndex = 0;

          if (
            (item.type == "volume_1" && type == "no-profit") ||
            (item.type == "db_1" && type == "no-profit") ||
            (item.type == "volume_2" && type == "no-profit")
          ) {
            profitThreeCheckIndex = candles.findIndex((candle) =>
              item.status == "buy"
                ? candle.highPrice >= startPrice + startPrice * profit
                : candle.lowPrice <= startPrice - startPrice * profit
            );

            if (profitThreeCheckIndex !== -1) {
              type = "profit-3";
              index = profitThreeCheckIndex;
              percent = profit;
            }
          }

          var profitIndexes = [];
          if (type !== "loss" && type == "volume_3") {
            for (let i = 1; i < candles.length; i++) {
              var percentProfit = (i + 0.5) / 100;

              var profitIndex = candles.findIndex((candle) => {
                const condition =
                  candle.highPrice >= startPrice + startPrice * percentProfit;
                return condition;
              });

              if (profitIndex === -1) {
              } else {
                profitIndexes.push({ index: i, profitIndex, percentProfit });
              }
            }
            index = profitIndexes[profitIndexes.length - 1].profitIndex;
            percent = profitIndexes[profitIndexes.length - 1].index / 100;
            type += "profit-" + profitIndexes[profitIndexes.length - 1].index;
          }

          profitMoneyAmount =
            type == "loss"
              ? profitMoneyAmount - moneyAmount * percent * 20
              : profitMoneyAmount + moneyAmount * percent * 20;
          console.log(
            item.id,
            item.symbolName,
            "stopLoss " + stopLossIndex,
            "profitOneCheckIndex " + profitOneCheckIndex,
            "index " + index,
            "profitThreeCheckIndex " + profitThreeCheckIndex
          );

          backTestDetails.push({
            id: item.id,
            symbolName: item.symbolName,
            spotPrice: item.spotPrice,
            volumeDiff: item.volumeDiff,
            persianDate: item.persianDate,
            startPrice: startPrice,
            stopPrice:
              type == "loss"
                ? startPrice - startPrice * stop
                : startPrice + startPrice * percent,
            status: type,
            position: item.status == "buy" ? "LONG" : "SHORT",
            startDate: startDate,
            stopDate: candles[index].timestamp,
            startDateUnix: candles[index].unix,
            stopDateUnix: candles[index].unix,
            profitMoneyAmount,
          });
        }

        // const idCounts = matchingDensityDetails.reduce((count, box) => {
        //   if (box.id === item.id) {
        //     return count + 1;
        //   }
        //   return count;
        // }, 0);
        // // console.log(idCounts);
        // if (idCounts < 2 && type == "loss") {
        //   const originalDate = new Date(candles[index].timestamp);
        //   const startTimeTransaction = Date.parse(originalDate);
        //   const cryptoPriceFetcher = await BinanceService.getHistoricalPrices(
        //     item.symbolName + "USDT",
        //     "1m",
        //     startTimeTransaction,
        //     startTimeTransaction + 6 * 60 * 60 * 1000
        //   )
        //     .then(async (range) => {
        //       if (range.length > 0) {
        //         const indexToAddAfter = indexItem; // Change this to the desired index

        //         const newItem = {
        //           type: item.type,
        //           outDirections: item.outDirections,
        //           id: item.id,
        //           symbolName: item.symbolName,
        //           status: item.status == "buy" ? "sell" : "buy",
        //           spotPrice: item.spotPrice,
        //           startPrice: item.startPrice,
        //           volumeDiff: item.volumeDiff,
        //           persianDate: item.tehranTime,
        //           symbolVolume: item.symbolVolume,
        //           range,
        //           timestamp: range[0].unix,
        //           startTimeUnix: startTimeTransaction,
        //         };

        //         // Use splice to add the new item after the specified index
        //         matchingDensityDetails.splice(indexToAddAfter + 1, 0, newItem);

        //         await BackTestController.profitCheck(
        //           matchingDensityDetails,
        //           backTestDetails,
        //           moneyAmount,
        //           type,
        //           stop,
        //           profit,
        //           false
        //         );
        //       }
        //     })
        //     .catch((error) => {
        //       console.error("Error:", error);
        //     });
        // }
      } catch (error) {
        console.error(error);
      }
    }
  }

  static async volumeCheck(
    symbolVolumes,
    matchingDensityDetails,
    volume,
    type
  ) {
    for (const symbolVolume of symbolVolumes) {
      const payload = JSON.parse(symbolVolume.payload);
      const spotPrice = symbolVolume.spot_price;
      const symbolStatus = symbolVolume.status;
      const tehranTime = await BackTestController.formatTimestamp(
        symbolVolume.created_at
      );

      const firstItem = payload[0];
      const secondItem = payload[1];

      var status = symbolVolume.status;

      const densityBox = firstItem.densityDetails;
      const minDensityDiffIndex = densityBox.reduce(
        (minIndex, box, currentIndex) => {
          return box.densityDiff >= densityBox[minIndex].densityDiff
            ? currentIndex
            : minIndex;
        },
        0
      );

      const payloadExcepOne = payload.slice(1);
      const countDensityVolumeStatus = payloadExcepOne.reduce((count, box) => {
        if (box.sale === status) {
          return count + 1;
        }
        return count;
      }, 0);
      const twoDensityBox = payload[0].densityDetails.concat(
        payload[1].densityDetails
      );

      const countTwoDensityVolumeStatus = twoDensityBox.reduce((count, box) => {
        if (box.densityBoxStatus !== status) {
          return count + 1;
        }
        return count;
      }, 0);

      var condition = false;
      if (type === "volume_1") {
        const firstCondition =
          minDensityDiffIndex !== 2 &&
          countDensityVolumeStatus >= 1 &&
          countTwoDensityVolumeStatus < 6;

        const secondCondition =
          (firstCondition && parseFloat(symbolVolume.densitydiff) < 900000) ||
          (firstCondition &&
            parseFloat(symbolVolume.densitydiff) > 900000 &&
            parseFloat(symbolVolume.densityboxrate) > 10 &&
            symbolVolume.densityvolumestatus === symbolVolume.status &&
            densityBox[1].densityBoxStatus === symbolVolume.status);

        const thirdCondition =
          (firstCondition && densityBox[1].densityDiff < 900000) ||
          (firstCondition &&
            densityBox[1].densityDiff > 900000 &&
            densityBox[1].densityBoxStatus === symbolVolume.status &&
            densityBox[1].densityVolumeStatus === symbolVolume.status &&
            densityBox[1].densityBoxRate > 10);

        condition = secondCondition && thirdCondition;
      }
      if (type === "db_1" || type === "volume_2") condition = true;
      var outDirections = false;

      if (condition) {
        outDirections = true;

        const originalDate = new Date(symbolVolume.created_at);
        const timestampSeconds = Date.parse(originalDate);

        const sixHoursInMilliseconds = 6 * 60 * 60 * 1000; // 6 hours in milliseconds
        const currentTimestampSeconds =
          timestampSeconds + sixHoursInMilliseconds;

        // // Define your query parameters
        const symbol = symbolVolume.symbol + "USDT";
        const interval = "1m";
        const intervalFive = "5m";
        const startTime = timestampSeconds;
        const endTime = currentTimestampSeconds;

        var startCondition = false;
        var startTimeTransaction = null;
        var startPrice = 0;
        await BinanceService.getHistoricalPrices(
          symbol,
          intervalFive,
          startTime,
          endTime,
          7
        ).then(async (candles) => {
          if (candles.length > 0) {
            const startCandle = candles[0];
            var rangeCandles = candles.slice(1);

            rangeCandles.forEach(async (entry, index) => {
              if (
                (symbolStatus == "buy" &&
                  entry.highPrice > startCandle.highPrice &&
                  !startCondition) ||
                (symbolStatus == "sell" &&
                  entry.lowPrice < startCandle.lowPrice &&
                  !startCondition)
              ) {
                startTimeTransaction = rangeCandles[index + 1]
                  ? rangeCandles[index + 1].unix
                  : null;

                startPrice = parseFloat(rangeCandles[index].price);
                if (startTimeTransaction != null) startCondition = true;
              }
            });

            var range = null;
            // console.log(matchingDensityDetails);
            if (startCondition) {
              const cryptoPriceFetcher =
                await BinanceService.getHistoricalPrices(
                  symbol,
                  interval,
                  startTimeTransaction,
                  startTimeTransaction + 6 * 60 * 60 * 1000
                )
                  .then((prices) => {
                    if (prices.length > 0) {
                      range = prices;
                    }
                  })
                  .catch((error) => {
                    console.error("Error:", error);
                  });

              matchingDensityDetails.push({
                type,
                outDirections,
                id: symbolVolume.id,
                symbolName: symbolVolume.symbol,
                status: status,
                position: symbolVolume.status,
                spotPrice: spotPrice,
                startPrice: startPrice,
                volumeDiff: parseFloat(firstItem.difference),
                persianDate: tehranTime,
                range,
                timestamp: range[0].unix,
                startTimeUnix: startTimeTransaction,
              });
            }
          }
        });
      }
    }
  }

  static async dbVolumeCheck(
    symbolVolumes,
    matchingDensityDetails,
    volume,
    type,
    backTestDetails,
    moneyAmount = 100,
    stop = 0.01,
    profit = 0.03,
    profitSave = true
  ) {
    for (const symbolVolume of symbolVolumes) {
      const spotPrice = symbolVolume.spot_price;
      const tehranTime = await BackTestController.formatTimestamp(
        symbolVolume.created_at
      );

      var status = symbolVolume.status;

      var condition = false;

      const payload = JSON.parse(symbolVolume.payload);
      const twoDensityBox = payload[0].densityDetails.concat(
        payload[1].densityDetails
      );
      const countTwoDensityVolumeStatus = twoDensityBox.reduce((count, box) => {
        if (box.densityBoxStatus !== status) {
          return count + 1;
        }
        return count;
      }, 0);

      if (type === "db_1" && countTwoDensityVolumeStatus <= 6) condition = true;

      if (condition) {
        const originalDate = new Date(symbolVolume.created_at);
        const timestampSeconds = Date.parse(originalDate);

        var range = null;
        const cryptoPriceFetcher = await BinanceService.getHistoricalPrices(
          symbolVolume.symbol + "USDT",
          "1m",
          timestampSeconds,
          timestampSeconds + 6 * 60 * 60 * 1000
        )
          .then((candles) => {
            if (candles.length > 0) {
              let startPrice = candles[0].price;
              let stopLossPrice =
                symbolVolume.status == "buy"
                  ? startPrice - startPrice * stop
                  : startPrice + startPrice * stop;
              let startDate = new Date(symbolVolume.created_at).toLocaleString(
                "en-US",
                {
                  timeZone: "Asia/Tehran",
                  hour12: false,
                  year: "numeric",
                  month: "2-digit",
                  day: "2-digit",
                  hour: "2-digit",
                  minute: "2-digit",
                  hour12: false,
                }
              );
              let startDateUnix = candles[0].unix;

              let index = null;
              let percent = 0;
              let typeProfit = null;
              console.log(
                symbolVolume.symbol,
                backTestDetails.length > 0
                  ? backTestDetails[backTestDetails.length - 1].symbolName
                  : null,
                backTestDetails.length > 0
                  ? backTestDetails[backTestDetails.length - 1].stopDateUnix
                  : null,
                startDateUnix,
                backTestDetails.length > 0 &&
                  backTestDetails[backTestDetails.length - 1].symbolName !=
                    symbolVolume.symbol &&
                  backTestDetails[backTestDetails.length - 1].stopDateUnix <
                    startDateUnix
              );
              if (
                backTestDetails.length == 0 ||
                (backTestDetails.length > 0 &&
                  backTestDetails[backTestDetails.length - 1].symbolName !=
                    symbolVolume.symbol &&
                  backTestDetails[backTestDetails.length - 1].stopDateUnix <
                    startDateUnix)
              ) {
                let profitMoneyAmount =
                  backTestDetails.length > 0
                    ? backTestDetails[backTestDetails.length - 1]
                        .profitMoneyAmount
                    : parseFloat(moneyAmount);

                // Get all elements except the first one
                const candlesForCalculate = candles.slice(1);

                const stopLossIndex = candlesForCalculate.findIndex((candle) =>
                  symbolVolume.status == "buy"
                    ? candle.lowPrice <= stopLossPrice
                    : candle.highPrice >= stopLossPrice
                );

                var profitOneCheckIndex = candlesForCalculate.findIndex(
                  (candle) =>
                    symbolVolume.status == "buy"
                      ? candle.highPrice >= startPrice + startPrice * 0.015
                      : candle.lowPrice <= startPrice - startPrice * 0.015
                );

                if (
                  (stopLossIndex !== -1 && profitOneCheckIndex == -1) ||
                  (stopLossIndex !== -1 &&
                    profitOneCheckIndex !== -1 &&
                    stopLossIndex < profitOneCheckIndex)
                ) {
                  typeProfit = "loss";
                  index = stopLossIndex;
                  percent = stop;
                } else {
                  typeProfit = "no-profit";
                  index = profitOneCheckIndex;
                  percent = 0;
                }

                var profitThreeCheckIndex = 0;

                if (typeProfit == "no-profit") {
                  profitThreeCheckIndex = candles.findIndex((candle) =>
                    symbolVolume.status == "buy"
                      ? candle.highPrice >= startPrice + startPrice * profit
                      : candle.lowPrice <= startPrice - startPrice * profit
                  );

                  if (profitThreeCheckIndex !== -1) {
                    typeProfit = "profit-3";
                    index = profitThreeCheckIndex;
                    percent = profit;
                  }
                }

                var profitIndexes = [];
                if (typeProfit !== "loss" && type == "volume_3") {
                  for (let i = 1; i < candles.length; i++) {
                    var percentProfit = (i + 0.5) / 100;

                    var profitIndex = candles.findIndex((candle) => {
                      const condition =
                        candle.highPrice >=
                        startPrice + startPrice * percentProfit;
                      return condition;
                    });

                    if (profitIndex === -1) {
                      break;
                    } else {
                      profitIndexes.push({
                        index: i,
                        profitIndex,
                        percentProfit,
                      });
                    }
                  }
                  index = profitIndexes[profitIndexes.length - 1].profitIndex;
                  percent = profitIndexes[profitIndexes.length - 1].index / 100;
                  typeProfit +=
                    "profit-" + profitIndexes[profitIndexes.length - 1].index;
                }

                profitMoneyAmount =
                  typeProfit == "loss"
                    ? profitMoneyAmount - moneyAmount * percent * 20
                    : profitMoneyAmount + moneyAmount * percent * 20;
                console.log(
                  symbolVolume.id,
                  symbolVolume.symbol,
                  "stopLoss " + stopLossIndex,
                  "profitOneCheckIndex " + profitOneCheckIndex,
                  "index " + index,
                  "profitThreeCheckIndex " + profitThreeCheckIndex
                );

                backTestDetails.push({
                  id: symbolVolume.id,
                  symbolName: symbolVolume.symbol,
                  spotPrice: symbolVolume.spotPrice,
                  volumeDiff: symbolVolume.difference,
                  persianDate: tehranTime,
                  startPrice: startPrice,
                  stopPrice:
                    typeProfit == "loss"
                      ? startPrice - startPrice * stop
                      : startPrice + startPrice * percent,
                  status: typeProfit,
                  position: symbolVolume.status == "buy" ? "LONG" : "SHORT",
                  startDate: startDate,
                  stopDate: candles[index].unix,
                  startDateUnix: startDateUnix,
                  stopDateUnix: candles[index].unix,
                  profitMoneyAmount,
                });
              }

              // const idCounts = matchingDensityDetails.reduce((count, box) => {
              //   if (box.id === item.id) {
              //     return count + 1;
              //   }
              //   return count;
              // }, 0);
              // // console.log(idCounts);
              // if (idCounts < 2 && type == "loss") {
              //   const originalDate = new Date(candles[index].timestamp);
              //   const startTimeTransaction = Date.parse(originalDate);
              //   const cryptoPriceFetcher = await BinanceService.getHistoricalPrices(
              //     item.symbolName + "USDT",
              //     "1m",
              //     startTimeTransaction,
              //     startTimeTransaction + 6 * 60 * 60 * 1000
              //   )
              //     .then(async (range) => {
              //       if (range.length > 0) {
              //         const indexToAddAfter = indexItem; // Change this to the desired index

              //         const newItem = {
              //           type: item.type,
              //           outDirections: item.outDirections,
              //           id: item.id,
              //           symbolName: item.symbolName,
              //           status: item.status == "buy" ? "sell" : "buy",
              //           spotPrice: item.spotPrice,
              //           startPrice: item.startPrice,
              //           volumeDiff: item.volumeDiff,
              //           persianDate: item.tehranTime,
              //           symbolVolume: item.symbolVolume,
              //           range,
              //           timestamp: range[0].unix,
              //           startTimeUnix: startTimeTransaction,
              //         };

              //         // Use splice to add the new item after the specified index
              //         matchingDensityDetails.splice(indexToAddAfter + 1, 0, newItem);

              //         await BackTestController.profitCheck(
              //           matchingDensityDetails,
              //           backTestDetails,
              //           moneyAmount,
              //           type,
              //           stop,
              //           profit,
              //           false
              //         );
              //       }
              //     })
              //     .catch((error) => {
              //       console.error("Error:", error);
              //     });
              // }
            }
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      }
    }
  }

  static async boxTwoPercentCheck(
    symbolVolumes,
    matchingDensityDetails,
    volume,
    type
  ) {
    for (const symbolVolume of symbolVolumes) {
      const spotPrice = symbolVolume.spot_price;
      const tehranTime = await BackTestController.formatTimestamp(
        symbolVolume.created_at
      );

      const payload = JSON.parse(symbolVolume.payload);
      const firstItem = payload[0];

      const twoDensityBox = payload[0].densityDetails.concat(
        payload[1].densityDetails
      );

      const originalDate = new Date(symbolVolume.created_at);
      const startTimeTransaction = Date.parse(originalDate);

      var status = symbolVolume.status == "buy" ? "sell" : "sell";

      const countTwoDensityVolumeStatus = twoDensityBox.reduce((count, box) => {
        if (box.densityBoxStatus !== symbolVolume.status) {
          return count + 1;
        }
        return count;
      }, 0);

      // console.log(countTwoDensityVolumeStatus);

      // if (countTwoDensityVolumeStatus >= 6) {
      matchingDensityDetails.push({
        type,
        id: symbolVolume.id,
        symbolName: symbolVolume.symbol,
        status: symbolVolume.status,
        spotPrice: spotPrice,
        volumeDiff: symbolVolume.difference,
        persianDate: tehranTime,
      });
      // }
    }
  }

  static async boxCheck(symbolVolumes, matchingDensityDetails) {
    for (const [index, symbolVolume] of symbolVolumes.entries()) {
      const { payload } = symbolVolume;

      // Check if there are at least 2 items in the 'payload' array
      if (payload.length >= 2) {
        const [firstItem, secondItem] = payload;

        // Get the densityVolumeStatus of the first item (assuming there is at least one item)
        const firstDensityVolumeStatus =
          firstItem.densityDetails[0].densityVolumeStatus;

        // Check if all "densityVolumeStatus" values are the same in the "densityDetails" of both items
        const firstDensityVolumeStatusSame = firstItem.densityDetails.every(
          (detail) => detail.densityVolumeStatus === firstDensityVolumeStatus
        );

        if (firstDensityVolumeStatusSame) {
          const secondDensityVolumeStatusSame = secondItem.densityDetails.every(
            (detail) => detail.densityVolumeStatus === firstDensityVolumeStatus
          );

          if (secondDensityVolumeStatusSame) {
            const originalDate = new Date(symbolVolume.createdAt);

            // Set seconds and milliseconds to 0
            const modifiedDate = new Date(originalDate);
            modifiedDate.setSeconds(0);
            modifiedDate.setMilliseconds(0);
            const timestampMilliseconds = Date.parse(modifiedDate);
            const timestampSeconds = timestampMilliseconds;

            const tehranTime = await BackTestController.formatTimestamp(
              symbolVolume.createdAt
            );

            const symbolData = symbolVolume.symbol;

            matchingDensityDetails.push({
              id: symbolVolume.symbolId,
              symbolName: symbolData.symbol,
              spotPrice: symbolVolume.spotPrice,
              volumeDiff: symbolVolume.volumeDiff,
              persianDate: tehranTime,
              startPrice: null, //startPrice,
              stopPrice: null, //stopPrice,
              status: null, //status,
              startDate: null, //startDate,
              stopDate: null, //stopDate,
              startDateUnix: null, //startDateUnix,
              stopDateUnix: null, //stopDateUnix,
              profitMoneyAmount: null, //profitMoneyAmount,
            });
          }
        }
      }
    }
  }

  static async formatTimestamp(timestamp) {
    const tehranTime = moment(timestamp)
      .tz("Asia/Tehran")
      .format("YYYY-MM-DD HH:mm");
    return tehranTime;
  }

  static async usFormatTimestamp(timestamp) {
    const originalDate = new Date(timestamp);
    const formattedDate = originalDate.toLocaleString("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    });
    return formattedDate;
  }
}
