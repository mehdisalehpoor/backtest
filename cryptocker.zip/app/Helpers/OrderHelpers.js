const OrderModel = require("../Models/OrderModel");

class OrderHelpers {
  static async createOrderInDB(
    order,
    userId,
    type,
    status,
    tickSizeNumberOfDecimals,
    leverageNumber,
    parentId = null
  ) {
   const orderInsert = await OrderModel.create({
      symbol: order.symbol,
      orderId: order.orderId,
      userId: userId,
      parentId: parentId,
      origQty: order.origQty,
      price: order.price,
      stopPrice: order.stopPrice,
      tickSizeNumberOfDecimals: tickSizeNumberOfDecimals,
      leverageNumber: leverageNumber,
      side: order.side,
      positionSide: order.positionSide,
      positionSide: order.positionSide,
      status: status,
      type: type,
      exit: false,
    });
    return orderInsert;
  }
}

module.exports = OrderHelpers;
