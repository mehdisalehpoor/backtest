const axios = require("axios");
const ProxyService = require("./ProxyService");

class BTSEService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.btse.com/spot/api/v3.2/orderbook/L2",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}-USDT`,
        depth: 500,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;

    const formattedResponse = {
      asks: orderBook.sellQuote.map((item) => [
        parseFloat(item['price']),
        parseFloat(item['size']),
      ]),
      bids: orderBook.buyQuote.map((item) => [
        parseFloat(item['price']),
        parseFloat(item['size']),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = BTSEService;
