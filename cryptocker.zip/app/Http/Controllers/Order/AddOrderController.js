import { Op } from "sequelize";
import { apiKey } from "../../../../config/configs";
import OrderHelpers from "../../../Helpers/OrderHelpers";
import UserModel from "../../../Models/UserModel";
const TelegramBotService = require("../../../Services/TelegramBotService");
var events = require("events");
var eventEmitter = new events.EventEmitter();
const { MainClient, USDMClient } = require("binance");
export class AddOrderController {
  static convertToPrecision = (precisionNumber, number) => {
    if (String(number).includes(".")) {
      const decimals = String(number).split(".")[1];
      let finalString = "";
      if (decimals.length >= precisionNumber) {
        switch (precisionNumber) {
          case 1:
            finalString = parseInt(String(number).split(".")[0]);
            return finalString;
          default:
            for (let i = 0; i < precisionNumber; i++) {
              finalString += decimals[i];
            }
            return parseFloat(`${String(number).split(".")[0]}.${finalString}`);
        }
      } else {
        return parseFloat(number);
      }
    }
  };

  static getDecimalsPrecision = (number) => {
    if (String(number).includes(".")) {
      return String(String(number).indexOf("1") - 1);
    } else {
      return String(number);
    }
  };

  static setMarginType = async (client, symbol) => {
    try {
      const setMarginType = await client.setMarginType({
        symbol: symbol,
        marginType: "ISOLATED",
        timestamp: new Date().getTime(),
      });

      console.log(setMarginType);
    } catch (error) {
      // console.log(error);
    }
  };

  static setLeverage = async (client, symbol) => {
    let leverage = 20; // Default leverage
    const leverageValues = [20, 15, 10]; // Leverage values to try

    try {
      for (let i = 0; i < leverageValues.length; i++) {
        const leverage_params = {
          symbol: symbol,
          leverage: leverageValues[i],
        };

        await client.setLeverage(leverage_params);

        // If setting leverage succeeds, update the leverage variable and break the loop
        leverage = leverageValues[i];
        break;
      }

      console.log("Leverage set to:", leverage);
      return leverage;
    } catch (error) {
      console.error(error.body);

      // If setting leverage fails, you can add additional error handling or retries here
    }
  };

  static submitNewOrder = async (client, position) => {
    const result = await client.submitNewOrder({
      symbol: position.symbol,
      side: position.side,
      positionSide: position.positionSide,
      type: position.type,
      timeInForce: position.timeInForce,
      quantity: position.quantity,
      price: position.price, // remove 0.001
      timestamp: new Date().getTime(),
    });
    console.log(result);
    return result;
  };

  static positionData(side, condition, price, lastPrice) {
    if (side == "buy") {
      var sideStatus = "BUY";
      var sideProfit = "SELL";
      var positionSide = "LONG";
      if (condition == 1) {
        price = parseFloat(lastPrice) - parseFloat(lastPrice) * 0.004;
        var stopPriceProfif = price + price * 0.01;
        var stopPriceLoss = price - price * 0.01;
      } else if (condition == 2) {
        price = parseFloat(lastPrice) - parseFloat(lastPrice) * 0.004;
        var stopPriceProfif = price + price * 0.01;
        var stopPriceLoss = price - price * 0.01;
      } else if (condition == 3 || condition == 4 || condition == 5) {
        price = parseFloat(lastPrice) - parseFloat(lastPrice) * 0.004;
        var stopPriceProfif = price + price * 0.01;
        var stopPriceLoss = price - price * 0.01;
      }
    } else {
      var sideStatus = "SELL";
      var sideProfit = "BUY";
      var positionSide = "SHORT";
      if (condition == 1) {
        price = parseFloat(lastPrice) + parseFloat(lastPrice) * 0.004;
        var stopPriceProfif = price - price * 0.01;
        var stopPriceLoss = price + price * 0.01;
      } else if (condition == 2) {
        price = parseFloat(lastPrice) + parseFloat(lastPrice) * 0.004;
        var stopPriceProfif = price - price * 0.01;
        var stopPriceLoss = price + price * 0.01;
      } else if (condition == 3 || condition == 4 || condition == 5) {
        price = parseFloat(lastPrice) + parseFloat(lastPrice) * 0.004;
        var stopPriceProfif = price - price * 0.01;
        var stopPriceLoss = price + price * 0.01;
      }
    }
    return { sideStatus, positionSide, sideProfit, stopPriceProfif, price };
  }

  static async handle(req, res, next) {
    try {
      const { symbol, side, condition, userManageMoney } = req.body;
      console.log(req.body);
      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });

      const mainClient = new MainClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });

      // Define the asynchronous functions
      const getAccountInformationPromise = client.getAccountInformation();
      const get24hrChangeStatisticsPromise = mainClient.getSymbolPriceTicker({
        symbol,
      });
      const getExchangeInfoPromise = client.getExchangeInfo();

      // Execute the promises concurrently
      const [accountInformation, changeStatistics, exchangeInfo] =
        await Promise.all([
          getAccountInformationPromise,
          get24hrChangeStatisticsPromise,
          getExchangeInfoPromise,
        ]);

      AddOrderController.setMarginType(client, symbol);
      const leverageNumber = await AddOrderController.setLeverage(
        client,
        symbol
      );
      const symbolExchangeData = exchangeInfo.symbols.find(
        (x) => x.symbol === symbol
      );
      const tickSizeNumberOfDecimals = parseInt(
        AddOrderController.getDecimalsPrecision(
          symbolExchangeData.filters[0].tickSize
        )
      );

      const usdtAsset = accountInformation.assets.find(
        (asset) => asset.asset === "USDT"
      );

      // Extract the asset value
      const usdtValue = usdtAsset.walletBalance;

      const lastPrice = changeStatistics.price;

      const user = await UserModel.findOne({
        where: {
          id: apiKey.userId,
        },
      });

      // if (user.balance == null)
        UserModel.update(
          {
            balance: Math.floor(parseFloat(usdtAsset.walletBalance)),
          },
          {
            where: {
              id: apiKey.userId,
            },
          }
        );

      let price = 0;
      var sideStatus;
      var positionSide;
      var sideProfit;
      var stopPriceProfif;
      ({ sideStatus, positionSide, sideProfit, stopPriceProfif, price } =
        AddOrderController.positionData(side, condition, price, lastPrice));

      const manageMoney =
        user.balance == null ||
        (user.balance != null && user.balance > parseFloat(usdtValue))
          ? user.marginPerOrder
          : parseFloat(usdtValue) - user.balance + user.marginPerOrder;

      const qty = (manageMoney / price) * parseFloat(leverageNumber);

      const precision = 0;
      const roundedQty = Number(qty.toFixed(precision));
      const priceOrder = Number(price.toFixed(tickSizeNumberOfDecimals));

      const openPosition = {
        symbol: symbol,
        side: sideStatus,
        positionSide: positionSide,
        type: "LIMIT",
        timeInForce: "GTC",
        quantity: roundedQty,
        price: priceOrder, // remove 0.001
        timestamp: new Date().getTime(),
      };

      console.log(openPosition);

      var newOrder = null;

      const submitNewOrder = await client
        .submitNewOrder(openPosition)
        .then((result) => {
          newOrder = result;
          console.log("order created");
          OrderHelpers.createOrderInDB(
            newOrder,
            apiKey.userId,
            "NEW",
            "NEW",
            tickSizeNumberOfDecimals,
            leverageNumber
          );
        });

      res.send({
        newOrder,
        time: new Date().getTime(),
      });
    } catch (error) {
      console.error(error);
    }
  }

  static async addOrder(req, res, next) {
    try {
      const { symbol, side, type, positionSide, quantity, price, stopPrice } =
        req.body;

      const takeProfit = {
        symbol: symbol,
        side: side,
        positionSide: positionSide,
        type: type,
        quantity: quantity,
        stopPrice: stopPrice,
        price: price,
        timestamp: new Date().getTime(),
      };
      console.log(takeProfit);
      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });
      var newOrder = null;
      const submitNewOrder = await client
        .submitNewOrder(takeProfit)
        .then((result) => {
          newOrder = result;
        });

      res.send(newOrder);
    } catch (error) {
      console.error(error);
    }
  }
}
