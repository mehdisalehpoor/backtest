import SenderHelper from "../Helpers/SenderHelper";

class Event extends SenderHelper {
  constructor(io, socket, event, data) {
    super(io);
    this.socket = socket;
    this.event = event;
    this.data = data;
  }
}

export default Event;
