const axios = require("axios");
const ProxyService = require("./ProxyService");

class BitForexService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.bitforex.com/api/v1/market/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `coin-usdt-${symbol.toLowerCase()}`,
        size: 200,
      },
      httpsAgent: agent,
    });
    const orderBook = orderBookResponse.data.data;
    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item.price),
        parseFloat(item.amount),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item.price),
        parseFloat(item.amount),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = BitForexService;
