import express from "express";
import { BackTestController } from "../../../app/Http/Controllers/BackTest/BackTestController";

const backTestRouter = express.Router();

//  @desc   Get Back Test
//  @route  GET /backtest/
backTestRouter.post("/", BackTestController.handle);

module.exports = backTestRouter;
