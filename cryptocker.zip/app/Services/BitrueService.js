const axios = require("axios");
const ProxyService = require("./ProxyService");

class BitrueService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://www.bitrue.com/api/v1/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}USDT`,
        limit: 200,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;
    
    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = BitrueService;
