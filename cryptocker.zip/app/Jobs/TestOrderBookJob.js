const TooBitService = require("../Services/ToobitService");
const WhiteBitService = require("../Services/WhiteBitService");
const BitGetService = require("../Services/BitGetService");
const BitForexService = require("../Services/BitForexService");
const CoinBaseService = require("../Services/CoinBaseService");
const XTService = require("../Services/XTService");
const BingxService = require("../Services/BingxService");
const MexcService = require("../Services/MexcService");
const { Op } = require("sequelize");
const ccxt = require("ccxt");
const SymbolModel = require("../Models/SymbolModel");
const KucoinService = require("../Services/KucoinService");
const SymbolExchangeModel = require("../Models/SymbolExchangeModel");
const BinanceService = require("../Services/BinanceService");
const GateService = require("../Services/GateService");
const BinanceUSService = require("../Services/BinanceUSService");
const HotcoinService = require("../Services/HotcoinService");
const axios = require("axios");
const TelegramBotService = require("../Services/TelegramBotService");
const DigiFinexService = require("../Services/DigiFinexService");
const LBankService = require("../Services/LBankService");
const OKXService = require("../Services/OKXService");
const CoinexService = require("../Services/CoinexService");
const LATokenService = require("../Services/LATokenService");
const BitmartService = require("../Services/BitmartService");
const HuobiService = require("../Services/HuobiService");
const PoloniexService = require("../Services/PoloniexService");
const BitrueService = require("../Services/BitrueService");
const TokoCryptoService = require("../Services/TokoCryptoService");
const ProbitService = require("../Services/ProbitService");
const BybitService = require("../Services/BybitService");
const OrderbookHelpers = require("../Helpers/OrderbookHelpers");
const DeepCoinService = require("../Services/DeepCoinService");
const OrangXService = require("../Services/OrangXService");
const FameExService = require("../Services/FameExService");
const BinanceTrService = require("../Services/BinanceTrService");
const PionexService = require("../Services/PionexService");
const BitvenusService = require("../Services/BitvenusService");

const args = process.argv;

const processChunk = async (chunk) => {
  var volume = false;
  if (args.includes("--volume")) {
    volume = true;
  }

  const response = [];
  const binanceAPI = "https://api.binance.com/api/v3/ticker/price";
  for (const symbol of chunk) {
    try {
      const exchangesData = await SymbolExchangeModel.findAll({
        where: { symbolId: symbol.id },
        include: [
          {
            association: "exchange",
          },
        ],
      });

      const exchanges = [];

      // Iterate through the data array and collect ccxtName values
      exchangesData.forEach((item) => {
        const ccxtName = item.exchange.ccxtName;
        const exchangeId = item.exchange.exchangeId;
        exchanges.push({ ccxtName, exchangeId });
      });
      var spotPrice = null;
      if (symbol.exchangeTicker) {
        if (symbol.exchangeTicker == "mexc") {
          spotPrice = await MexcService.getTicker(`${symbol.symbol}_USDT`);
        }
      } else {
        const spotPriceData = await axios.get(binanceAPI, {
          params: { symbol: `${symbol.symbol}USDT` },
        });
        spotPrice = parseFloat(spotPriceData.data.price);
      }

      const exchangeSuccessFull = [];
      const promises = await getExchangeOrderBook(
        exchanges,
        symbol.symbol,
        exchangeSuccessFull
      );

      const resultsExchanges = await Promise.all(promises).then(
        async (results) => {
          const asks = results
            .filter(
              (item) =>
                item &&
                item.orderBook &&
                item.orderBook.asks &&
                item.orderBook.asks.length > 0
            )
            .flatMap((item) => item.orderBook.asks);
          const bids = results
            .filter(
              (item) =>
                item &&
                item.orderBook &&
                item.orderBook.bids &&
                item.orderBook.bids.length > 0
            )
            .flatMap((item) => item.orderBook.bids);

          const box =
            await OrderbookHelpers.futuresFifteenBoxEnterSignalOrderbook(
              exchangeSuccessFull,
              symbol.symbol,
              symbol.id,
              { asks, bids },
              spotPrice,
              10,
              2,
              4.5,
              volume,
              true,
              "spot"
            );
          response.push({
            symbol: symbol.symbol,
            spotPrice: spotPrice,
            orderBook: { asks, bids },
            box,
          });
        }
      );
    } catch (error) {}
  }
  return response;
};

const handleFuturesSymbolsCheck = async (volume) => {
  const symbols = await SymbolModel.findAll({
    where: {
      futures: true,
      exchangeVolume: {
        [Op.gte]: 90,
      },
    },
  });

  const chunkSize = 4;

  const symbolChunks = [];

  for (let i = 0; i < symbols.length; i += chunkSize) {
    symbolChunks.push(symbols.slice(i, i + chunkSize));
  }

  const processChunkPromise = [];
  for (const chunk of symbolChunks) {
    processChunkPromise.push(processChunk(chunk));
  }

  const data = await Promise.all(processChunkPromise);
  return data;
};

const fetchOrderBook = async (exchange, symbol, exchanges) => {
  try {
    let result;

    switch (exchange.ccxtName) {
      case "kucoin":
        // const kucoin = new KucoinService();
        // result = await kucoin.getOrderBook(symbol);
        const ccxtKucoin = new ccxt[exchange.ccxtName]();
        const responseKucoin = await ccxtKucoin.fetchL2OrderBook(
          `${symbol}/USDT`
        );
        const formattedResponseKucoin = {
          asks: responseKucoin.asks.map((item) => [
            parseFloat(item[0]),
            parseFloat(item[1]),
          ]),
          bids: responseKucoin.bids.map((item) => [
            parseFloat(item[0]),
            parseFloat(item[1]),
          ]),
        };
        result = formattedResponseKucoin;
        break;

      case "mexc":
        result = await MexcService.getOrderbook(`${symbol}_USDT`);
        break;

      case "bingx":
        const bingxService = new BingxService(`${symbol}-USDT`);
        result = await bingxService.main();
        break;

      case "hotcoin":
        result = await HotcoinService.getOrderbook(symbol);
        break;

      case "coinex":
        result = await CoinexService.getOrderbook(symbol);
        break;

      case "bitvenus":
        result = await BitvenusService.getOrderBook(symbol);
        break;

      case "bybit":
        result = await BybitService.getOrderbook(symbol);
        break;

      case "binance":
        result = await BinanceService.getOrderbook(`${symbol}USDT`);
        break;

      case "binance-us":
        const responseBinanceUS = await BinanceUSService.getOrderbook(
          `${symbol}USDT`
        );
        result = responseBinanceUS;
        break;

      case "gate":
        result = await GateService.getOrderbook(`${symbol}_USDT`);
        break;

      case "bitget":
        result = await BitGetService.getOrderBook(symbol);
        break;

      case "bitforex":
        result = await BitForexService.getOrderBook(symbol);
        break;

      case "lbank":
        result = await LBankService.getOrderBook(symbol);
        break;

      case "digifinex":
        result = await DigiFinexService.getOrderBook(symbol);
        break;

      case "xt":
        result = await XTService.getOrderBook(symbol);
        break;

      case "okx":
        result = await OKXService.getOrderBook(symbol);
        break;

      case "coinex":
        result = await CoinexService.getOrderBook(symbol);
        break;

      case "coinbase":
        result = await CoinBaseService.getOrderBook(symbol);
        break;

      case "latoken":
        result = await LATokenService.getOrderBook(symbol);
        break;

      case "bitmart":
        result = await BitmartService.getOrderBook(symbol);
        break;

      case "huobi":
        result = await HuobiService.getOrderBook(symbol);
        break;

      case "whitebit":
        result = await WhiteBitService.getOrderBook(symbol);
        break;

      case "deepcoin":
        result = await DeepCoinService.getOrderBook(symbol);
        break;

      case "orangex":
        result = await OrangXService.getOrderBook(symbol);
        break;

      case "bitrue":
        result = await BitrueService.getOrderBook(symbol);
        break;

      case "poloniex":
        result = await PoloniexService.getOrderBook(symbol);
        break;

      case "tokocrypto":
        result = await TokoCryptoService.getOrderBook(symbol);
        break;

      case "toobit":
        result = await TooBitService.getOrderBook(symbol);
        break;

      case "binance-tr":
        result = await BinanceTrService.getOrderBook(symbol);
        break;

      case "fameex":
        result = await FameExService.getOrderBook(symbol);
        break;

      case "pionex":
        result = await PionexService.getOrderBook(symbol);
        break;

      case "probit":
        result = await ProbitService.getOrderBook(symbol);
        break;

      default:
        const exchangeDefault = new ccxt[exchange.ccxtName]();
        const responseExchange = await exchangeDefault.fetchL2OrderBook(
          `${symbol}/USDT`
        );
        const formattedResponseExchange = {
          asks: responseExchange.asks.map((item) => [
            parseFloat(item[0]),
            parseFloat(item[1]),
          ]),
          bids: responseExchange.bids.map((item) => [
            parseFloat(item[0]),
            parseFloat(item[1]),
          ]),
        };
        result = formattedResponseExchange;
        break;
    }

    exchanges.push(exchange); // Only push when there is no error
    return result;
  } catch (error) {
    // console.log(error);
    var message = symbol + " " + exchange.ccxtName + " " + error;
    TelegramBotService.futuresSignalSend(
      "fetchOrderBook In OrderBookJob " + message
    );
  }
};

const getExchangeOrderBook = async (exchanges, symbol, exchangeSuccessFull) => {
  const results = await Promise.all(
    exchanges.map((exchangeId) =>
      fetchOrderBook(exchangeId, symbol, exchangeSuccessFull)
    )
  );
  return results.map((orderBook, index) => ({
    exchangeId: exchanges[index],
    orderBook,
  }));
};

export const runFuturesSymbolsCheckJob = async () => {
  try {
    const data = await handleFuturesSymbolsCheck();
    return data;
  } catch (error) {
    TelegramBotService.futuresSignalSend("OrderBookJob " + error);
  }
};
