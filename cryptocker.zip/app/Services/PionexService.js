const axios = require("axios");
const ProxyService = require("./ProxyService");

class PionexService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.pionex.com/api/v1/market/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}_USDT`,
        limit: 1000,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = PionexService;
