const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://open-api.bingx.com/openApi/spot/v2/",
        symbol: baseSymbol + "-" + quoteSymbol,
        exchange: "bingx",
        // https://open-api.bingx.com/openApi/spot/v2/market/kline?symbol=BTC-USDT&interval=1d&limit=1000&timestamp=1503619200000
       
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            const params = {
                symbol: symbol,
                interval: timeframe,
                // timestamp:
                startTime: startTime * 1000,
                endTime: endTime * 1000
            };

            const response = await axios.get(url + "klines", { params });
            const data = response.data;

            return data.map(kline => ([
                kline[0],//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
