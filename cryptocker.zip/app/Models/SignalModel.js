const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const SignalModel = sequelize.define(
  "signals",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbol: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    spotPrice: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    orderId: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    futuresPrice: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    exitFuturesPrice: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    percentageIncrease: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    profit: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    signalStatus: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    payload: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    exchangesVolume: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    signalType: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    type: {
      type: DataTypes.ENUM(["FUTURES", "SPOT"]),
      defaultValue: "FUTURES",
      allowNull: false,
    },
    checkCount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    exitCount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    exit: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

module.exports = SignalModel;
