class SenderHelper {
  constructor(io, socket) {
    this.io = io;
    this.socket = socket;
  }

  // send message to one user with client id
  async send(clientId, event, data) {
    this.io.to(clientId).emit(event, data);
  }

  // send message to all users
  async sendToAll(event, data) {
    this.io.emit(event, data);
  }
}

export default SenderHelper;
