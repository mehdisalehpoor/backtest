const axios = require("axios");
const ProxyService = require("./ProxyService");

class DigiFinexService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://openapi.digifinex.com/v3/order_book",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol.toLowerCase()}_usdt`,
        limit: 5000,
      },
      httpsAgent: agent,
    });
    const orderBook = orderBookResponse.data;

    return orderBook;
  }
}

module.exports = DigiFinexService;
