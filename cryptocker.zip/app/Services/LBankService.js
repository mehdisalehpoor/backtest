const axios = require("axios");
const ProxyService = require("./ProxyService");

class LBankService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.lbkex.com/v2/depth.do",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol.toLowerCase()}_usdt`,
        size: 60,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = LBankService;
