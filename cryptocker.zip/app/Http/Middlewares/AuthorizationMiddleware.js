import JwtService from "../../Services/JwtService";

class AuthorizationMiddleware {
  static async handle(req, res, next) {
    const { authorization: useToken } = req.headers;
    const token = useToken.split(" ")[1]; //Bearer Token => ['Bearer', token]
    try {
      req.decodedToken = JwtService.verify(token);
      next();
    } catch (err) {
      next(err);
    }
  }
}

export default AuthorizationMiddleware;
