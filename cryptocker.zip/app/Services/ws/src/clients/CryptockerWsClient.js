const WebSocketClient = require("./WebSocketClient");

class CryptockerWsClient {
  constructor(config) {
    this.config = config;
    this.symbol = config.symbol;
    this.wsClient = new WebSocketClient(config);
  }
}

module.exports = CryptockerWsClient;
