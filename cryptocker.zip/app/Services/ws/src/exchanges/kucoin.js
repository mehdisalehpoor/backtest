const axios = require("axios");

const fetchKucoinToken = async () => {
  try {
    const response = await axios.post(
      "https://api.kucoin.com/api/v1/bullet-public"
    );
    return response.data.data.token;
  } catch (error) {
    throw new Error("Error fetching KuCoin token: " + error.message);
  }
};

const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "-" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "kucoin",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws-api-spot.kucoin.com/?token=${await fetchKucoinToken()}`,
    getSubscribeMessage: (symbol) => {
      return {
        type: "subscribe",
        topic: `/market/level2:${symbol}`,
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.changes?.asks || [];
      const bids = message?.data?.changes?.bids || [];
      return { asks, bids };
    },
  };
};
