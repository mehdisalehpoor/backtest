const calculateTotalValue = (data) => {
  return data.reduce((total, [price, size]) => total + price * size, 0);
};

module.exports = calculateTotalValue;
