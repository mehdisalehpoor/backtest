const SymbolModel = require("../Models/SymbolModel");
const axios = require("axios");
const TelegramBotService = require("../Services/TelegramBotService");
const UserModel = require("../Models/UserModel");

const runMarginTypeJob = async () => {
  try {
    // Find all active users
    const users = await UserModel.findAll({
      where: {
        status: true,
      },
    });

    // Iterate over each user
    for (const user of users) {
      // Find all symbols
      const symbols = await SymbolModel.findAll();

      // Iterate over each symbol
      for (const symbol of symbols) {
        try {
          const apiUrl = `http://${user.ip}:3013/v1/symbol/margin`;

          // Prepare request body
          const requestBody = {
            symbol: symbol.symbol + "USDT",
            marginType: "ISOLATED",
          };

          // Send POST request to set margin type
          const response = await axios.post(apiUrl, requestBody);
          console.log(response.data); // Log response data

          // You might want to do something with the response data here
        } catch (error) {
          console.error(error.response.data);
          // Handle the error, maybe notify the user or log it somewhere
        }
      }
    }

    return users; // Return the users after the job is done
  } catch (error) {
    console.error("Error occurred in runMarginTypeJob:", error.message);
    // Send error message to TelegramBotService
    TelegramBotService.futuresSignalSend("runMarginTypeJob " + error);
  }
};

// Invoke the runJob function to start the recurring execution
runMarginTypeJob();
