const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "-" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "coinbase-exchange",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws-feed.exchange.coinbase.com`,
    getSubscribeMessage: (symbol) => {
      return {
        type: "subscribe",
        channels: ["level2"],
        product_ids: [symbol],
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.[0]?.asks || [];
      const bids = message?.data?.[0]?.bids || [];
      return { asks, bids };
    },
  };
};
