const axios = require("axios");
// const ProxyService = require("./ProxyService");
const { WebSocket } = require("ws");
const RedisClientService = require("./RedisClientService");

class BinanceService {
  static async getOrderbook(symbol) {
    try {
      const axiosClient = axios.create({
        baseURL: "https://api.binance.com/api/v3/depth",
      });
      // const agent = await ProxyService.getProxyAddress();
      const response = await axiosClient.get("", {
        params: {
          symbol: `${symbol}`,
          limit: 5000,
        },
        // httpsAgent: agent,
      });

      const formattedResponse = {
        asks: response.data.asks.map((item) => [
          parseFloat(item[0]),
          parseFloat(item[1]),
        ]),
        bids: response.data.bids.map((item) => [
          parseFloat(item[0]),
          parseFloat(item[1]),
        ]),
      };
      return formattedResponse;
    } catch (error) {
      console.error(error);
    }
  }

  static async getFuturesSymbols() {
    // Binance API base URL
    const baseURL = "https://fapi.binance.com/fapi/v1/exchangeInfo";
    // Create a request to get all futures symbols
    // const agent = await ProxyService.getProxyAddress();

    const axiosClient = axios.create({
      baseURL: baseURL,
    });

    const binanceResponse = await axiosClient.get("", {
      // httpsAgent: agent,
    });

    return binanceResponse;
  }

  static async getSpotSymbols() {
    // Binance API base URL
    const baseURL = "https://api.binance.com/api/v3/exchangeInfo";
    // Create a request to get all futures symbols
    // const agent = await ProxyService.getProxyAddress();

    const axiosClient = axios.create({
      baseURL: baseURL,
    });

    const binanceResponse = await axiosClient.get("", {
      // httpsAgent: agent,
    });

    const symbols = binanceResponse.data.symbols.filter(
      cmcSymbol => cmcSymbol.quoteAsset === "USDT"
  );
  
    return symbols;
  }

  static async getFuturesPrice(symbol) {
    const binanceAPI = "https://fapi.binance.com/fapi/v1/ticker/price";

    // const agent = await ProxyService.getProxyAddress();

    const axiosClient = axios.create({
      baseURL: binanceAPI,
    });
    const futuresPriceData = await axiosClient.get("", {
      params: {
        symbol: `${symbol}USDT`,
      },
      // httpsAgent: agent,
    });

    return parseFloat(futuresPriceData.data.price);
  }

  static async getSpotPrice(symbol) {
    const binanceAPI = "https://api.binance.com/api/v3/ticker/price";

    // const agent = await ProxyService.getProxyAddress();

    const axiosClient = axios.create({
      baseURL: binanceAPI,
    });
    const futuresPriceData = await axiosClient.get("", {
      params: {
        symbol: `${symbol}USDT`,
      },
      // httpsAgent: agent,
    });

    return parseFloat(futuresPriceData.data.price);
  }

  static async getHistoricalPrices(
    symbol,
    interval,
    startTime,
    endTime,
    limit = 1000
  ) {
    const apiUrl = "https://fapi.binance.com/fapi/v1/klines";
    const queryParams = {
      symbol,
      interval,
      startTime,
      endTime,
      limit,
    };
    // const headers = {
    //   'X-MBX-APIKEY': this.apiKey,
    // };

    try {
      const response = await axios.get(apiUrl, { params: queryParams }); //, headers });

      if (response.data.length > 0) {
        const prices = response.data.map((candlestick) => {
          // console.log(candlestick);
          const timestamp = new Date(candlestick[0]);
          const unix = candlestick[0];
          const closeUnix = candlestick[6];
          const price = parseFloat(candlestick[4]);
          const openPrice = parseFloat(candlestick[1]);
          const highPrice = parseFloat(candlestick[2]);
          const lowPrice = parseFloat(candlestick[3]);

          return {
            timestamp,
            price,
            openPrice,
            highPrice,
            lowPrice,
            unix,
            closeUnix,
          };
        });

        return prices;
      } else {
        console.log("No data found for the specified time range.");
        return [];
      }
    } catch (error) {
      console.error("Error fetching futures data:", error);
      throw error;
    }
  }

  static async wsTrade(symbolPair) {
    const ws = new WebSocket(
      `wss://stream.binance.com:9443/ws/${symbolPair}@trade`
    );

    ws.on("open", () => {
      console.log(
        `Connected to Binance WebSocket server for ${symbolPair} order book updates`
      );
    });

    ws.on("message", async (data) => {
      const message = JSON.parse(data);

      const price = parseFloat(message.p);
     
      const redis = new RedisClientService();
      redis
        .set(`${symbolPair}_price`, price)
        .then(async () => {})
        .catch((err) => {
          console.error("Error:", err);
        });
    });

    ws.on("error", (error) => {
      console.error(`WebSocket error for ${symbolPair}:`, error);
    });

    ws.on("close", () => {
      console.log(
        `Disconnected from Binance WebSocket server for ${symbolPair} order book updates`
      );
    });

    return ws;
  }
}

module.exports = BinanceService;
