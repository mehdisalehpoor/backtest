import { IsTypingEvent, SendPrivateMessage } from "../Events";
import ExchangeOrderBookEvent from "../Events/ExchangeOrderBookEvent";
import Router from "../Libraries/SocketRouter";
import { IsTypingValidation, SendMessageValidation } from "../Validations";

const route = new Router();

route.register("send_private_message", SendPrivateMessage).middleware(SendMessageValidation).namespace("all");
route.register("is_typing", IsTypingEvent).middleware(IsTypingValidation);
route.register("exchange_orderbook", ExchangeOrderBookEvent);

export default route;
