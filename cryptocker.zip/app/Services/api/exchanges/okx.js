const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://www.okx.com/api/v5/market/",
        symbol: baseSymbol + quoteSymbol,
        exchange: "okx",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {

            let type = "1d";
            if(timeframe == "1d"){
                bar = "1Dutc";
            }
            const params = {
                instId: symbol,
                bar: timeframe,
                after: startTime * 1000,
                before: endTime * 1000,
                // limit: 300,
            };

            const response = await axios.get(url + "klines", { params });
            const data = response.data;

            return data.map(kline => ([
                kline[0],//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
