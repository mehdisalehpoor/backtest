const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "bitvenus",
    symbol: await fixSymbolName(symbol),
    url: `wss://wsapi.bitvenus.me`,
    getSubscribeMessage: (symbol) => {
      return {
        symbol: symbol,
        topic: "depth",
        event: "sub",
        params: {
          binary: false,
        },
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.a || [];
      const bids = message?.data?.b || [];
      return { asks, bids };
    },
  };
};
