const BinanceService = require('../Services/BinanceService');
const fs = require('fs');
const { exchangeModules, loadExchangeConfig } = require('../Services/api/exchanges');
const TelegramBotService = require("../Services/TelegramBotService");
const CoinmarketcapHelpers = require("../Helpers/CoinmarketcapHelpers");
const { symbol } = require('joi');
const { RSI } = require('technicalindicators');

const runVolumeJob = async () => {
    try {
        // Create a request to get all futures symbols
        const [kucoinResponse, coinmarketcapResponse] = await Promise.all([
            BinanceService.getSpotSymbols(),
            CoinmarketcapHelpers.coinmarketcapFilterSymbolsList("binance"),
        ]);

        // const usdtSymbols = kucoinResponse.map(symbolInfo => symbolInfo.symbol);

        const usdtSymbols = [
            "BTC"
            //  "SXP",
            //     // "POLX",
            //     // "AI",
            //     //  "FTG",
            //     // "VXV",
            //     // "MJT",
            //     // "RBP",
            //     // "SRBP",
            //     // "FT",
            //     // "HIENS4",
            //     // "HIENS3",
            //     // "MC",
            //     // "HIODBS",
            //     // "PIX",
            //     // "GEM",
            //     //"BEAT",
            //     //  "HIFLUF",
            //     // "HIBIRDS",
            //     // "HIMFERS",
            //     // "HIUNDEAD",
            //     // "HIFRIENDS",
            //     // "HISEALS",
            //     // "HIBEANZ",
            //     // "OTK",
            //     // "HIBAKC",
            //     // "VERSE",
            //     // "MM",
            //     // "UQC",
            //     // "TUNE",
            // "FORTH"
        ];

        const coinmarketcapSymbols = coinmarketcapResponse.data.marketPairs;
        const data = [];

        for (const symbol of usdtSymbols) {
            try {

                await new Promise(resolve => setTimeout(resolve, 2000));
                const symbolWithoutUsdt = makeSymbolNameWithoutUsdt(symbol);

                const cmcSymbol = coinmarketcapSymbols.find(
                    cmcSymbol => cmcSymbol.baseSymbol === symbolWithoutUsdt && cmcSymbol.quoteSymbol === "USDT"
                );

                if (!cmcSymbol) continue;

                const config = await loadExchangeConfig(cmcSymbol.baseCurrencySlug);
                const { exchanges } = await CoinmarketcapHelpers.coinmarketcapCalculate(
                    cmcSymbol.baseCurrencySlug,
                    []
                );

                console.log(cmcSymbol.baseCurrencySlug);

                const filteredExistsExchangesUsdt = exchanges.filter(exchange =>
                    exchange.quoteSymbol === "USDT"
                    && exchange.exchangeSlug !== "binance-th"
                );

                const filteredExistsExchanges = filteredExistsExchangesUsdt.filter(exchange =>
                    Object.keys(exchangeModules).some(myExchange => myExchange === exchange.exchangeSlug.split('-')[0])
                );
                
                const percentageExists = (filteredExistsExchanges.length / filteredExistsExchangesUsdt.length) * 100;

                if (percentageExists < 5) {
                    console.log(
                        symbolWithoutUsdt,
                        "filteredExistsExchangesUsdt " + filteredExistsExchangesUsdt.length,
                        "filteredExistsExchanges " + filteredExistsExchanges.length,
                        "percentageExists", percentageExists.toFixed(0)
                    );
                    continue;
                }

                const exchangesCandles = [];
                await getCandleData(filteredExistsExchanges, exchangesCandles);
                
                const binanceCandles = await getBinanceData(exchangesCandles);

                // console.log(binanceCandles[0][binanceCandles[0].length - 2]);

                data.push(await analyzeVolume(await sum(exchangesCandles), binanceCandles[0]));
                // data.push(await sum(exchangesCandles));
                // data.push(exchangesCandles);
                // const volume = await sumIndexTwo(data[0]);

                const filePath = 'symbols\\' + symbol + '.json';
                const rsiFilePath = 'symbols\\rsi\\' + symbol + '.json';

                fs.writeFileSync(filePath, JSON.stringify(data[0], null, 2)); // The second parameter is for pretty-printing the JSON
                fs.writeFileSync(rsiFilePath, JSON.stringify(binanceCandles[0], null, 2)); // The second parameter is for pretty-printing the JSON

            } catch (error) {
                console.error(symbol.baseSymbol, error);
            }
        }
        // const filePath = 'data.json'
        return data;
    } catch (error) {
        console.error(error);
        TelegramBotService.futuresSignalSend(error.message);
    }
};

const getBinanceData = (data) => {
    return data.map(innerArray => {
        return innerArray.filter(entry => entry[3].toLowerCase() === 'binance');
    }).filter(innerArray => innerArray.length > 0);
}

const sumIndexTwo = (dataArray) => {
    return dataArray.reduce((sum, current) => {
        return sum + current[2]; // Index 2 is where the value to sum is located
    }, 0);
};

const sum = (candleData) => {
    const combinedData = candleData.flat();
    combinedData.sort((a, b) => new Date(a[0]) - new Date(b[0]));

    const now = new Date();
    now.setHours(0, 0, 0, 0); // Set to midnight
    const midnightTimestampNow = now.getTime(); // Get today's midnight timestamp

    const result = combinedData.reduce((acc, current) => {
        const date = current[0];
        const volume = Number(current[2]);
        const symbol = current[1];
        const closePrice = current[5];
        const highPrice = current[6];

        // Check if the date is not today's date
        if (new Date(date).getTime() < midnightTimestampNow) {
            if (acc[date]) {
                acc[date].volume += volume;
            } else {
                acc[date] = { date, symbol, volume, closePrice, highPrice };
            }
        }

        return acc;
    }, {});

    // Create an array from the result object
    const finalResult = Object.keys(result).map(date => [
        date,
        result[date].symbol,
        result[date].volume,
        result[date].closePrice,
        result[date].highPrice
    ]);

    // Sort the final result by date
    finalResult.sort((a, b) => new Date(a[0]) - new Date(b[0]));

    return finalResult;
};


const analyzeVolume = async (combinedData, binanceCandles) => {
    console.log(combinedData);
    let maxPrice = combinedData[0][4];
    for (let i = 1; i < combinedData.length; i++) {
        if (combinedData[i][4] > maxPrice) {
            maxPrice = combinedData[i][4];
        }
    }

    combinedData.forEach(row => {
        row.timestamp = new Date(row[0]);
        row.symbol = row[1];
        row.volume = parseFloat(row[2]);
        row.ClosePrice = parseFloat(row[3]);
        row.MaxPrice = parseFloat(maxPrice);
    });

    let cumulativeSumVolume = 0;
    const response = [];

    for (let i = 0; i < combinedData.length; i++) {
        cumulativeSumVolume += combinedData[i].volume;
        const cumulativeAvgVolume = cumulativeSumVolume / (i + 1);

        // if (combinedData[i].volume > 3 * cumulativeAvgVolume) {
        // if (
            // combinedData[i].ClosePrice < combinedData[i].MaxPrice - combinedData[i].MaxPrice * 85 / 100 &&
            // combinedData[i].volume > 2 * cumulativeAvgVolume
            // combinedData[i].volume > 1.5 * cumulativeAvgVolume && combinedData[i].volume <= 3.7 * cumulativeAvgVolume
            // && 
            // combinedData[i].volume <= cumulativeAvgVolume - cumulativeAvgVolume * 17 / 100
        // ) {

            const rate = parseFloat(combinedData[i].volume) / parseFloat(cumulativeAvgVolume);

            const rateBeforeVolume = response.length == 0 ? 0 : parseFloat(combinedData[i].volume) / parseFloat(response[response.length - 1].Volume);

            const index = binanceCandles.findIndex(entry => entry[0] === combinedData[i][0]);

            const dataBeforeIndex = binanceCandles.slice(0, index + 1);

            const closingPrices = dataBeforeIndex.map(candle => parseFloat(candle[7]));

            const rsiValues = await calculateRSI(closingPrices);

            response.push({
                Date: combinedData[i].timestamp,
                Symbol: combinedData[i].symbol + "USDT",
                Volume: combinedData[i].volume,
                SumVolume: cumulativeSumVolume,
                AverageVolume: cumulativeAvgVolume,
                RateAverageVolume: rate.toFixed(2),
                rsi: rsiValues[rsiValues.length - 1]

                //     RateBeforeAverageVolume: rateBeforeVolume.toFixed(2),
                //     BeforeVolume: response.length == 0 ? 0 : response[response.length - 1].Volume,
                //     ClosePrice: combinedData[i].ClosePrice,
                //     MaxPrice: combinedData[i].MaxPrice
            });
        // }
    }

    return response;
}

/**
 * Converts a Unix timestamp to a human-readable date.
 * 
 * @param {number} timestamp - The Unix timestamp in seconds.
 * @returns {string} - The formatted date string.
 */
const timestampToDate = (timestamp, exchangeSlug) => {
    const date = new Date((exchangeSlug === "binance" || exchangeSlug === "bybit") ? timestamp : timestamp * 1000);

    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2); // Months are zero-based
    const day = ('0' + date.getDate()).slice(-2);
    const hours = ('0' + date.getHours()).slice(-2);
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2);

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

runVolumeJob();

async function getCandleData(filteredExistsExchanges, exchangesCandles) {
    await Promise.all(filteredExistsExchanges.map(async (exchange) => {
        try {
            await new Promise(resolve => setTimeout(resolve, 1500));
            const [exchangeName] = exchange.exchangeSlug.split('-');
            const exchangeConfig = loadExchangeConfig(exchangeName);

            if (!exchangeConfig) throw new Error(`Exchange configuration for ${exchangeName} not found`);

            const startTime = new Date('2017-01-01').getTime() / 1000;
            const now = new Date();
            now.setHours(0, 0, 0, 0);
            const midnightTimestamp = now.getTime() / 1000;

            const twoYearsInMillis = 2 * 365 * 24 * 60 * 60 * 1000;
            const endTime = startTime + (twoYearsInMillis / 1000);

            const getConfig = await exchangeConfig.getConfig(exchange.baseSymbol, exchange.quoteSymbol);

            let candles = await getConfig.getKlines(getConfig.url, getConfig.symbol, "1d", startTime, endTime);

            let exit = true;
            let lastCandleTime = endTime;

            while (exit) {
                await new Promise(resolve => setTimeout(resolve, 1500));
                const oneDay = 24 * 60 * 60;

                if (candles.length > 0) {
                    lastCandleTime = parseFloat(candles[candles.length - 1][0]) + oneDay;

                }

                lastCandleTime = lastCandleTime.toString().length > 10 ? lastCandleTime / 1000 : lastCandleTime;
                // console.log(lastCandleTime < midnightTimestamp, timestampToDate(lastCandleTime), timestampToDate(midnightTimestamp));
                if (lastCandleTime < midnightTimestamp && exchange.exchangeSlug !== "bitrue") {
                    const previousDayTimestampTwoYearsAgo = lastCandleTime + (twoYearsInMillis / 1000);

                    const newCandles = await getConfig.getKlines(getConfig.url, getConfig.symbol, "1d", lastCandleTime, previousDayTimestampTwoYearsAgo);

                    if (newCandles.length > 0) {
                        candles = [...candles, ...newCandles];
                        candles.sort((a, b) => new Date(a[0]) - new Date(b[0]));
                    } else {
                        lastCandleTime = lastCandleTime + (twoYearsInMillis / 1000);
                    }
                } else {
                    exit = false;
                }
            }

            const candlestick = candles.map(candleData =>
                [
                    timestampToDate(candleData[0], exchange.exchangeSlug),
                    exchange.baseSymbol,
                    candleData[5],
                    exchange.exchangeSlug,
                    exchange.marketPair,
                    candleData[2],
                    candleData[3],
                    candleData[4],
                ]);

            exchangesCandles.push(candlestick);
        } catch (error) {
            console.log(exchange.marketPair + " " + exchange.exchangeSlug + " " + error);
        }
    }));
}

function makeSymbolNameWithoutUsdt(symbol) {
    return symbol.replace("USDT", "").replace("-", "");
}

const calculateRSI = (closingPrices, period = 14) => {
    return RSI.calculate({ values: closingPrices, period: period });
};

const getBTCUSDRSI = async () => {
    const rsiValues = calculateRSI(closingPrices);
    console.log('RSI Values:', rsiValues);
};
