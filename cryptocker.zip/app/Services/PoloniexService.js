const axios = require("axios");
const ProxyService = require("./ProxyService");

class PoloniexService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: `https://api.poloniex.com/markets/${symbol}_USDT/orderBook`,
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        limit: 100,
      },
      httpsAgent: agent,
    });

    const orderBookArray = orderBookResponse.data;
    const asksOrderbook = orderBookResponse.data.asks;
    const bidsOrderbook = orderBookResponse.data.bids;
    const asks = [];
    const bids = [];

    for (let i = 0; i < asksOrderbook.length; i += 2) {
      const pair = [
        parseFloat(asksOrderbook[i]),
        parseFloat(asksOrderbook[i + 1]),
      ];
      asks.push(pair);
    }

    for (let i = 0; i < bidsOrderbook.length; i += 2) {
      const pair = [
        parseFloat(bidsOrderbook[i]),
        parseFloat(bidsOrderbook[i + 1]),
      ];
      bids.push(pair);
    }
    const formattedResponse = { asks, bids };

    return formattedResponse;
  }
}

module.exports = PoloniexService;
