import express from "express";
import SignalListController from "../../../app/Http/Controllers/Signal/SignalListController";

const signalRouter = express.Router();
//  @desc   Signals List
//  @route  GET /signal/get-signal-list
signalRouter.get(
  "/list",
  SignalListController.handle
);

module.exports = signalRouter;