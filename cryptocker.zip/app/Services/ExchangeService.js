const axios = require("axios");
const TelegramBotService = require("./TelegramBotService");

class ExchangeService {
  static async getOrderBook(symbol, exchange) {
    const hosts = ["ger", "ger2", "ger3"];

    // Get a random index from the hosts array
    const randomIndex = Math.floor(Math.random() * hosts.length);

    // Use the random index to select a random host
    const randomHost = hosts[randomIndex];

    try {
      const axiosClient = axios.create({
        baseURL: `https://${randomHost}.mohar9h.quest/?type=orderbook`,
      });

      const orderBookResponse = await axiosClient.get("", {
        params: {
          exchange: exchange,
          symbol: symbol,
        },
      });

      if (orderBookResponse.data.success == false) {
        throw new Error(orderBookResponse.data.message);
      }

      const orderBook = orderBookResponse.data;

      const formattedResponse = {
        asks: orderBook.asks.map((item) => [
          parseFloat(item[0]),
          parseFloat(item[1]),
        ]),
        bids: orderBook.bids.map((item) => [
          parseFloat(item[0]),
          parseFloat(item[1]),
        ]),
      };

      return formattedResponse;
    } catch (error) {
      TelegramBotService.futuresSignalSend(
        "ExchangeServiceOrderBook " + exchange + error
      );
    }
  }
}
module.exports = ExchangeService;
