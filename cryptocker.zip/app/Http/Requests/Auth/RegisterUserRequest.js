import Joi from "joi";
import Handler from "../../../Exceptions/handler";
import { ErrorCode } from "../../../Exceptions/errorCode";
import { i18n } from "../../../../config/configs";
import IRCheck from "ircheck";
import UserModel from "../../../Models/UserModel";

const schema = Joi.object({
  password: Joi.string()
    .required()
    .min(6)
    .max(30)
    .label(i18n.__("password"))
    .messages({
      "string.empty": i18n.__("string_empty"),
      "any.required": i18n.__("required"),
      "string.min": i18n.__("string_min"),
      "string.max": i18n.__("string_max"),
    }),

  username: Joi.string()
    .label(i18n.__("username"))
    .required()
    .min(4)
    .max(12)
    .messages({
      "string.empty": i18n.__("string_empty"),
      "any.required": i18n.__("required"),
      "string.min": i18n.__("string_min"),
      "string.max": i18n.__("string_max"),
    }),

  mobile: Joi.string()
    .label(i18n.__("mobile"))
    .required()
    .custom((value, helper) => {
      const phoneNumber = IRCheck.Phone.isMobile(value);
      if (!phoneNumber) return helper.message(i18n.__("not_valid"));
    })
    .messages({
      "string.empty": i18n.__("string_empty"),
      "any.required": i18n.__("required"),
    }),
});

export const RegisterUserRequest = async (req, res, next) => {
  try {
    const { error } = schema.validate(req.body, { abortEarly: false });

    if (error) {
      const errorMessage = error.details.map((err) => {
        const { message, path } = err;
        const key = path[0];
        return {
          key,
          message,
        };
      });
      throw new Handler(ErrorCode.VALIDATION_FAILED, errorMessage);
    }
    const usernameExists = await UserModel.findOne({
      where: {
        username: req.body.username,
      },
    });

    if (usernameExists) {
      throw new Handler(
        ErrorCode.VALIDATION_FAILED,
        i18n.__("username_exists")
      );
    }

    const mobileExists = await UserModel.findOne({
      where: {
        mobile: req.body.mobile,
      },
    });

    if (mobileExists) {
      throw new Handler(ErrorCode.VALIDATION_FAILED, i18n.__("mobile_exists"));
    }

    next(res.body);
  } catch (error) {
    next(error);
  }
};
