const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return "t" + base.toUpperCase() + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "bitfinex",
    symbol: await fixSymbolName(symbol),
    url: `wss://api-pub.bitfinex.com/ws/2`,

    getSubscribeMessage: (symbol) => {
      return {
        event: "subscribe",
        channel: "book",
        symbol: symbol,
        freq: "F0",
        len: "100",
        prec: "P0",
        subId: `book/${symbol}/P0`,
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      let asks = [];
      let bids = [];

      if (
        Array.isArray(message) &&
        message.length > 1 &&
        Array.isArray(message[1])
      ) {
        if (message[1][1] > 0) {
          if (message[1][2] > 0) {
            bids.push([message[1][0], message[1][2]]);
          } else {
            asks.push([message[1][0], Math.abs(message[1][2])]);
          }
        }
      }

      return { asks, bids };
    },
  };
};
