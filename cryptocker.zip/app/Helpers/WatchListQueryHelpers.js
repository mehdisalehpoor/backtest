const { Op } = require("sequelize");

const DateHelpers = require("./DateHelpers");
const WatchListModel = require("../Models/WatchListModel");

class WatchListQueryHelpers {

    static async getTodaySymbolsInWatchListModel() {
        const watchlist = await WatchListModel.findAll({
            where: {
                rate: null,
            },
        });

        return watchlist;
    }

    static async getTodayFuturesSymbolsInWatchListModel() {
        const today = DateHelpers.today();
        const watchlist = await WatchListModel.findAll({
            where: {
                type: "futures",
                // created_at: {
                //     [Op.between]: [today.startOfToday, today.endOfToday],
                // },
            },
        });

        return watchlist;
    }

    static async getSymbolInWatchListModel(symbol) {
        const today = DateHelpers.today();
        const watchlist = await WatchListModel.findOne({
            where: {
                symbol: symbol,
                created_at: {
                    [Op.between]: [today.startOfToday, today.endOfToday],
                },
            },
        });

        return watchlist;
    }

}

module.exports = WatchListQueryHelpers;