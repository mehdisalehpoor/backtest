const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "/" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "nominex",
    symbol: await fixSymbolName(symbol),
    url: `wss://nominex.io/api/ws/v1`,
    getSubscribeMessage: (symbol) => {
      return {
        event: "subscribe",
        endpoint: `/orderBook/${symbol}/A0/100`,
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = [];
      const bids = [];

      if (message && message.payload) {
        message.payload.forEach((item) => {
          if (item.side === "BUY" && item.amount > 0) {
            bids.push([item.price, item.amount]);
          }
          if (item.side === "SELL" && item.amount > 0) {
            asks.push([item.price, item.amount]);
          }
        });
      }
      return { asks, bids };
    },
  };
};
