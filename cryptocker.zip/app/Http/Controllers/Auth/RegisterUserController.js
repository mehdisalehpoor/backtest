import UserModel from "../../../Models/UserModel";

class RegisterUserController {
  static async handle(req, res, next) {
    const { username, mobile, password } = req.body;
    try {
      const data = await UserModel.create({
        username,
        mobile,
        password,
      });

      res.response(data);
    } catch (error) {
      next(error);
    }
  }
}

export default RegisterUserController;
