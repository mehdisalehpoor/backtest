<?php
require_once('./exchange_service.php');


// Check if the "type" parameter is set
if (isset($_GET['type'])) {
    $type = $_GET['type'];
    if (isset($_GET['exchange'])) {
        $exchange = $_GET['exchange'];
        if (isset($_GET['symbol'])) {
            $symbol = $_GET['symbol'];
            if ($type == 'orderbook') {

                if ($exchange == 'binance') {
                    $orderbook = ExchangeService::getBinanceOrderbook($symbol);
                } elseif ($exchange == 'mexc') {
                    $orderbook = ExchangeService::getMexcOrderbook($symbol);
                } elseif ($exchange == 'xt') {
                    $orderbook = ExchangeService::getXTOrderbook($symbol);
                } else if ($exchange == 'whitebit') {
                    $orderbook = ExchangeService::getWhiteBitOrderbook($symbol);
                } else if ($exchange == 'toobit') {
                    $orderbook = ExchangeService::getTooBitOrderbook($symbol);
                } else if ($exchange == 'tokocrypto') {
                    $orderbook = ExchangeService::getTokoCryptoOrderbook($symbol);
                } else if ($exchange == 'probit') {
                    $orderbook = ExchangeService::getProbitOrderbook($symbol);
                } else if ($exchange == 'poloniex') {
                    $orderbook = ExchangeService::getPoloniexOrderBook($symbol);
                } else if ($exchange == 'pionex') {
                    $orderbook = ExchangeService::getPionexOrderbook($symbol);
                } else if ($exchange == 'orangex') {
                    $orderbook = ExchangeService::getOrangeXOrderbook($symbol);
                } else if ($exchange == 'okx') {
                    $orderbook = ExchangeService::getOkxOrderbook($symbol);
                } else if ($exchange == 'lbank') {
                    $orderbook = ExchangeService::getLBankOrderbook($symbol);
                } else if ($exchange == 'latoken') {
                    $orderbook = ExchangeService::getLatokenOrderbook($symbol);
                } else if ($exchange == 'huobi') {
                    $orderbook = ExchangeService::getHuobiOrderbook($symbol);
                } else if ($exchange == 'hotcoin') {
                    $orderbook = ExchangeService::getHotcoinOrderbook($symbol);
                } else if ($exchange == 'gate') {
                    $orderbook = ExchangeService::getGateOrderbook($symbol);
                } else if ($exchange == 'digifinex') {
                    $orderbook = ExchangeService::getDigiFinexOrderbook($symbol);
                } else if ($exchange == 'fameex') {
                    $orderbook = ExchangeService::getFameexOrderbook($symbol);
                } else if ($exchange == 'deepcoin') {
                    $orderbook = ExchangeService::getDeepCoinOrderbook($symbol);
                } else if ($exchange == 'coinex') {
                    $orderbook = ExchangeService::getCoinexOrderbook($symbol);
                } else if ($exchange == 'coinbase') {
                    $orderbook = ExchangeService::getCoinBaseOrderbook($symbol);
                }

                // $url = "https://api.ipify.org/?format=json";

                // $ch = curl_init($url);
                // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                // $response = curl_exec($ch);
                // curl_close($ch);

                // $data = json_decode($response, true);

                // $userIP = $data['ip'];
                // echo "User's IP address: " . $userIP;


                echo json_encode($orderbook);
            }
        } else {
            echo "Symbol parameter is not set<br>";
        }
    } else {
        echo "Exchange parameter is not set<br>";
    }
} else {
    echo "Type parameter is not set<br>";
}
