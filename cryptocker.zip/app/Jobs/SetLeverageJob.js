const SymbolModel = require("../Models/SymbolModel");
const axios = require("axios");
const TelegramBotService = require("../Services/TelegramBotService");
const UserModel = require("../Models/UserModel");

const runSetLeverageJob = async () => {
  try {
    // Find all active users
    const users = await UserModel.findAll({
      where: {
        status: true,
      },
    });

    // Iterate over each user
    for (const user of users) {
      // Find all symbols
      const symbols = await SymbolModel.findAll();

      // Iterate over each symbol
      for (const symbol of symbols) {
        try {
          const apiUrl = `http://${user.ip}:3013/v1/symbol/leverage`;

          // Prepare request body
          const requestBody = {
            symbol: symbol.symbol + "USDT",
            leverage: symbol.initialLeverage,
          };

          // Send POST request to set margin type
          const response = await axios.post(apiUrl, requestBody);
          console.log(response.data); // Log response data

          // You might want to do something with the response data here
        } catch (error) {
          console.error({
            symbol: symbol.symbol,
            error: error.response.data,
          });
        }
      }
    }

    return users; // Return the users after the job is done
  } catch (error) {
    console.error("Error occurred in runSetLeverageJob:", error.message);
    // Send error message to TelegramBotService
    TelegramBotService.futuresSignalSend("runSetLeverageJob " + error);
  }
};

// Invoke the runJob function to start the recurring execution
runSetLeverageJob();
