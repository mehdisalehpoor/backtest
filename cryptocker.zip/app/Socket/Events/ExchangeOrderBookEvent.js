import { i18n } from "../../../config/configs";
import ResponseHelper from "../Helpers/ResponseHelper";
import Event from "./Event";

class ExchangeOrderBookEvent extends Event {
  constructor(io, socket, event, data) {
    super(io, socket, event, data);
  }
  async handle() {
    console.log(this.data);
    this.send(
      client.client_id,
      this.event,
      ResponseHelper.success(this.data, 200)
    );
  }
}

export default ExchangeOrderBookEvent;
