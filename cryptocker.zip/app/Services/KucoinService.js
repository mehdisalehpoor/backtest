const axios = require("axios");
const crypto = require("crypto");

class KucoinService {
  constructor() {
    this.api_key = "64765e0118ad490001f4667f";
    this.api_secret = "834d5ded-5a61-4bd4-82ed-1007ccb83d5a";
    this.api_passphrase = "ademehdi";
    this.baseUrl = "https://api.kucoin.com";
  }

  async getOrderBook(symbol) {
    const url = `${this.baseUrl}/api/v3/market/orderbook/level2?symbol=${symbol}-USDT`;
    const now = Date.now();
    const str_to_sign =
      now + "GET" + `/api/v3/market/orderbook/level2?symbol=${symbol}-USDT`;
    const signature = crypto
      .createHmac("sha256", this.api_secret)
      .update(str_to_sign)
      .digest("base64");
    const passphrase = crypto
      .createHmac("sha256", this.api_secret)
      .update(this.api_passphrase)
      .digest("base64");
    const headers = {
      "KC-API-SIGN": signature,
      "KC-API-TIMESTAMP": now,
      "KC-API-KEY": this.api_key,
      "KC-API-PASSPHRASE": passphrase,
      "KC-API-KEY-VERSION": "2",
    };

    try {
      const response = await axios.get(url, { headers });
      const orderBook = response.data;

      const formattedResponse = {
        asks: orderBook.data.asks.map((item) => [
          parseFloat(item[0]),
          parseFloat(item[1]),
        ]),
        bids: orderBook.data.bids.map((item) => [
          parseFloat(item[0]),
          parseFloat(item[1]),
        ]),
      };

      return formattedResponse;
    } catch (error) {
      console.error(error);
    }
  }

  async getSymbols() {
    const url = `${this.baseUrl}/api/v1/symbols`;


    try {
      const response = await axios.get(url);

      return response.data.data;
    } catch (error) {
      console.error(error);
    }
  }

  async createDepositAddress(currency) {
    const url = `${this.baseUrl}/deposit-addresses`;
    const now = Date.now();
    const data = { currency };
    const data_json = JSON.stringify(data);
    const str_to_sign = now + "POST" + "/api/v1/deposit-addresses" + data_json;
    const signature = crypto
      .createHmac("sha256", this.api_secret)
      .update(str_to_sign)
      .digest("base64");
    const passphrase = crypto
      .createHmac("sha256", this.api_secret)
      .update(this.api_passphrase)
      .digest("base64");
    const headers = {
      "KC-API-SIGN": signature,
      "KC-API-TIMESTAMP": now,
      "KC-API-KEY": this.api_key,
      "KC-API-PASSPHRASE": passphrase,
      "KC-API-KEY-VERSION": "2",
      "Content-Type": "application/json",
    };

    try {
      const response = await axios.post(url, data_json, { headers });
      console.log(response.status);
      console.log(response.data);
    } catch (error) {
      console.error(error);
    }
  }
}

module.exports = KucoinService;
