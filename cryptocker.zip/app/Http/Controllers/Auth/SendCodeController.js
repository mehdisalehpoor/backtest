import Handler from "../../../Exceptions/handler";
import { ErrorCode } from "../../../Exceptions/errorCode";
import UserModel from "../../../Models/UserModel";
import { i18n } from "../../../../config/configs";
import SmsIrService from "../../../Services/SmsIrService";

class SendCodeController {
  static async handle(req, res, next) {
    const { mobile } = req.body;
    try {
      const user = await UserModel.findOne({
        where: {
          mobile: mobile,
        },
      });

      if (!user) {
        throw new Handler(ErrorCode.USER_NOT_EXISTS);
      }

      var otp = Math.floor(1000 + Math.random() * 9000);
      var hash = Math.random().toString(36).substring(2, 10);

      // OtpCodeModel.create({
      //   mobile,
      //   otp,
      //   hash,
      // });

      SmsIrService.sendOtpCode(mobile, otp);

      res.response({ message: i18n.__("send_code") });
    } catch (error) {
      next(error);
    }
  }
}

export default SendCodeController;
