const axios = require("axios");
const UserModel = require("../Models/UserModel");
const OrderModel = require("../Models/OrderModel");
const DateHelpers = require("../Helpers/DateHelpers");
const SymbolModel = require("../Models/SymbolModel");

class ApiService {
  static async call(symbol, side, condition) {
    const users = await UserModel.findAll();

    users.map(async (user) => {
      const symbolInDb = await SymbolModel.findOne({
        where: {
          symbol: symbol,
        },
      });
      if (symbolInDb) {
        return;
      }
      const apiUrl = `http://${user.ip}:3013/v1/order/add`;

      const requestBody = {
        symbol: symbol,
        side: side,
        condition: condition,
        userManageMoney: user.capitalـdivision,
      };
      try {
        axios.post(apiUrl, requestBody).then((response) => {
          console.log("API call successful");
          // Handle the API response
          console.log(response.data);
        });
      } catch (err) {
        console.error(err);
      }
    });
  }

  static async callSpotPrice(symbol) {
    const max = 2;
    const min = 1;
    const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    const user = await UserModel.findOne({
      where: { id: randomNumber },
    });

    const apiUrl = `http://${user.ip}:3013/v1/symbol/spot-price`;

    const requestBody = {
      symbol: symbol,
    };
    try {
      const response = await axios.post(apiUrl, requestBody);
      const spotPrice = response.data;
      return spotPrice;
    } catch (err) {
      console.error(err);
    }
  }

  static async callRsi(symbol, timeframe) {
    const max = 2;
    const min = 1;
    const randomNumber = Math.floor(Math.random() * (max - min + 1)) + min;
    const user = await UserModel.findOne({
      where: { id: randomNumber },
    });

    const apiUrl = `http://${user.ip}:3013/v1/symbol/rsi`;

    const requestBody = {
      symbol: symbol,
      timeframe: timeframe,
    };
    try {
      const response = await axios.post(apiUrl, requestBody);
      const rsi = response.data;
      return rsi;
    } catch (err) {
      console.error(err);
    }
  }

  static async callClosePosition(symbol) {
    const users = await UserModel.findAll();

    users.map(async (user) => {
      const apiUrl = `http://${user.ip}:3013/v1/position/delete`;

      const lastHours = DateHelpers.lastHours(8);

      const order = await OrderModel.findOne({
        symbol,
        userId: user.id,
        parentId: null,
        exit: false,
        created_at: {
          [Op.between]: [lastHours.startOfLastHours, lastHours.endOfLastHours],
        },
      });

      if (!order) return null;

      const requestBody = {
        symbol: symbol,
        sideStatus: order.side == "BUY" ? "SELL" : "BUY",
        positionSide: order.position_side,
        tickSizeNumberOfDecimals: order.tick_size_number_of_decimals,
        roundedQty: order.orig_qty,
      };

      try {
        axios
          .post(apiUrl, requestBody)
          .then((response) => {
            console.log("API call successful");
            // Handle the API response
            console.log(response.data);
          })
          .catch((error) => {
            console.error("API call failed:", error);
          });
      } catch (err) {
        console.error(err);
      }
    });
  }

  static async handle(userIp, url, params) {
    const apiUrl = `http://${userIp}:3013/v1/${url}`;

    const requestBody = params;

    try {
      const response = await axios.post(apiUrl, requestBody);
      return response.data;
    } catch (err) {
      console.error(err);
    }
  }
}

module.exports = ApiService;
