const axios = require("axios");
const ProxyService = require("./ProxyService");

class TokoCryptoService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://www.tokocrypto.com/open/v1/market/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}_USDT`,
        limit: 500,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = TokoCryptoService;
