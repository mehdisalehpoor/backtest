const WebSocket = require("ws");
const { Sequelize, DataTypes } = require('sequelize');

// Assuming Sequelize is properly configured, replace the following with your database connection details
const sequelize = new Sequelize("postgresql://root:k4X3r4ByDGXdVsUFXCHWfpCG@grace.iran.liara.ir:33396/postgres", { logging: false });

// Define SignalModel using Sequelize
const SignalModel = sequelize.define(
  "signals",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbol: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    spotPrice: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    futuresPrice: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    exitFuturesPrice: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    percentageIncrease: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    profit: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    signalStatus: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    payload: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    exchangesVolume: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    signalType: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    type: {
      type: DataTypes.ENUM(["FUTURES", "SPOT"]),
      defaultValue: "FUTURES",
      allowNull: false,
    },
    checkCount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    exitCount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0,
    },
    exit: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

let sockets = []; // Array to store WebSocket connections

(async () => {
  try {
    await sequelize.authenticate();
    console.log('Connection to the database has been established successfully.');
    initializeWebSocketConnections(); // Call the function once the database connection is established
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
})();

const connectToWebSocket = async (pair) => {
  const symbol = pair.toLowerCase() + 'usdt';
  const ws = new WebSocket(`wss://fstream.binance.com/ws/${symbol}@depth20`);

  ws.onopen = () => {
    console.log(`Connected to Binance WebSocket server for ${symbol} order book updates`);
  };

  ws.onmessage = (data) => {
    const message = JSON.parse(data.data);
    const asks = message.a.map((item) => [
      parseFloat(item[0]),
      parseFloat(item[1]),
    ]);
    const bids = message.b.map((item) => [
      parseFloat(item[0]),
      parseFloat(item[1]),
    ]);

    console.log(`${pair} Order Book:`, { asks, bids });
  };

  ws.onerror = (error) => {
    console.error(`WebSocket error for ${pair}:`, error);
  };

  ws.onclose = () => {
    console.log(`Disconnected from Binance WebSocket server for ${pair} order book updates`);
  };
  

  return ws;
};

const getSymbolsFromSignals = async () => {
  try {
    return await SignalModel.findAll({
      attributes: ['id', 'symbol', 'type', 'futures_price', 'exit'], // Specify the columns to select
      where: {
        type: 'FUTURES',
        exit: false,
      }
    });
  } catch (error) {
    throw new Error("Error fetching symbols from signals: " + error.message);
  }
};

const initializeWebSocketConnections = async () => {
  try {
    await sequelize.sync(); // Sync models with database
    const tradingPairs = await getSymbolsFromSignals();

    // Close existing WebSocket connections
    sockets.forEach(ws => ws.close());
    sockets = [];

    // Open new WebSocket connections based on tradingPairs
    tradingPairs.forEach(pair => {
      const ws = connectToWebSocket(pair.symbol);
      sockets.push(ws);
    });
  } catch (error) {
    console.error("Error initializing WebSocket connections:", error);
  }
};











const WebSocket = require("ws");

const tradingPair = "BTCUSDT"; // Specify the trading pair here

const ws = new WebSocket(`wss://stream.bybit.com/v5/public/spot`);

ws.on("open", () => {
  // Subscribe to the trading pair's order book updates
  ws.send(
    JSON.stringify({
      op: "subscribe",
      args: [`orderbook.200.${tradingPair}`],
    })
  );
  console.log(
    `Connected to Bybit WebSocket server for ${tradingPair} spot trading updates`
  );
});

ws.on("message", (data) => {
  const message = JSON.parse(data);
  const orderbook = message.data;

  if (orderbook && orderbook.a.length > 0) {
    const asks = orderbook.a.map((item) => [
      parseFloat(item[0]),
      parseFloat(item[1]),
    ]);
    const bids = orderbook.b.map((item) => [
      parseFloat(item[0]),
      parseFloat(item[1]),
    ]);
    console.log({ asks, bids });
  } else {
    console.log("Property 'a' is not present in the order book.");
  }

});

ws.on("error", (error) => {
  console.error("WebSocket error:", error);
});

ws.on("close", () => {
  console.log(
    `Disconnected from Bybit WebSocket server for ${tradingPair} spot trading updates`
  );
});
