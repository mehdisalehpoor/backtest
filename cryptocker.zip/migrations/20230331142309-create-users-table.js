"use strict";

const sequelize = require("sequelize");

module.exports = {
  up: function (queryInterface, DataTypes) {
    return queryInterface.createTable("users", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
      },
      username: {
        type: DataTypes.STRING(30),
        unique: true,
        allowNull: true,
      },
      email: {
        type: DataTypes.STRING(30),
        unique: true,
        allowNull: true,
      },
      mobile: {
        type: DataTypes.STRING(14),
        unique: true,
        allowNull: true,
      },
      thumbnail: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      banner: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      bio: {
        type: DataTypes.STRING,
        allowNull: true,
      },
      birthdate: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      password: {
        type: DataTypes.STRING(150),
        allowNull: true,
      },
      created_at: {
        allowNull: false,
        type: DataTypes.DATE,
        defaultValue: sequelize.NOW,
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE,
        allowNull: true,
      },
      deleted_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    });
  },

  down: function (queryInterface, DataTypes) {
    return queryInterface.dropTable("users");
  },
};
