const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "trubit-exchange",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.trubit.com/openapi/quote/ws/v1`,
    getSubscribeMessage: (symbol) => {
      return {
        symbol: symbol,
        topic: "depth",
        event: "sub",
        params: {
          binary: false,
        },
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.[0]?.a || [];
      const bids = message?.data?.[0]?.b || [];
      return { asks, bids };
    },
  };
};
