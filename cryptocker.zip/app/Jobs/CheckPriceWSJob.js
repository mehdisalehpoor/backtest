const { cryptockerWs } = require("../Services/ws/src");
const CoinmarketcapHelpers = require("../Helpers/CoinmarketcapHelpers");
const ExchangeModel = require("../Models/ExchangeModel");
const SymbolModel = require("../Models/SymbolModel");
const { Op } = require("sequelize");
const BinanceService = require("../Services/BinanceService");

const fetchSymbolsFromSignals = async () => {
  try {
    return await SymbolModel.findAll({
      where: {
        futures: true,
        exchangeVolume: { [Op.gte]: 90 },
      },
    });
  } catch (error) {
    console.error("Error fetching symbols from signals:", error);
    throw new Error("Error fetching symbols from signals");
  }
};

const fetchExchanges = async () => {
  try {
    return await ExchangeModel.findAll();
  } catch (error) {
    console.error("Error fetching exchanges:", error);
    throw new Error("Error fetching exchanges");
  }
};

const runCheckPriceWSJob = async () => {
  try {
    const symbols = await fetchSymbolsFromSignals();
    const exchangesFetch = await fetchExchanges();

    await Promise.all(
      symbols.map(async (pair) => {
        const symbolPair = pair.symbol.toLowerCase() + "usdt";
        await BinanceService.wsTrade(symbolPair);

        const coinmarketCap = await CoinmarketcapHelpers.coinmarketcapCalculate(
          pair.name,
          exchangesFetch
        );
        const exchanges = coinmarketCap.filteredExistsExchanges;

        await Promise.all(
          exchanges.map(async (exchange) => {
            const exchangeSlug = exchange.exchangeSlug.split("-")[0];
            const symbol = `${exchange.baseSymbol}/${exchange.quoteSymbol}`;
            const wsClient = await cryptockerWs(
              exchangeSlug,
              symbol,
              exchange.baseSymbol
            );
          })
        );
      })
    );
  } catch (error) {
    console.error("An error occurred:", error);
  }
};

module.exports = {
  runCheckPriceWSJob,
};
