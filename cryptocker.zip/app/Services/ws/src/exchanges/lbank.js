const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toLowerCase() + "_" + quote.toLowerCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "lbank",
    symbol: await fixSymbolName(symbol),
    url: `wss://www.lbkex.net/ws/V2/`,

    getSubscribeMessage: (symbol) => {
      return {
        action: "subscribe",
        subscribe: "depth",
        depth: "100",
        pair: symbol,
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.depth?.asks || [];
      const bids = message?.depth?.bids || [];
      return { asks, bids };
    },
  };
};
