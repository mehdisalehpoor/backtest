import SocketAuthorizationMiddleware from "./Middlewares/SocketAuthorizationMiddleware";
import SocketHandler from "./SocketHandler";

export default class SocketManager {
    constructor(io) {
        console.log(io);
        // Socket events
        io.on("connection", (socket) => {

            // Check User Authentication
            // console.log(this.io);
            SocketAuthorizationMiddleware.authorize(socket, io);
            // Socket Handler
            new SocketHandler(socket, this.io);

            // Disconnect Socket
            socket.on("disconnect", () => {
                // Remove Client When Disconnected
                SocketAuthorizationMiddleware.removeClient(socket, this.io);
            })
        });
    }
}
