// Pm2Service.js
const pm2 = require("pm2");

class Pm2Service {
  static startProcess(processNameOrId, type, orderId) {
    console.log("Starting process " + processNameOrId);
    pm2.start(
      {
        name: processNameOrId,
        script: "./app/Jobs/CheckPositionJob.js",
        args: [`--type=${type}`, `--orderId=${orderId}`],
        autorestart: false, // Disable automatic restart
      },
      (err, apps) => {
        if (err) {
          console.error(err);
          return;
        }
        console.log("Job started successfully");
      }
    );
  }

  static stopProcess(processNameOrId) {
    console.log("Stopping process " + processNameOrId);
    pm2.stop(processNameOrId, (err, proc) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log("Job stopped successfully");
    });
  }
}

module.exports = Pm2Service;
