import Joi from "joi";
import Handler from "../../../Exceptions/handler";
import { ErrorCode } from "../../../Exceptions/errorCode";
import { i18n } from "../../../../config/configs";
import { parsePhoneNumberFromString as parsePhoneNumber } from "libphonenumber-js";

const schema = Joi.object({
    otp: Joi.string()
        .label(i18n.__("otp"))
        .required()
        .min(4)
        .max(4)
        .messages({
            "string.empty": i18n.__("string_empty"),
            "any.required": i18n.__("required"),
            "string.min": i18n.__("string_min"),
            "string.max": i18n.__("string_max"),
        }),
    mobile: Joi.string()
        .label(i18n.__("mobile"))
        .required()
        .custom((value, helper) => {
            const phoneNumber = parsePhoneNumber(value);
            if (!phoneNumber) return helper.message(i18n.__("not_valid"));
            return phoneNumber.isValid();
        })
        .messages({
            "string.empty": i18n.__("string_empty"),
            "any.required": i18n.__("required"),
        }),
});

export const VerifyCodeRequest = async (req, res, next) => {
    try {
        const { error } = schema.validate(req.body, { abortEarly: false });

        if (error) {
            const errorMessage = error.details.map((err) => {
                const { message, path } = err;
                const key = path[0];
                return {
                    key,
                    message,
                };
            });
            throw new Handler(ErrorCode.VALIDATION_FAILED, errorMessage);
        }

        next(res.body);
    } catch (error) {
        next(error);
    }
};
