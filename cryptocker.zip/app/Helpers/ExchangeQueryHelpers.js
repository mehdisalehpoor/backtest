const ExchangeModel = require("../Models/ExchangeModel");

class ExchangeQueryHelpers {
  static async getAllExchanges() {
    const exchanges = await ExchangeModel.findAll();
    return exchanges;
  }

  static async addAllExchagnes() {
    const exchanges = [
      { exchangeId: 943, exchangeSlug: "hotcoin", ccxtName: "hotcoin" },
      { exchangeId: 270, exchangeSlug: "binance", ccxtName: "binance" },
      { exchangeId: 270, exchangeSlug: "binance-us", ccxtName: "binance-us" },
      { exchangeId: 302, exchangeSlug: "gate", ccxtName: "gate" },
      { exchangeId: 1064, exchangeSlug: "bingx", ccxtName: "bingx" },
      { exchangeId: 521, exchangeSlug: "bybit", ccxtName: "bybit" },
      { exchangeId: 24, exchangeSlug: "kraken", ccxtName: "kraken" },
      { exchangeId: 513, exchangeSlug: "bitget", ccxtName: "bitget" },
      { exchangeId: 311, exchangeSlug: "kucoin", ccxtName: "kucoin" },
      { exchangeId: 350, exchangeSlug: "coinex", ccxtName: "coinex" },
      { exchangeId: 89, exchangeSlug: "coinbasepro", ccxtName: "coinbasepro" },
      { exchangeId: 89, exchangeSlug: "coinbase", ccxtName: "coinbase" },
      {
        exchangeId: 89,
        exchangeSlug: "coinbaseprime",
        ccxtName: "coinbaseprime",
      },
      { exchangeId: 710, exchangeSlug: "tokocrypto", ccxtName: "tokocrypto" },
      { exchangeId: 544, exchangeSlug: "mexc", ccxtName: "mexc" },
      { exchangeId: 380, exchangeSlug: "latoken", ccxtName: "latoken" },
      { exchangeId: 1149, exchangeSlug: "cryptocom", ccxtName: "cryptocom" },
      { exchangeId: 433, exchangeSlug: "bitrue", ccxtName: "bitrue" },
      { exchangeId: 102, exchangeSlug: "huobi", ccxtName: "huobi" },
      { exchangeId: 294, exchangeSlug: "okx", ccxtName: "okx" },
      { exchangeId: 477, exchangeSlug: "probit", ccxtName: "probit" },
      { exchangeId: 16, exchangeSlug: "poloniex", ccxtName: "poloniex" },
      { exchangeId: 520, exchangeSlug: "bitvavo", ccxtName: "bitvavo" },
      { exchangeId: 453, exchangeSlug: "ascendex", ccxtName: "ascendex" },
      { exchangeId: 406, exchangeSlug: "bitmart", ccxtName: "bitmart" },
      { exchangeId: 333, exchangeSlug: "lbank", ccxtName: "lbank" },
      { exchangeId: 403, exchangeSlug: "bitforex", ccxtName: "bitforex" },
      { exchangeId: 351, exchangeSlug: "upbit", ccxtName: "upbit" },
      { exchangeId: 70, exchangeSlug: "bitstamp", ccxtName: "bitstamp" },
      { exchangeId: 37, exchangeSlug: "bitfinex2", ccxtName: "bitfinex2" },
      { exchangeId: 525, exchangeSlug: "xt", ccxtName: "xt" },
      { exchangeId: 955, exchangeSlug: "phemex", ccxtName: "phemex" },
      { exchangeId: 151, exchangeSlug: "gemini", ccxtName: "gemini" },
    ];
    const response = [];
    for (const exchange of exchanges) {
      const [exchangeCreated, created] = await ExchangeModel.findOrCreate({
        where: { name: exchange.exchangeSlug },
        defaults: {
          name: exchange.ccxtName,
          exchangeId: exchange.exchangeId,
          ccxtName: exchange.ccxtName,
          exchangeSlug: exchange.exchangeSlug,
        },
      });
      response.push(exchangeCreated);
    }
    return response;
  }
}

module.exports = ExchangeQueryHelpers;