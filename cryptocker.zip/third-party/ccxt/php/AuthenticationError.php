<?php

namespace ccxt;

require_once PATH_TO_CCXT . 'ExchangeError.php';

class AuthenticationError extends ExchangeError {};
