import { i18n } from "../../../config/configs";
import jwt from "jsonwebtoken";
import UserModel from "../../Models/UserModel";
import ResponseHelper from "../Helpers/ResponseHelper";

class SocketAuthorizationMiddleware {
  constructor() {
    // Initialize an empty map to store authenticated clients
    this.clients = new Map();
  }

  static authenticate(io) {
    io.use(async (socket, next) => {
      // Extract the token from the request headers
      const token = socket.handshake.headers["authorization"];

      try {
        // check token is valid
        const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

        // push the authenticated users to IO clients object
        await SocketAuthorizationMiddleware.addClients(socket, decoded, io);

        return next();
      } catch (err) {
        return next(new Error(i18n.__("unauthenticated")));
      }
    });
  }

  // add clients to IO
  static async addClients(socket, decoded, io) {
    const user = await UserModel.findOne({ where: { id: decoded.id } });
    const users = {
      client_id: socket.id,
      user_id: decoded.id,
      username: user.username,
      iat: decoded.iat,
      expire: decoded.exp,
    };

    if (io.authenticatedUsers == undefined) {
      const authenticatedUsers = [];
      authenticatedUsers.push(users);
      io.authenticatedUsers = authenticatedUsers;
    } else {
      io.authenticatedUsers.push(users);
    }
  }

  static authorize(socket, io) {
    // Check if the client is authenticated
    try {
      io.authenticatedUsers.find((client, index) => {
        if (client.client_id !== socket.id) {
          // If the client is not authenticated, reject the message
          ResponseHelper.error(i18n.__("unauthenticated"), 403);
        }
      });
    } catch (err) {
      ResponseHelper.error(i18n.__("unauthenticated"), 403);
    }
  }

  static removeClient(socket, io) {
    // Remove the client from the clients map when it disconnects
    io.authenticatedUsers.splice(
      io.authenticatedUsers.findIndex(({ clientId }) => clientId == socket.id),
      1
    );
  }
}

export default SocketAuthorizationMiddleware;
