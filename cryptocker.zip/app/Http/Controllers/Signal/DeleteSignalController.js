import SignalModel from "../../../Models/SignalModel";

class DeleteSignalController {
  static async handle(req, res, next) {
    const id = req.params.id;
    try {
      const signals = await SignalModel.destroy({ where: { id } });

      res.response("success");
    } catch (error) {
      next(error);
    }
  }
}

export default DeleteSignalController;
