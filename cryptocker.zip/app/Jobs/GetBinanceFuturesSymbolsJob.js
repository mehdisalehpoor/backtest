const SignalModel = require("../Models/SignalModel");

const TelegramBotService = require("../Services/TelegramBotService");
const ExchangeModel = require("../Models/ExchangeModel");
const SymbolExchangeModel = require("../Models/SymbolExchangeModel");
const CoinmarketcapHelpers = require("../Helpers/CoinmarketcapHelpers");
const BinanceService = require("../Services/BinanceService");
const SymbolModel = require("../Models/SymbolModel");

export const runJobToGetBinanceFuturesSymbols = async () => {
  try {
    // Create a request to get all futures symbols
    const [binanceResponse, coinmarketcapResponse] = await Promise.all([
      BinanceService.getFuturesSymbols(),
      CoinmarketcapHelpers.coinmarketcapSymbolsList(),
    ]);

    if (binanceResponse.status !== 200) {
      console.error("Failed to fetch futures symbols");
      return;
    }

    const tradingSymbols = binanceResponse.data.symbols.filter(
      (symbolInfo) => symbolInfo.status == "TRADING"
    );

    const binanceSymbols = tradingSymbols.map(
      (symbolInfo) => symbolInfo.symbol
    );

    const usdtSymbols = binanceSymbols.filter((symbol) =>
      symbol.endsWith("USDT")
    );

    const coinmarketcapSymbols = coinmarketcapResponse.data.data;
    const data = [];
    const exchanges = await ExchangeModel.findAll();
    for (const symbol of usdtSymbols) {
      try {
        await new Promise((resolve) => setTimeout(resolve, 250));
        const symbolWithoutUsdt = symbol.replace("USDT", "");

        const cmcSymbol = coinmarketcapSymbols.find(
          (cmcSymbol) => cmcSymbol.symbol === symbolWithoutUsdt
        );

        const { sumExistsExchangesVolume, filteredExistsExchanges } =
          await CoinmarketcapHelpers.coinmarketcapCalculate(
            cmcSymbol.slug,
            exchanges
          );

        const signal = await SignalModel.findOne({
          where: {
            symbol: symbolWithoutUsdt,
            type: "FUTURES",
            exit: false,
          },
        });

        const isBinanceExists = filteredExistsExchanges.some(
          (exchange) => exchange.exchangeSlug === "binance"
        );

        if (
          (parseFloat(sumExistsExchangesVolume.toFixed(0)) >= 80 &&
            isBinanceExists) ||
          signal
        ) {
          var findSymbol = await SymbolModel.findOne({
            where: {
              symbol: symbolWithoutUsdt,
            },
          });

          if (findSymbol) {
            SymbolModel.update(
              {
                exchangeVolume: signal
                  ? 90
                  : parseFloat(sumExistsExchangesVolume.toFixed(0)),
              },
              { where: { id: findSymbol.id } }
            );
          } else {
            console.log("Invalid");
            findSymbol = await SymbolModel.create({
              symbol: symbolWithoutUsdt,
              name: cmcSymbol.slug,
              futures: true,
              spot: false,
              exchangeVolume: parseFloat(sumExistsExchangesVolume.toFixed(0)),
            });
          }

          await SymbolExchangeModel.destroy({
            where: { symbolId: findSymbol.id },
          });

          for (const exchange of filteredExistsExchanges) {
            const exchangeData = await ExchangeModel.findOne({
              where: { exchangeId: exchange.exchangeId },
            });
            SymbolExchangeModel.create({
              exchangeId: exchangeData.id,
              symbolId: findSymbol.id,
            });
          }

          data.push({
            symbol,
            exchange_volume: parseFloat(sumExistsExchangesVolume.toFixed(0)),
            name: cmcSymbol.slug,
            filteredExistsExchanges,
          });
        }
        console.log({
          symbol,
          exchange_volume: parseFloat(sumExistsExchangesVolume.toFixed(0)),
        });
      } catch (error) {
        console.error(error.message);
        var message = symbol + error;
        TelegramBotService.futuresSignalSend(message);
      }
    }

    return data;
  } catch (error) {
    console.error(error);
    var message = error;
    TelegramBotService.futuresSignalSend(message);
  }
};
