const axios = require("axios");
const ProxyService = require("./ProxyService");

class HuobiService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: `https://api.huobi.pro/market/depth`,
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol.toLowerCase()}usdt`,
        type: "step0",
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.tick;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[0]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[0]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = HuobiService;
