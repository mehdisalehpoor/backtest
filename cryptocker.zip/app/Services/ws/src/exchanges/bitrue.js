const zlib = require("zlib");

const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toLowerCase() + quote.toLowerCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "bitrue",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.bitrue.com/market/ws`,
    getSubscribeMessage: (symbol) => {
      return {
        event: "sub",
        params: {
          cb_id: symbol,
          channel: `market_${symbol}_simple_depth_step0`,
        },
      };
    },
    parseMessage: (data) => {
      const buf = Buffer.from(data);
      data = zlib.gunzipSync(buf).toString("utf-8");
      const message = JSON.parse(data);
      const asks = message?.tick?.asks || [];
      const bids = message?.tick?.buys || [];
      return { asks, bids };
    },
  };
};
