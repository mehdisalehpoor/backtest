const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "/" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "kraken",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.kraken.com/v2`,
    getSubscribeMessage: (symbol) => {
      return {
        method: "subscribe",
        params: {
          channel: "book",
          depth: 100,
          snapshot: true,
          symbol: [symbol],
        },
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      let asks = message?.data?.[0]?.asks || [];
      let bids = message?.data?.[0]?.bids || [];
      asks = asks.map((item) => [item.price, item.qty]);
      bids = bids.map((item) => [item.price, item.qty]);
      return { asks, bids };
    },
  };
};
