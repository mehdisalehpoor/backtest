const zlib = require("zlib");

const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "_" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "hotcoin-global",
    symbol: await fixSymbolName(symbol),
    url: `wss://wss.hotcoinfin.com/trade/multiple`,

    getSubscribeMessage: (symbol) => {
      return {
        sub: `market.${symbol}.trade.depth`,
      };
    },
    parseMessage: (data) => {
      const buf = Buffer.from(data);
      data = zlib.gunzipSync(buf).toString("utf-8");
      const message = JSON.parse(data);
      const asks = message?.data?.asks || [];
      const bids = message?.data?.bids || [];
      return { asks, bids };
    },
  };
};
