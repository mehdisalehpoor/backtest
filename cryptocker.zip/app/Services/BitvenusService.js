const axios = require("axios");
const ProxyService = require("./ProxyService");

class BitvenusService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://www.bitvenus.com/openapi/quote/v1/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}USDT`,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = BitvenusService;
