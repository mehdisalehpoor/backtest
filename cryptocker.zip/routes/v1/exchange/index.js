import express from "express";
import { AddExchangeController } from "../../../app/Http/Controllers/exchange/AddExchangeController";

const exchangeRouter = express.Router();

//  @desc   Add Exchange(s)
//  @route  POST /exchange/add
exchangeRouter.post("/add", AddExchangeController.handle);


module.exports = exchangeRouter;
