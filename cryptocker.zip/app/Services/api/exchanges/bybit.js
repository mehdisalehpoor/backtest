const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://api2.bybit.com/spot/api/quote/v2/",
        symbol: baseSymbol + quoteSymbol,
        exchange: "bybit",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            const params = {
                symbol: symbol,
                interval: timeframe,
                startTime: startTime * 1000,
                endTime: endTime * 1000
            };

            const response = await axios.get(url + "klines", { params });

            const data = response.data.result;

            return data.map(kline => ([
                kline.t,//timestamp
                kline.o,//open
                kline.h,//high
                kline.l,//low
                kline.c,//close
                kline.v,//volume
            ]));
        },
    };
};
