const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "_" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "crypto-com-exchange",
    symbol: await fixSymbolName(symbol),
    url: `wss://stream.crypto.com/exchange/v1/market`,

    getSubscribeMessage: (symbol) => {
      return {
        method: "subscribe",
        params: {
          channels: [`book.${symbol}`],
        },
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.result?.data?.[0]?.asks || [];
      const bids = message?.result?.data?.[0]?.bids || [];
      return { asks, bids };
    },
  };
};
