const axios = require("axios");
const ProxyService = require("./ProxyService");

class OKXService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://aws.okx.com/api/v5/market/books",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        instId: `${symbol}-USDT`,
        sz: 400,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook[0].asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook[0].bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = OKXService;
