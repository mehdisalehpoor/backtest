import { createServer } from "http";
import express from "express";
import { Server } from "socket.io";

class WebRtcServer {
  constructor() {
    this.activeUsers = [];
    this.app = express();
    this.server = createServer(this.app);
    this.io = new Server(this.server, {
        cors: {
          origin: "*",
          methods: ["*"]
        }
      });
    this.port = process.env.WEBRTC_PORT || 3015;
    this.run();
  }

  run() {
    this.app.use(express.static("resources/views/stream"));

    this.io.on("connection", (socket) => {
      const socketExist = this.activeUsers.find(
        (socketExist) => socketExist === socket.id
      );

      if (!socketExist) {
        this.activeUsers.push(socket.id);

        socket.emit("update-user-list", {
          users: this.activeUsers.filter(
            (socketExist) => socketExist !== socket.id
          ),
        });

        socket.broadcast.emit("update-user-list", { users: [socket.id] });
      }

      socket.on("call-user", (data) => {
        socket.to(data.to).emit("call-made", {
          offer: data.offer,
          socket: socket.id,
        });
      });

      socket.on("make-answer", (data) => {
        socket.to(data.to).emit("answer-made", {
          socket: socket.id,
          answer: data.answer,
        });
      });

      socket.on("reject-call", (data) => {
        socket.to(data.from).emit("call-rejected", {
          socket: socket.id,
        });
      });

      socket.on("disconnect", () => {
        this.activeUsers = this.activeUsers.filter(
          (socketExist) => socketExist !== socket.id
        );

        socket.broadcast.emit("remove-user", {
          socketId: socket.id,
        });
      });
    });

    this.server.listen(this.port, () =>
      console.log(`WebRtc is running on port ${this.port}`)
    );
  }
}

module.exports = WebRtcServer;
