const axios = require("axios");
const ProxyService = require("./ProxyService");

class BitService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.bit.com/linear/v1/orderbooks",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        instrument_id: `${symbol}-USDT-PERPETUAL`,
        level: 50,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = BitService;
