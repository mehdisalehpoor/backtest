
class Controller {
    static async index(req, res, next) {

    }

    static async handle(req, res, next) {
        try {
            this.index(req, res, next);
        } catch (error) {
            next(error);
        }
    }
}