const axios = require("axios");
const SymbolModel = require("../Models/SymbolModel");
const TelegramBotService = require("../Services/TelegramBotService");

const getDecimalsPrecision = (number) => {
  if (String(number).includes(".")) {
    return String(String(number).indexOf("1") - 1);
  } else {
    return String(number);
  }
};

const runGetSymbolsDataJob = async () => {
  try {
    const apiUrl = "http://212.64.223.186:3013/v1/symbol";
    const exchangeInfoUrl = `${apiUrl}/exchangeInfo`;

    // Fetch exchange info
    const { data: exchangeInfo } = await axios.get(exchangeInfoUrl);

    // Fetch symbols from SymbolModel where futures is true
    const symbols = await SymbolModel.findAll({
      where: { futures: true},
    });

    const result = [];

    // Process each symbol
    for (const symbol of symbols) {
      const leverageUrl = `${apiUrl}/leverageBracket`;
      const params = { symbol: `${symbol.symbol}USDT` };

      try {
        // Fetch leverage data for the symbol
        const { data: leverageResponse } = await axios.get(leverageUrl, {
          params,
        });

        // Find initialLeverageTen
        const initialLeverageTen = leverageResponse[0].brackets.find(
          (bracket) => bracket.initialLeverage === 10
        );

        // Find symbolExchangeData
        const symbolExchangeData = exchangeInfo.symbols.find(
          (item) => item.symbol === `${symbol.symbol}USDT`
        );

        const tickSizeNumberOfDecimals = parseInt(
          getDecimalsPrecision(symbolExchangeData.filters[0].tickSize)
        );

        const stepSizeNumberOfDecimals = parseInt(
          getDecimalsPrecision(symbolExchangeData.filters[1].stepSize)
        );

        // Prepare leverage data
        const leverageData = {
          symbol: leverageResponse[0].symbol,
          initialLeverageTen: initialLeverageTen,
          baseAssetPrecision: tickSizeNumberOfDecimals,
          tickSize: symbolExchangeData.filters[0].tickSize
        };

        // Update SymbolModel if initialLeverageTen exists
        if (initialLeverageTen) {
          await SymbolModel.update(
            {
              initialLeverage: 10,
              baseAssetPrecision: tickSizeNumberOfDecimals,
              stepAssetPrecision: stepSizeNumberOfDecimals,
            },
            { where: { id: symbol.id } }
          );
        }

        // Push leverageData to result array
        result.push(leverageData);
      } catch (error) {
        var message = symbol.symbol + " " + error;
        TelegramBotService.futuresSignalSend("GetSymbolsDataJob " + message);
      }
    }

    return result;
  } catch (error) {
    TelegramBotService.futuresSignalSend("GetSymbolsDataJob " + error);
  }
};

runGetSymbolsDataJob();