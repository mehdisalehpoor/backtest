const axios = require("axios");
const ProxyService = require("./ProxyService");

class CoinBaseService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: `https://api.pro.coinbase.com/products/${symbol}-USDT/book`,
    });

    const agent = await ProxyService.getProxyAddress();

    const response = await axiosClient.get("", {
      params: {
        level: 2,
      },
      httpsAgent: agent,
    });

    const orderBook = response.data;
    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = CoinBaseService;
