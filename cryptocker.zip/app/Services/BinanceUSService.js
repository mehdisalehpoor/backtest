const axios = require("axios");

class BinanceUSService {
  static async getOrderbook(symbol) {
    const axiosClient = axios.create({
      baseURL: "`https://api.binance.us/api/v3/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const response = await axiosClient.get("", {
      params: {
        symbol: `${symbol}`,
        limit: 5000,
      },
      httpsAgent: agent,
    });

    const formattedResponse = {
      asks: response.data.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: response.data.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };
    return formattedResponse;
  }
}

module.exports = BinanceUSService;
