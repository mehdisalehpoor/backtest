const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://api.kucoin.com/api/v1/market/",
        symbol: baseSymbol + "-" + quoteSymbol,
        exchange: "kucoin",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
          
            let type = "1d";
            if(timeframe == "4h"){
                type = "4hour";
            }

            if(timeframe == "1h"){
                type = "1hour";
            }

            if(timeframe == "1d"){
                type = "1day";
            }

            if(timeframe == "1w"){
                type = "1week";
            }

            const params = {
                symbol: symbol,
                type,
                startAt: startTime,
                endAt: endTime
            };

            const response = await axios.get(url + "candles", { params });
            const data = response.data.data.reverse();
            
            return data.map(kline => ([
                kline[0],//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
