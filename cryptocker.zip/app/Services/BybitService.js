const ProxyService = require("./ProxyService");
const axios = require('axios');

class BybitService {

  static async getOrderbook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.bybit.com/spot/v3/public/quote/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}USDT`,
        limit: 200,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;

    const asks = orderBook.result.asks.map((item) => [
      parseFloat(item[0]),
      parseFloat(item[1]),
    ]);
    const bids = orderBook.result.bids.map((item) => [
      parseFloat(item[0]),
      parseFloat(item[1]),
    ]);

    return { asks, bids };
  }
}

module.exports = BybitService;
