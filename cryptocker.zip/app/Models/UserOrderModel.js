const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const UserOrderModel = sequelize.define(
  "user_orders",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbol: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    OrderId: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    origQty: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    price: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    stopPrice: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    exit: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

module.exports = UserOrderModel;
