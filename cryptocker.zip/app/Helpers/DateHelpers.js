class DateHelpers {
  changeDateTime(datetime) {
    const date = new Date(datetime);
    let dateString =
      date.getFullYear() +
      "-" +
      this.padZero(date.getMonth() + 1) +
      "-" +
      this.padZero(date.getDate()) +
      " " +
      this.padZero(date.getHours()) +
      ":" +
      this.padZero(date.getMinutes()) +
      ":" +
      this.padZero(date.getSeconds());

    return dateString;
  }
  padZero(num) {
    return num.toString().padStart(2, "0");
  }

  static today() {
    const today = new Date();
    const startOfToday = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );
    const endOfToday = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate() + 1
    );
    return { startOfToday, endOfToday };
  }

  static lastOneHour() {
    const now = new Date();
    const startOfLastHour = new Date(now.getTime() - 2 * 60 * 60 * 1000); // Subtract 1 hour in milliseconds
    const endOfLastHour = new Date(now.getTime());

    return { startOfLastHour, endOfLastHour };
  }

  static lastFourHour() {
    const now = new Date();
    const startOfLastFourHour = new Date(now.getTime() - 4 * 60 * 60 * 1000); // Subtract 4 hours in milliseconds
    const endOfLastFourHour = new Date(now.getTime()); // Current time    

    return { startOfLastFourHour, endOfLastFourHour };
  }

  static lastTwentyFourHours() {
    const now = new Date();
    const startOfLastTwentyFourHours = new Date(now.getTime() - 24 * 60 * 60 * 1000); // Subtract 24 hours in milliseconds
    const endOfLastTwentyFourHours = new Date(now.getTime()); // Current time    
  
    return { startOfLastTwentyFourHours, endOfLastTwentyFourHours };
  }

  static lastHours(hours) {
    const now = new Date();
    const startOfLastHours = new Date(now.getTime() - hours * 60 * 60 * 1000); // Subtract 24 hours in milliseconds
    const endOfLastHours = new Date(now.getTime()); // Current time    
  
    return { startOfLastHours, endOfLastHours };
  }
}

module.exports = DateHelpers;
