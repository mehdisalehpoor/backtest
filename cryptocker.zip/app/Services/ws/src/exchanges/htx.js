const zlib = require("zlib");

const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toLowerCase() + quote.toLowerCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "htx",
    symbol: await fixSymbolName(symbol),
    url: `wss://api.huobi.pro/ws`,
    getSubscribeMessage: (symbol) => {
      return {
        sub: `market.${symbol}.depth.step0`,
        id: "id1",
      };
    },
    parseMessage: (data) => {
      const buf = Buffer.from(data);
      data = zlib.gunzipSync(buf).toString("utf-8");
      const message = JSON.parse(data);
      const asks = message?.tick?.asks || [];
      const bids = message?.tick?.bids || [];
      return { asks, bids };
    },
  };
};
