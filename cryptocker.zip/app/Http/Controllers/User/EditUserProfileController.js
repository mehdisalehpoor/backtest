import UserModel from "../../../Models/UserModel";
import { ErrorCode } from "../../../Exceptions/errorCode";

class EditUserProfileController {
  static async handle(req, res, next) {
    const { id } = req.decodedToken;
    const { email, username } = req.body;

    try {
      const user = await UserModel.findOne({ where: { id: id } });

      if (user) {
        user.email = email ? email : user.email;
        user.username = username ? username : user.username;
        await user.save();
        res.response(user);
      } else {
        throw new Handler(ErrorCode.USER_NOT_EXISTS);
      }
    } catch (err) {
      next(err);
    }
  }
}

export default EditUserProfileController;
