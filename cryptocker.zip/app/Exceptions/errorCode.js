import { StatusCodes } from "http-status-codes";
import { i18n } from "../../config/configs";

const ErrorCode = {
  INTERNAL_SERVER_ERROR: 1,
  USER_EXISTS: 2,
  USER_NOT_EXISTS: 3,
  USER_PASSWORD_INCORRECT: 4,
  INVALID_JWT: 5,
  VALIDATION_FAILED: 6,
};

const getError = (errorCode) => {
  switch (errorCode) {
    case ErrorCode.INTERNAL_SERVER_ERROR:
      return [StatusCodes.INTERNAL_SERVER_ERROR, i18n.__("server_error")];

    case ErrorCode.USER_EXISTS:
      return [StatusCodes.CONFLICT, i18n.__("user_exists")];

    case ErrorCode.USER_NOT_EXISTS:
      return [StatusCodes.NOT_FOUND, i18n.__("user_not_exists")];

    case ErrorCode.USER_PASSWORD_INCORRECT:
      return [StatusCodes.UNPROCESSABLE_ENTITY, i18n.__("input_incorrect")];

    case ErrorCode.INVALID_JWT:
      return [StatusCodes.UNAUTHORIZED, i18n.__("unauthenticated")];

    case ErrorCode.VALIDATION_FAILED:
      return [StatusCodes.CONFLICT, i18n.__("unauthenticated")];

    default:
      return [StatusCodes.INTERNAL_SERVER_ERROR, i18n.__("server_error")];
  }
};

module.exports = {
  ErrorCode,
  getError,
};
