<?php
require './ccxt-master/ccxt/vendor/autoload.php';

use ccxt\binance;

$binance = new binance();

$ticker = $binance->fetch_ticker('BTC/USDT');
print_r($ticker);

exit();


// Define an array mapping exchange names to service functions
$exchangeMap = [
    'binance' => 'getBinanceOrderbook',
    'mexc' => 'getMexcOrderbook',
    'xt' => 'getXTOrderbook',
    'whitebit' => 'getWhiteBitOrderbook',
    'toobit' => 'getTooBitOrderbook',
    'tokocrypto' => 'getTokoCryptoOrderbook',
    'probit' => 'getProbitOrderbook',
    'poloniex' => 'getPoloniexOrderBook',
    'pionex' => 'getPionexOrderbook',
    'orangex' => 'getOrangeXOrderbook',
    'okx' => 'getOkxOrderbook',
    'lbank' => 'getLBankOrderbook',
    'latoken' => 'getLatokenOrderbook',
    'huobi' => 'getHuobiOrderbook',
    'hotcoin' => 'getHotcoinOrderbook',
    'gate' => 'getGateOrderbook',
    'digifinex' => 'getDigiFinexOrderbook',
    'fameex' => 'getFameexOrderbook',
    'deepcoin' => 'getDeepCoinOrderbook',
    'coinex' => 'getCoinexOrderbook',
    'coinbase' => 'getCoinBaseOrderbook',
    'bingx' => 'getBingxOrderbook',
    'bybit' => 'getBybitOrderbook',
    'kraken' => 'getKrakenOrderbook',
    'bitget' => 'getBitgetOrderbook',
    'kucoin' => 'getKucoinOrderbook',
    'bitrue' => 'getBitrueOrderbook',
    'bitmart' => 'getBitmartOrderbook',
    'bitforex' => 'getBitforexOrderbook',
    'ascendex' => 'getAscendexOrderbook',
];

// Check if the "type", "exchange", and "symbol" parameters are set
if (isset($_GET['type'], $_GET['exchange'], $_GET['symbol'])) {
    $type = $_GET['type'];
    $exchange = $_GET['exchange'];
    $symbol = $_GET['symbol'];

    if ($type == 'orderbook') {
        // Check if the specified exchange exists in the mapping
        if (array_key_exists($exchange, $exchangeMap)) {
            // Call the corresponding service function based on the exchange
            $orderbook = call_user_func([ExchangeService::class, $exchangeMap[$exchange]], $symbol);
            echo json_encode($orderbook);
        } else {
            echo "Specified exchange is not supported<br>";
        }
    } else {
        echo "Invalid type parameter<br>";
    }
} else {
    echo "Required parameters are not set<br>";
}
