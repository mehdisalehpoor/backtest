const WebSocket = require("ws");
const boxCalculate = require("../utils/boxCalculate");
const zlib = require("zlib");
const util = require("util");

const deflateAsync = util.promisify(zlib.deflate);

class WebSocketClient {
  constructor(config, baseSymbol) {
    this.config = config;
    this.symbol = config.symbol;
    this.baseSymbol = baseSymbol;

    this.connect();
  }

  connect() {
    this.ws = new WebSocket(this.config.url);

    this.ws.on("open", this.onOpen.bind(this));
    this.ws.on("message", this.onMessage.bind(this));
    this.ws.on("error", this.onError.bind(this));
    this.ws.on("close", this.onClose.bind(this));
  }
  async onOpen() {
    const subscribeMessage = this.config.getSubscribeMessage(this.symbol);
    await this.ws.send(JSON.stringify(subscribeMessage));

    console.log(
      `Connected to ${this.config.exchange} WebSocket server for ${this.symbol} order book updates`
    );
  }

  async onMessage(data) {
    const parsedData = this.config.parseMessage(data);
    const box = await boxCalculate(
      parsedData,
      this.baseSymbol,
      this.config.exchange
    );
    console.log(box);
    // // Convert the box object to JSON string and then to a buffer
    // const jsonString = JSON.stringify(box);
    // const jsonBuffer = Buffer.from(jsonString);

    // // Calculate and log the size of the uncompressed data
    // const uncompressedSize = jsonBuffer.length;
    // const readableUncompressedSize = await this.bytesToSize(uncompressedSize);
    // console.log("Uncompressed Size:", readableUncompressedSize);

    // // Compress the buffer
    // const compressedBuffer = await deflateAsync(jsonBuffer);

    // // Calculate and log the size of the compressed data
    // const compressedSize = compressedBuffer.length;
    // const readableCompressedSize = await this.bytesToSize(compressedSize);
    // console.log("Compressed Size:", readableCompressedSize);
  }

  async bytesToSize(bytes) {
    var sizes = ["Bytes", "KB", "MB", "GB", "TB"];
    if (bytes == 0) return "n/a";
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    if (i == 0) return bytes + " " + sizes[i];
    return (bytes / Math.pow(1024, i)).toFixed(1) + " " + sizes[i];
  }

  onError(error) {
    console.error(error);
  }

  async onClose() {
    console.log(
      `WebSocket connection closed for ${this.symbol}. Reconnecting...`
    );
    this.connect(); // Reconnect
  }
}

module.exports = WebSocketClient;
