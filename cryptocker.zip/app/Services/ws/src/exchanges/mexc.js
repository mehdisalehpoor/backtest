const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "_" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "mexc",
    symbol: await fixSymbolName(symbol),
    url: `wss://wbs.mexc.com/ws`,

    getSubscribeMessage: (symbol) => {
      return {
        method: "SUBSCRIPTION",
        params: [`spot@public.limit.depth.v3.api@${symbol}@20`],
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.d?.asks || [];
      const bids = message?.d?.bids || [];
      return { asks, bids };
    },
  };
};
