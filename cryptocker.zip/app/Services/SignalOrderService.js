const axios = require("axios");
const TelegramBotService = require("../Services/TelegramBotService");
const UserModel = require("../Models/UserModel");
const BinanceService = require("./BinanceService");
const SymbolModel = require("../Models/SymbolModel");

class SignalOrderService {
  static addOrderForUsers = async (symbol, side) => {
    return;
    try {
      const users = await UserModel.findAll({
        where: {
          status: true,
        },
      });

      const symbolModel = await SymbolModel.findOne({
        where: {
          symbol: symbol,
        },
      });

      await Promise.all(
        users.map(async (user) => {
          try {
            const accountInformationApiUrl = `http://${user.ip}:3013/v1/symbol/account`;
            const positionRiskApiUrl = `http://${user.ip}:3013/v1/order/positionRisk`;
            const orderApiUrl = `http://${user.ip}:3013/v1/order/addOrder`;

            const positionRisk = await axios
              .post(positionRiskApiUrl, {
                symbol: symbol + "USDT",
              })
              .then(async (response) => {
                const positionSide = side == "buy" ? "LONG" : "SHORT";

                const liquidationData = response.data.filter(
                  (item) =>
                    item.liquidationPrice !== "0" &&
                    item.positionSide === positionSide
                );

                if (liquidationData.length === 0) {
                  const accountInformation = await axios.get(
                    accountInformationApiUrl
                  );

                  const usdtAsset = accountInformation.data.assets.find(
                    (asset) => asset.asset === "USDT"
                  );

                  // Extract the asset value
                  const walletBalance = parseFloat(usdtAsset.walletBalance);

                  const futuresPrice = await BinanceService.getFuturesPrice(
                    symbol
                  );

                  const quantity =
                    (walletBalance /
                      user.capitalDivision /
                      parseFloat(futuresPrice)) *
                    symbolModel.initialLeverage;

                  await SignalOrderService.addOrderAndStoploss(
                    symbol,
                    side,
                    quantity,
                    symbolModel,
                    orderApiUrl,
                    positionSide,
                    user,
                    walletBalance
                  );

                  UserModel.update(
                    {
                      balance: walletBalance,
                    },
                    {
                      where: {
                        id: user.id,
                      },
                    }
                  );
                } else {
                  const message = "Order already exists in " + symbol;
                  TelegramBotService.sendLogToUser(
                    "SignalOrderService " + message,
                    user
                  );
                }
              })
              .catch((error) => {
                // TODO: log in telegram bot
                
                TelegramBotService.sendLogToUser(JSON.stringify(error.data), user);
              });
          } catch (error) {
            console.log(error);
            TelegramBotService.sendLogToUser(error, user);
          }
        })
      );

      return users;
    } catch (error) {
      TelegramBotService.futuresSignalSend("SignalOrderService " + error);
    }
  };

  static exitOrderForUsers = async (symbol, side) => {
    return;
    try {
      const users = await UserModel.findAll({
        where: {
          status: true,
        },
      });

      await Promise.all(
        users.map(async (user) => {
          try {
            const accountInformationApiUrl = `http://${user.ip}:3013/v1/symbol/account`;
            const positionRiskApiUrl = `http://${user.ip}:3013/v1/order/positionRisk`;
            const cancelAllOrdersApiUrl = `http://${user.ip}:3013/v1/order/cancelAllOrders`;
            const orderApiUrl = `http://${user.ip}:3013/v1/order/addOrder`;

            const positionRisk = await axios
              .post(positionRiskApiUrl, {
                symbol: symbol + "USDT",
              })
              .then(async (response) => {
                const positionSide = side == "buy" ? "LONG" : "SHORT";

                const liquidationData = response.data.filter(
                  (item) =>
                    item.liquidationPrice !== "0" &&
                    item.positionSide === positionSide
                );
                console.log(liquidationData);
                if (liquidationData.length != 0) {
                  const exitOrder = liquidationData[0];

                  const accountInformation = await axios.get(
                    accountInformationApiUrl
                  );

                  const usdtAsset = accountInformation.data.assets.find(
                    (asset) => asset.asset === "USDT"
                  );

                  // Extract the asset value
                  const walletBalance = parseFloat(usdtAsset.walletBalance);
                  console.log(walletBalance);

                  if (exitOrder.positionSide == "SHORT") {
                    var quatity = parseFloat(exitOrder.positionAmt) * -1;
                  } else {
                    var quatity = parseFloat(exitOrder.positionAmt);
                  }

                  const exitParams = {
                    symbol: exitOrder.symbol,
                    side: exitOrder.positionSide === "LONG" ? "SELL" : "BUY",
                    positionSide: exitOrder.positionSide,
                    type: "MARKET",
                    quantity: quatity,
                  };

                  const exitOrderResponse = await axios
                    .post(orderApiUrl, exitParams)
                    .then(async (response) => {
                      const order = response.data;

                      var text = `[FUTURES]\n#closePosition\nSymbol=${order.symbol}\nPosition=${order.positionSide}\nQuantity=${order.origQty}\nBalance=${walletBalance}`;
                      TelegramBotService.sendLogToUser(text, user);
                    })
                    .catch((error) => {
                      console.log(error);
                      var errorResponse = error;
                      var error = `[FUTURES]\n#order\n${errorResponse}`;
                      TelegramBotService.sendLogToUser(error, user);
                    });

                  UserModel.update(
                    {
                      balance: walletBalance,
                    },
                    {
                      where: {
                        id: user.id,
                      },
                    }
                  );
                  const cancelAllOrders = await axios
                    .post(cancelAllOrdersApiUrl, { symbol: exitOrder.symbol })
                    .then(async (response) => {
                      // TODO: log in telegram bot
                      console.log("cancel all orders");
                    })
                    .catch((error) => {
                      // TODO: log in telegram bot
                      console.error(error.response.data);
                    });
                } else {
                  const message = "there is no order in " + symbol;
                  TelegramBotService.sendLogToUser(
                    "SignalOrderService " + symbol + " " + message,
                    user
                  );
                }
              })
              .catch((error) => {
                // TODO: log in telegram bot
                console.log(error);
                TelegramBotService.sendLogToUser(JSON.stringify(error.data), user);
              });
          } catch (error) {
            TelegramBotService.sendLogToUser(error, user);
          }
        })
      );

      return users;
    } catch (error) {
      console.log(error);
      TelegramBotService.futuresSignalSend("SignalOrderService " + error);
    }
  };

  static async addOrderAndStoploss(
    symbol,
    side,
    quantity,
    symbolModel,
    orderApiUrl,
    positionSide,
    user,
    balance = 0
  ) {
    const orderParams = {
      symbol: symbol + "USDT",
      side: side.toUpperCase(), // BUY or SELL
      positionSide: side == "buy" ? "LONG" : "SHORT", // SHORT or LONG
      type: "MARKET", // MARKET or LIMIT
      quantity:
        parseInt(symbolModel.stepAssetPrecision) > 1
          ? parseFloat(quantity.toFixed(symbolModel.stepAssetPrecision - 1))
          : parseFloat(quantity.toFixed(0)),
    };

    const addOrderResponse = await axios
      .post(orderApiUrl, orderParams)
      .then(async (response) => {
        const order = response.data;

        const price = await BinanceService.getFuturesPrice(symbol);

        const stopPriceLoss =
          positionSide === "LONG"
            ? parseFloat(price) - parseFloat(price) * 0.01
            : parseFloat(price) + parseFloat(price) * 0.01;

        const stopLoss = {
          symbol: order.symbol,
          side: positionSide === "LONG" ? "SELL" : "BUY",
          positionSide: order.positionSide,
          type: "STOP",
          quantity: order.origQty,
          stopPrice: parseFloat(
            stopPriceLoss.toFixed(symbolModel.baseAssetPrecision)
          ),
          price: parseFloat(
            stopPriceLoss.toFixed(symbolModel.baseAssetPrecision)
          ),
        };

        var stopPrice = "";

        const addStopOrderResponse = await axios
          .post(orderApiUrl, stopLoss)
          .then(async (response) => {
            const stopOrder = response.data;
            stopPrice = `StopPrice=${stopOrder.stopPrice}`;
            // TODO: log in telegram bot
            console.log("Done STOP order");
          })
          .catch((error) => {
            // TODO: log in telegram bot
            TelegramBotService.sendLogToUser(error.response.data, user);
          });

        var text = `[FUTURES]\n#openPosition\nSymbol=${order.symbol}\nPosition=${order.positionSide}\nQuantity=${order.origQty}\nBalance=${balance}\n${stopPrice}`;
        TelegramBotService.sendLogToUser(text, user);
      })
      .catch((error) => {
        // TODO: log in telegram bot
        TelegramBotService.sendLogToUser(error.response.data, user);
      });
  }
}

module.exports = SignalOrderService;
