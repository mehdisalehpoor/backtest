const zlib = require("zlib");

exports.getConfig = async (symbol) => {
  return {
    url: "wss://open-api-ws.bingx.com/market",
    symbol: await fixSymbolName(symbol),
    exchange: "bingx",
    getSubscribeMessage: (symbol) => {
      return {
        id: "id1",
        reqType: "sub",
        dataType: `${symbol}@depth50`,
      };
    },
    parseMessage: (data) => {
      const buf = Buffer.from(data);
      data = zlib.gunzipSync(buf).toString("utf-8");
      const message = JSON.parse(data);
      return {
        asks: message?.data?.asks || [],
        bids: message?.data?.bids || [],
      };
    },
  };
};

const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "-" + quote.toUpperCase();
};
