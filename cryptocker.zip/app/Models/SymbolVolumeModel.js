const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");
const SymbolModel = require("./SymbolModel");

const SymbolVolumeModel = sequelize.define(
  "symbol_volume",
  {
    id: {
      type: DataTypes.BIGINT,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbolId: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    spotPrice: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    asksVolume: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    bidsVolume: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    bidsDensityVolume: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    asksDensityVolume: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    payload: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    exchangesVolume: {
      type: DataTypes.BIGINT,
      allowNull: true,
    },
    signalType: {
      type: DataTypes.STRING(30),
      allowNull: true,
    },
    begin: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

SymbolVolumeModel.belongsTo(SymbolModel, {
  foreignKey: "symbolId", // Use the correct foreign key name
  as: "symbol",
});

// Export the intermediary table model along with the SymbolModel and ExchangeModel
module.exports = SymbolVolumeModel;
