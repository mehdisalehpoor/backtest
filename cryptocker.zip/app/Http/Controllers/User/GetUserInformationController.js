import UserModel from "../../../Models/UserModel";
import { ErrorCode } from "../../../Exceptions/errorCode";

class GetUserInformationController {
  static async handle(req, res, next) {
    const { id } = req.decodedToken;

    try {
      const user = await UserModel.findOne({ where: { id: id } });

      if (user) {
        res.response(user);
      } else {
        throw new Handler(ErrorCode.USER_NOT_EXISTS);
      }
    } catch (err) {
      next(err);
    }
  }
}

export default GetUserInformationController;
