<?php

class ExchangeService
{
    const BINANCE_API_URL = 'https://api.binance.com/api/v3';
    const BINANCE_TR_API_URL = 'https://api.binance.me/api/v3/depth';
    const MEXC_API_BASE_URL = 'https://www.mexc.com/open/api/v2/market';
    const XT_API_BASE_URL = 'https://sapi.xt.com/v4/public/depth';
    const WHITEBIT_API_BASE_URL = 'https://whitebit.com/api/v2/public/depth';
    const TOOBIT_API_BASE_URL = 'https://api.toobit.com/quote/v1/depth';
    const TOKOCRYPTO_API_BASE_URL = 'https://www.tokocrypto.com/open/v1/market/depth';
    const PROBIT_API_BASE_URL = "https://api.probit.com/api/exchange/v1/order_book";
    const POLONIEX_API_BASE_URL = "https://api.poloniex.com/markets/";
    const PIONEX_API_BASE_URL = "https://api.pionex.com/api/v1/market/depth";
    const ORANGEX_API_BASE_URL = "https://api.orangex.com/api/v1/public/get_order_book";
    const OKX_API_BASE_URL = "https://aws.okx.com/api/v5/market/books";
    const LBANK_API_BASE_URL = "https://api.lbkex.com/v2/depth.do";
    const LATOKEN_API_BASE_URL = "https://api.latoken.com/api/v1/marketData/orderBook/";
    const HUOBI_API_BASE_URL = "https://api.huobi.pro/market/depth";
    const HOTCOIN_API_BASE_URL = "https://api.hotcoinfin.com/v1/trade";
    const GATE_API_BASE_URL = "https://api.gateio.ws/api/v4/spot/order_book";
    const FAMEEX_API_BASE_URL = "https://api.fameex.com/api/v2/orderbook";
    const DIGIFINEX_API_BASE_URL = "https://openapi.digifinex.com/v3/order_book";
    const DEEPCOIN_API_BASE_URL = "https://api.deepcoin.com/deepcoin/market/books";
    const COINEX_API_BASE_URL = "https://api.coinex.com/v1/market/depth";
    const COINBASE_API_BASE_URL = "https://api.pro.coinbase.com/products/";
    const BYBIT_API_BASE_URL = "https://api.bybit.com/v5/market/orderbook";
    const KRAKEN_API_BASE_URL = "https://api.kraken.com/0/public/Depth";
    const BITGET_API_BASE_URL = "https://api.bitget.com/api/v2/spot/market/";
    const KUCOIN_API_BASE_URL = "https://api.kucoin.com/api/v1/market/orderbook/";
    const BITRUE_API_BASE_URL = "https://www.bitrue.com/api/v1/depth";
    const BITMART_API_BASE_URL = "https://api-cloud.bitmart.com/spot/quotation/v3/books";
    const BITFOREX_API_BASE_URL = "https://api.bitforex.com/api/v1/market/depth";
    const ASCENDEX_API_BASE_URL = "https://ascendex.com/api/pro/v1/depth";
    const BITVENUS_API_BASE_URL = "https://www.bitvenus.com/openapi/quote/v1/depth";

    public static function getBinanceOrderbook($symbol)
    {
        try {
            $url = self::BINANCE_API_URL . '/depth?symbol=' . urlencode($symbol) . 'USDT&limit=5000';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode != 200) {
                throw new Exception($response);
            }

            curl_close($ch);

            $orderBook = json_decode($response, true);

            return [
                "success" => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getBinanceTrOrderbook($symbol)
    {
        try {
            $url = self::BINANCE_TR_API_URL . '?symbol=' . urlencode($symbol) . 'USDT&limit=500';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode != 200) {
                throw new Exception($response);
            }

            curl_close($ch);

            $orderBook = json_decode($response, true);

            return [
                "success" => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getMexcOrderbook($symbol)
    {
        $API_BASE_URL = self::MEXC_API_BASE_URL; // MXC API base URL
        $TRADING_PAIR = $symbol . "_USDT";
        try {

            $params = [
                'symbol' => $TRADING_PAIR,
                'depth' => 2000, // You can adjust the number of levels you want to retrieve
            ];

            $url = $API_BASE_URL . "/depth?" . http_build_query($params);

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode != 200) {
                throw new Exception($response);
            }

            $responseData = json_decode($response, true);
            curl_close($ch);

            $orderBook = $responseData['data'];
            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item['price'],
                        $item['quantity'],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item['price'],
                        $item['quantity'],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getXTOrderbook($symbol)
    {
        $API_BASE_URL = self::XT_API_BASE_URL; // XT API base URL
        $TRADING_PAIR = strtolower($symbol) . '_usdt';
        try {

            $params = [
                'symbol' => $TRADING_PAIR,
                'limit' => 500, // You can adjust the number of levels you want to retrieve
            ];

            $url = $API_BASE_URL . "?" . http_build_query($params);

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);


            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode != 200) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);

            // Check for cURL errors
            if ($responseData['rc'] != 0) {
                throw new Exception($response);
            }
            $orderBook = $responseData['result'];
            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [$item[0], $item[1]];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [$item[0], $item[1]];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['mc']
            ];
        }
    }

    public static function getWhiteBitOrderbook($symbol)
    {
        $API_BASE_URL = self::WHITEBIT_API_BASE_URL; // MXC API base URL
        $TRADING_PAIR = $symbol . "_USDT";
        try {

            $url = $API_BASE_URL . "/" . $TRADING_PAIR;

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            $responseData = json_decode($response, true);

            if (!$responseData['success']) {
                throw new Exception($response);
            }
            curl_close($ch);

            $orderBook = $responseData['result'];
            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getTooBitOrderbook($symbol)
    {
        $API_BASE_URL = self::TOOBIT_API_BASE_URL; // MXC API base URL
        $TRADING_PAIR = $symbol . "USDT";
        try {

            $params = [
                'symbol' => $TRADING_PAIR,
                'limit' => 100, // You can adjust the number of levels you want to retrieve
            ];

            $url = $API_BASE_URL . "?" . http_build_query($params);

            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode != 200) {
                throw new Exception($response);
            }

            $responseData = json_decode($response, true);
            curl_close($ch);

            $orderBook = $responseData;
            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['a']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['b']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getTokoCryptoOrderbook($symbol)
    {
        try {
            $url = self::TOKOCRYPTO_API_BASE_URL . '?symbol=' . urlencode($symbol) . '_USDT&limit=500';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['code'] != 0) {
                throw new Exception($response);
            }


            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getProbitOrderbook($symbol)
    {
        try {
            $url = self::PROBIT_API_BASE_URL;
            $params = [
                'market_id' => "{$symbol}-USDT",
            ];

            $fullUrl = $url . '?' . http_build_query($params);

            $ch = curl_init($fullUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if ($httpCode != 200) {
                throw new Exception($response);
            }

            $orderBook = json_decode($response, true);
            curl_close($ch);

            $orderBookData = $orderBook['data'];

            $asks = array();
            $bids = array();
            foreach ($orderBookData as $item) {
                if ($item['side'] == 'buy') {
                    $asks[] = array($item['price'], $item['quantity']);
                }
            }
            foreach ($orderBookData as $item) {
                if ($item['side'] == 'sell') {
                    $bids[] = array($item['price'], $item['quantity']);
                }
            }

            return ['success' => true, "asks" => $asks, "bids" => $bids];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['errorCode']
            ];
        }
    }

    public static function getPoloniexOrderBook($symbol)
    {
        try {
            $baseUrl = self::POLONIEX_API_BASE_URL . "{$symbol}_USDT/orderBook";
            $limit = 100;

            $ch = curl_init($baseUrl . "?limit={$limit}");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $orderBookResponse = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($orderBookResponse);
            }

            $orderBookArray = json_decode($orderBookResponse, true);

            if ($orderBookArray['code']) {
                throw new Exception($orderBookResponse);
            }

            curl_close($ch);

            $asksOrderbook = $orderBookArray['asks'];
            $bidsOrderbook = $orderBookArray['bids'];
            $asks = [];
            $bids = [];

            for ($i = 0; $i < count($asksOrderbook); $i += 2) {
                $pair = [
                    $asksOrderbook[$i],
                    $asksOrderbook[$i + 1],
                ];
                $asks[] = $pair;
            }

            for ($i = 0; $i < count($bidsOrderbook); $i += 2) {
                $pair = [
                    $bidsOrderbook[$i],
                    $bidsOrderbook[$i + 1],
                ];
                $bids[] = $pair;
            }

            return ['success' => true, 'asks' => $asks, 'bids' => $bids];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return $error;
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getPionexOrderbook($symbol)
    {
        try {
            $url = self::PIONEX_API_BASE_URL . '?symbol=' . urlencode($symbol) . '_USDT&limit=1000';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if (!$responseData['result']) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);

            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getOrangeXOrderbook($symbol)
    {
        try {
            $url = self::ORANGEX_API_BASE_URL . '?instrument_name=' . urlencode($symbol) . '-USDT-SPOT&depth=1000';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);

            $orderBook = $responseData['result'];

            if (count($orderBook['asks']) == 0) {
                throw new Exception($response);
            }
            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => 'some error occurred'
            ];
        }
    }

    public static function getLBankOrderbook($symbol)
    {
        try {
            $url = self::LBANK_API_BASE_URL . '?symbol=' . strtolower($symbol) . '_usdt&size=60';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check HTTP status code
            curl_close($ch);

            $responseData = json_decode($response, true);

            if (!$responseData['data']) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);

            return [
                "success" => false,
                "message" => "something went wrong"
            ];
        }
    }

    public static function getOkxOrderbook($symbol)
    {
        try {
            $url = self::OKX_API_BASE_URL . '?instId=' . urlencode($symbol) . '-USDT&sz=400';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);

            if ($responseData['code'] != 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook[0]['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook[0]['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getLatokenOrderbook($symbol)
    {
        try {
            $url = self::LATOKEN_API_BASE_URL . $symbol . 'USDT/100';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            curl_close($ch);

            $responseData = json_decode($response, true);

            if ($responseData['status'] == "FAILURE") {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item['price'],
                        $item['quantity'],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item['price'],
                        $item['quantity'],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['error']
            ];
        }
    }

    public static function getHuobiOrderbook($symbol)
    {
        try {
            $url = self::HUOBI_API_BASE_URL . '?symbol=' . strtolower($symbol) . 'usdt&type=step0';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['status'] == "error") {
                throw new Exception($response);
            }

            $orderBook = $responseData['tick'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['err-msg']
            ];
        }
    }

    public static function getHotcoinOrderbook($symbol)
    {
        try {
            $url = self::HOTCOIN_API_BASE_URL . '?symbol=' . strtolower($symbol) . '_usdt&count=1000';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);
            if (!isset($responseData['code'])) {
                throw new Exception($response);
            }

            if ($responseData && isset($responseData['data']['trades'])) {
                $asks = [];
                $bids = [];

                foreach ($responseData['data']['trades'] as $trade) {
                    if ($trade['en_type'] === 'ask') {
                        $asks[] = [$trade['price'], $trade['amount']];
                    } elseif ($trade['en_type'] === 'bid') {
                        $bids[] = [$trade['price'], $trade['amount']];
                    }
                }

                return ['success' => true, 'bids' => $bids, 'asks' => $asks];
            } else {
                return ['success' => false, 'message' => 'Invalid trade'];
            }
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getGateOrderbook($symbol)
    {
        try {
            $url = self::GATE_API_BASE_URL . '?currency_pair=' . urlencode($symbol) . '_USDT&limit=5000';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);

            if (!isset($responseData['asks'])) {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getDigiFinexOrderbook($symbol)
    {
        try {
            $url = self::DIGIFINEX_API_BASE_URL . '?symbol=' . strtolower($symbol) . '_usdt&limit=5000';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            curl_close($ch);
            $responseData = json_decode($response, true);
            return $responseData;
            if ($responseData['code'] != 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => "some error occurred"
            ];
        }
    }

    public static function getFameexOrderbook($symbol)
    {
        try {
            $url = self::FAMEEX_API_BASE_URL . '?symbol=' . $symbol . '-USDT&limit=100';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            // Check HTTP status code
            curl_close($ch);
            $responseData = json_decode($response, true);

            if (count($responseData['asks']) == 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => "some error occurred"
            ];
        }
    }

    public static function getDeepCoinOrderbook($symbol)
    {
        try {
            $url = self::DEEPCOIN_API_BASE_URL . '?instId=' . $symbol . '-USDT&sz=400';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['code'] != 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getCoinexOrderbook($symbol)
    {
        try {
            $url = self::COINEX_API_BASE_URL . '?market=' . $symbol . 'USDT&merge=0.000001&limit=50';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['code'] != 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getCoinBaseOrderbook($symbol)
    {
        try {
            $url = self::COINBASE_API_BASE_URL . $symbol . '-USDT/book?level=2';
            $headers = [
                'Upgrade-Insecure-Requests: 1',
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
                'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
                'sec-ch-ua-mobile: ?0',
                'sec-ch-ua-platform: "Windows"',
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['message']) {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getBingxOrderbook($symbol)
    {
        try {
            $API_KEY = "RhiLOQk3urEgezVNWScIKJLkg5jTTgcfW30ZXlchEB9oCSxTSQM6ScnWAuljCwpmgpsEsz2RlGd5bhEOz6Q";
            $API_SECRET = "pRwKXzllSZVkkpbggljxn2gPsc5XPqtN869rqWwNNUPY7pQtHw3mfikx2xgFfJmGIT2D3VVE2TFm7IhBPRA";
            $HOST = "open-api.bingx.com";
            $api = [
                "uri" => "/openApi/spot/v1/market/depth",
                "method" => "GET",
                "payload" => [
                    "symbol" => $symbol . "-USDT",
                    "limit" => 1000
                ],

                "protocol" => "https"
            ];

            $timestamp = round(microtime(true) * 1000);
            $parameters = "timestamp=" . $timestamp;

            if ($api["payload"] != null) {
                foreach ($api["payload"] as $key => $value) {
                    $parameters .= "&$key=$value";
                }
            }

            $hash = hash_hmac("sha256", $parameters, $API_SECRET, true);
            $hashHex = bin2hex($hash);
            $sign = strtolower($hashHex);
            $url = "{$api["protocol"]}://{$HOST}{$api["uri"]}?{$parameters}&signature={$sign}";

            $options = [
                "http" => [
                    "header" => "X-BX-APIKEY: {$API_KEY}",
                    "method" => $api["method"]
                ],
                "ssl" => [
                    "verify_peer" => false,
                    "verify_peer_name" => false
                ]
            ];

            $context = stream_context_create($options);
            $response = file_get_contents($url, false, $context);

            $responseData = json_decode($response, true);
    
            $orderBook = $responseData['data'];
            if (count($orderBook['asks']) == 0) {
                throw new Exception($response);
            }
            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            return [
                "success" => false,
                "message" => "some error occurred"
            ];
        }
    }

    public static function getBybitOrderbook($symbol)
    {
        try {
            $url = self::BYBIT_API_BASE_URL . "?category=spot&symbol={$symbol}USDT&limit=200";
            $headers = [
                'Upgrade-Insecure-Requests: 1',
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
                'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
                'sec-ch-ua-mobile: ?0',
                'sec-ch-ua-platform: "Windows"',
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);

            if ($responseData['retCode'] != 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData['result'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['a']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['b']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['retMsg']
            ];
        }
    }

    public static function getKrakenOrderbook($symbol)
    {
        try {
            $url = self::KRAKEN_API_BASE_URL . "?pair={$symbol}USDT&count=500";
            $headers = [
                'Upgrade-Insecure-Requests: 1',
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
                'sec-ch-ua: "Not.A/Brand";v="8", "Chromium";v="114", "Google Chrome";v="114"',
                'sec-ch-ua-mobile: ?0',
                'sec-ch-ua-platform: "Windows"',
            ];
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);

            $responseData = json_decode($response, true);

            if ($responseData['error'] != []) {
                throw new Exception($response);
            }

            $orderBook = $responseData['result'];
            $firstKey = key($orderBook);

            // Access the data for the dynamic key
            $dynamicData = $orderBook[$firstKey];
            return $dynamicData;
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);

            return [
                "success" => false,
                "message" => $error['error']
            ];
        }
    }

    public static function getBitgetOrderbook($symbol)
    {
        try {
            $type = "step0";
            $limit = 150;

            $url = self::BITGET_API_BASE_URL . "orderbook?symbol={$symbol}USDT&type=$type&limit=$limit";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['msg'] != "success") {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getKucoinOrderbook($symbol)
    {
        try {
            $type = "step0";
            $limit = 150;

            $url = self::KUCOIN_API_BASE_URL . "level2_100?symbol=$symbol-USDT";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);
 
            $orderBook = $responseData['data'];

            if ($orderBook['time'] == 0) {
                throw new Exception($response);
            }

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => "some error occurred"
            ];
        }
    }

    public static function getBitrueOrderbook($symbol)
    {
        try {
            $limit = 200;

            $url = self::BITRUE_API_BASE_URL . "?symbol=$symbol" . "USDT&limit=$limit";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['code'] &&  $responseData['code'] < 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getBitmartOrderbook($symbol)
    {
        try {
            $limit = 50;

            $url = self::BITMART_API_BASE_URL . "?symbol=$symbol" . "_USDT&limit=$limit";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['data'] == null) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message'],
            ];
        }
    }

    public static function getBitforexOrderbook($symbol)
    {
        try {
            $limit = 200;
            $symbolFetch = "coin-usdt-" . strtolower($symbol);
            $url = self::BITFOREX_API_BASE_URL . "?symbol=$symbolFetch" . "&size=$limit";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['success'] == false) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item['price'],
                        $item['amount'],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item['price'],
                        $item['amount'],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }

    public static function getAscendexOrderbook($symbol)
    {
        try {
            $url = self::BITVENUS_API_BASE_URL . "?symbol=$symbol" . "USDT";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);

            if ($responseData['code']) {
                throw new Exception($response);
            }

            $orderBook = $responseData;

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['msg']
            ];
        }
    }

    public static function getBitvenusOrderbook($symbol)
    {
        try {
            $url = self::ASCENDEX_API_BASE_URL . "?symbol=$symbol" . "/USDT";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Upgrade-Insecure-Requests: 1']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);

            // Check for cURL errors
            if (curl_errno($ch)) {
                throw new Exception($response);
            }

            curl_close($ch);
            $responseData = json_decode($response, true);
 
            if ($responseData['code'] != 0) {
                throw new Exception($response);
            }

            $orderBook = $responseData['data'];

            return [
                'success' => true,
                'asks' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['asks']),
                'bids' => array_map(function ($item) {
                    return [
                        $item[0],
                        $item[1],
                    ];
                }, $orderBook['bids']),
            ];
        } catch (Exception $exception) {
            $error = json_decode($exception->getMessage(), true);
            return [
                "success" => false,
                "message" => $error['message']
            ];
        }
    }
}
