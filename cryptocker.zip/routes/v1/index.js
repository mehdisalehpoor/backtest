import express from "express";
import usersRouter from "./users";
import authRouter from "./auth";
import symbolRouter from "./symbol";
import signalRouter from "./signal";
import orderRouter from "./order";
import exchangeRouter from "./exchange";
import backTestRouter from "./backTest";

const v1Router = express.Router();

v1Router.use("/users", usersRouter);
v1Router.use("/auth", authRouter);
v1Router.use("/symbol", symbolRouter);
v1Router.use("/exchange", exchangeRouter);
v1Router.use("/signal", signalRouter);
v1Router.use("/order", orderRouter);
v1Router.use("/backtest", backTestRouter);

module.exports = v1Router;
