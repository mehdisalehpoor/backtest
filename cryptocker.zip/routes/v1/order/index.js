import express from "express";
import { AddOrderController } from "../../../app/Http/Controllers/Order/AddOrderController";
import { BinanceOrderController } from "../../../app/Http/Controllers/Order/BinanceOrderController";

const orderRouter = express.Router();

//  @desc   add order
//  @route  POST /order/add
orderRouter.post("/add", AddOrderController.handle);

//  @desc   add order
//  @route  POST /order/addOrder
orderRouter.post("/addOrder", BinanceOrderController.addOrder);

//  @desc   close order position
//  @route  POST /order/closePosition
orderRouter.post("/closePosition", BinanceOrderController.closePosition);


//  @desc   cancel order
//  @route  POST /order/cancelOrder
orderRouter.post("/cancelOrder", BinanceOrderController.cancelOrder);

//  @desc   cancel all orders
//  @route  POST /order/cancelAllOrders
orderRouter.post("/cancelAllOrders", BinanceOrderController.cancelAllOrders);

//  @desc   get order from binance
//  @route  POST /order/checkOrder
orderRouter.post("/checkOrder", BinanceOrderController.getOrder);

//  @desc   get positionRisk from binance
//  @route  POST /order/positionRisk
orderRouter.post("/positionRisk", BinanceOrderController.getPositionRisk);

module.exports = orderRouter;
