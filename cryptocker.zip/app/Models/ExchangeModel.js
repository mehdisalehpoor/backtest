const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const ExchangeModel = sequelize.define(
    "exchanges",
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
            allowNull: false,
        },
        name: {
            type: DataTypes.STRING(30),
            unique: true,
            allowNull: false,
        },
        exchangeId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        ccxtName: {
            type: DataTypes.STRING(30),
            unique: true,
            allowNull: false,
        },
        exchangeSlug: {
            type: DataTypes.STRING(30),
            allowNull: false,
        },
        deleted_at: {
            type: DataTypes.DATE,
            type: "TIMESTAMP",
        },
    },
    {
        timestamps: true,
        underscored: true,
    }
);

module.exports = ExchangeModel;
