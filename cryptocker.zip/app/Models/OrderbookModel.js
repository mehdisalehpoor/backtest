const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");

const OrderbookModel = sequelize.define(
  "orderbooks",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbol: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    qty: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    amount: {
      type: DataTypes.STRING(30),
      allowNull: false,
    },
    side: {
      type: DataTypes.ENUM(["asks", "bids"]),
      defaultValue: "asks",
      allowNull: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

module.exports = OrderbookModel;
