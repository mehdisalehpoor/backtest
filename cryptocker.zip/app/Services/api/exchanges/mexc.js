const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://api.mexc.com/api/v3/",
        symbol: baseSymbol + quoteSymbol,
        exchange: "mexc",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            const params = {
                symbol: symbol,
                interval: timeframe,
                startTime: startTime,
                // limit: 365
                endTime: endTime
            };

            const response = await axios.get(url + "klines", { params });
            const data = response.data;
            console.log(params);
            return data.map(kline => ([
                kline[0] / 1000,//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
