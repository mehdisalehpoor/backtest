const Redis = require("ioredis");

class RedisClientService {
  constructor() {
    const options = {
      host: "localhost", // Redis server host
      port: 6379, // Redis server port
      password: "Mohammad1367",
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
      retryStrategy: function (times) {
        // reconnect after a delay based on the number of attempts
        const delay = Math.min(times * 50, 2000);
        return delay;
      },
    };
    this.redis = new Redis(options);
    this.redis.on("error", (err) => {
      console.error("Redis error:", err);
    });
    this.redis.on("connect", () => {
      console.log("Connected to Redis");
    });
    this.redis.on("reconnecting", (delay) => {
      console.log(`Reconnecting to Redis in ${delay}ms`);
    });
  }

  set(key, value) {
    return this.redis.set(key, value);
  }

  get(key) {
    return this.redis.get(key);
  }

  publish(channel, message) {
    return this.redis.publish(channel, message);
  }

  subscribe(channel, callback) {
    return this.redis.subscribe(channel, callback);
  }

  onMessage(callback) {
    this.redis.on("message", callback);
  }

  quit() {
    return this.redis.quit();
  }
}

module.exports = RedisClientService;
