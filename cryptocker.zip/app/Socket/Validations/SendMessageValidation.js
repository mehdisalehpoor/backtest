import Joi from "joi";
import { i18n } from "../../../config/configs";
import ResponseHelper from "../Helpers/ResponseHelper";
import SenderHelper from "../Helpers/SenderHelper";

class SendMessageValidation extends SenderHelper {
  constructor(io, socket, event_name, input) {
    super(io);
    this.socket = socket;
    this.event_name = event_name;
    this.input = input;
  }
  async handle() {
    const schema = Joi.object({
      user_id: Joi.number()
        .integer()
        .required()
        .label(i18n.__("user_id"))
        .messages({
          "string.empty": i18n.__("string_empty"),
          "any.required": i18n.__("required"),
        }),
      message: Joi.string()
        .required()
        .label(i18n.__("message"))
        .messages({
          "string.empty": i18n.__("string_empty"),
          "any.required": i18n.__("required"),
        }),
    });

    const { error } = schema.validate(this.input, { abortEarly: false });

    if (error) {
      const errorMessage = error.details.map((err) => {
        const { message, path } = err;
        const key = path[0];
        return {
          key,
          message,
        };
      });
      this.send(
        this.socket.id,
        this.event_name,
        ResponseHelper.error(errorMessage, 422)
      );
      return false;
    }
    return true;
  }
}
export default SendMessageValidation;
