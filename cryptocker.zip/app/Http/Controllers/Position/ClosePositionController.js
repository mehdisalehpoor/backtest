import { Op } from "sequelize";
import { apiKey } from "../../../../config/configs";
import OrderHelpers from "../../../Helpers/OrderHelpers";
const { MainClient, USDMClient } = require("binance");

class AddOrderController {
  static async handle(req, res, next) {
    try {
      const {
        symbol,
        sideStatus,
        positionSide,
        tickSizeNumberOfDecimals,
        roundedQty,
      } = req.body;

      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });

      const mainClient = new MainClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });

      // Define the asynchronous functions
      const get24hrChangeStatisticsPromise = mainClient.getSymbolPriceTicker({
        symbol,
      });

      // Execute the promises concurrently
      const [changeStatistics] = await Promise.all([
        get24hrChangeStatisticsPromise,
      ]);

      const lastPrice = changeStatistics.price;

      const priceOrder = Number(lastPrice.toFixed(tickSizeNumberOfDecimals));

      const openPosition = {
        symbol: symbol,
        side: sideStatus,
        positionSide: positionSide,
        type: "LIMIT",
        timeInForce: "GTC",
        quantity: roundedQty,
        price: priceOrder, // remove 0.001
        timestamp: new Date().getTime(),
      };

      const submitNewOrder = await AddOrderController.submitNewOrder(
        client,
        openPosition
      );

      const newOrder = await OrderHelpers.createOrderInDB(
        submitNewOrder,
        apiKey.userId,
        "NEW",
        "NEW",
        tickSizeNumberOfDecimals,
        leverageNumber
      );

      res.send({
        newOrder,
        newOrderProfit,
        time: new Date().getTime(),
      });
    } catch (error) {
      console.error(error);
    }
  }
}

export default AddOrderController;
