class ResponseHelper {
  static success = (data = []) => ({
    status: 200,
    data,
  });

  static error = (messages, status_code) => ({
    status: status_code,
    message: messages,
  });
}

export default ResponseHelper;
