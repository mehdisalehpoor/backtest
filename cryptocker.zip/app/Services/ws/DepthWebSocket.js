import WebSocket from "ws";
import zlib from "zlib";
import path from "path";
import fs from "fs";

// Load the exchange configuration dynamically
const loadExchangeConfig = (exchange) => {
  const configPath = path.join(__dirname, "exchanges", `${exchange}.js`);
  if (fs.existsSync(configPath)) {
    return import(configPath);
  } else {
    console.error(`Configuration file for ${exchange} does not exist.`);
    return null;
  }
};

// Subscribe to the exchange
const subscribeToExchange = async (ws, symbol, exchangeConfig) => {
  const subscribeMessage = exchangeConfig.getSubscribeMessage(symbol);
  await ws.send(JSON.stringify(subscribeMessage));
  console.log(`Subscribed to ${symbol} order book updates`);
};

// Handle incoming messages
const handleIncomingMessage = async (data, config, exchangeConfig) => {
  if (
    Buffer.isBuffer(data) &&
    ["bingx", "htx", "hotcoin-global", "bitrue"].includes(config.exchange)
  ) {
    const buf = Buffer.from(data);
    data = zlib.gunzipSync(buf).toString("utf-8");
  }

  const message = exchangeConfig.parseMessage(data);
  const { totalAskValue, totalBidValue } = calculateTotalValues(
    message.asks,
    message.bids
  );
  console.log(
    `${config.symbol} (${config.exchange}) => ask => ${totalAskValue}, bid => ${totalBidValue}`
  );
};

// Calculate total values for asks and bids
const calculateTotalValues = (asks, bids) => {
  const totalAskValue = calculateTotalValue(asks);
  const totalBidValue = calculateTotalValue(bids);
  return { totalAskValue, totalBidValue };
};

// Calculate total value for an array of data
const calculateTotalValue = (data) => {
  return data.reduce((total, [price, size]) => total + price * size, 0);
};

// Create a new WebSocket client
const createWebSocketClient = (config) => {
  const { symbol, exchange, url } = config;
  const exchangeConfig = loadExchangeConfig(exchange);

  if (!exchangeConfig) {
    throw new Error(`Exchange configuration for ${exchange} not found`);
  }

  const ws = new WebSocket(url);

  ws.on("open", async () => {
    await subscribeToExchange(ws, symbol, exchangeConfig);
    console.log(
      `Connected to ${exchange} WebSocket server for ${symbol} order book updates`
    );
  });

  ws.on("message", (data) =>
    handleIncomingMessage(data, config, exchangeConfig)
  );
  ws.on("error", (error) => console.error(error));
  ws.on("close", () => {
    console.log(config);
    createWebSocketClient(config); // Restart connection
  });

  return ws;
};

export default createWebSocketClient;
