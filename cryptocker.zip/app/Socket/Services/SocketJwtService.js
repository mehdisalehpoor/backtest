import jwt from "jsonwebtoken";
import { i18n, password } from "../../../config/configs";

class SocketJwtService {
  static verify(token) {
    try {
      return jwt.verify(token, password.secret_key);
    } catch (error) {
      throw new Handler(ErrorCode.INVALID_JWT);
    }
  }
}

export default SocketJwtService;
