<?php

require 'ccxt/vendor/autoload.php';
require_once('./exchange_service.php');

// Check if the "type", "exchange", and "symbol" parameters are set
if (isset($_GET['type'], $_GET['exchange'], $_GET['symbol'])) {
    $type = $_GET['type'];
    $exchangeId = $_GET['exchange'];  // Change variable name to avoid overwriting the class instance
    $symbol = $_GET['symbol'];
    $exchangeMap = [
        'binance' => 'getBinanceOrderbook',
        'binance-tr' => 'getBinanceTrOrderbook',
        'mexc' => 'getMexcOrderbook',
        'xt' => 'getXTOrderbook',
        'whitebit' => 'getWhiteBitOrderbook',
        'toobit' => 'getTooBitOrderbook',
        'tokocrypto' => 'getTokoCryptoOrderbook',
        'probit' => 'getProbitOrderbook',
        'poloniex' => 'getPoloniexOrderBook',
        'pionex' => 'getPionexOrderbook',
        'orangex' => 'getOrangeXOrderbook',
        'okx' => 'getOkxOrderbook',
        'lbank' => 'getLBankOrderbook',
        'latoken' => 'getLatokenOrderbook',
        'huobi' => 'getHuobiOrderbook',
        'hotcoin' => 'getHotcoinOrderbook',
        'gate' => 'getGateOrderbook',
        'digifinex' => 'getDigiFinexOrderbook',
        'fameex' => 'getFameexOrderbook',
        'deepcoin' => 'getDeepCoinOrderbook',
        'coinex' => 'getCoinexOrderbook',
        'coinbase' => 'getCoinBaseOrderbook',
        'bingx' => 'getBingxOrderbook',
        'bybit' => 'getBybitOrderbook',
        'kraken' => 'getKrakenOrderbook',
        'bitget' => 'getBitgetOrderbook',
        'kucoin' => 'getKucoinOrderbook',
        'bitrue' => 'getBitrueOrderbook',
        'bitmart' => 'getBitmartOrderbook',
        'bitforex' => 'getBitforexOrderbook',
        'ascendex' => 'getAscendexOrderbook',
        'bitvenus' => 'getAscendexOrderbook',
    ];
    try {
        if (array_key_exists($exchangeId, $exchangeMap)) {
            // Call the corresponding service function based on the exchange
            $orderbook = call_user_func([ExchangeService::class, $exchangeMap[$exchangeId]], $symbol);
            echo json_encode($orderbook);
        } else {
            try {
                // Dynamically create an instance of the exchange class
                $exchange = '\\ccxt\\' . $exchangeId;
                $exchangeInstance = new $exchange();
                // Fetch order book for the specified symbol
                if ($exchangeId == "bitfinex2") {
                    $orderBook = $exchangeInstance->fetch_order_book($symbol . "/USDT", 100);
                } else {
                    $orderBook = $exchangeInstance->fetch_order_book($symbol . "/USDT");
                }


                // Display order book information
                echo json_encode($orderBook);
            } catch (\ccxt\BaseError $e) {
                echo json_encode([
                    "success" => false,
                    "message" => $e->getMessage()
                ]);
            }
        }
    } catch (Exception $exception) {
        return $exception->getMessage();
    }
} else {
    echo "Required parameters are not set<br>";
}
