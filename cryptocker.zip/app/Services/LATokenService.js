const axios = require("axios");
const ProxyService = require("./ProxyService");

class LATokenService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: `https://api.latoken.com/api/v1/marketData/orderBook/${symbol}USDT/100`,
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item.price),
        parseFloat(item.quantity),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item.price),
        parseFloat(item.quantity),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = LATokenService;
