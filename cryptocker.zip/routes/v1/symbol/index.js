const ccxt = require("ccxt");
import express from "express";
const axios = require("axios");
const { HttpsProxyAgent } = require("https-proxy-agent");
import GetBinanceFuturesSymbol from "../../../app/Http/Controllers/Symbol/GetBinanceFuturesSymbol";
import SignalModel from "../../../app/Models/SignalModel";
import { apiKey } from "../../../config/configs";
import ProxyService from "../../../app/Services/ProxyService";
import SignalOrderService from "../../../app/Services/SignalOrderService";
import BinanceService from "../../../app/Services/BinanceService";
import SymbolModel from "../../../app/Models/SymbolModel";
import SymbolVolumeModel from "../../../app/Models/SymbolVolumeModel";
import sequelize, { Sequelize, Op } from "sequelize";
import { runCheckPriceWSJob } from "../../../app/Jobs/CheckPriceWSJob";
import { runVolumeJob } from "../../../app/Jobs/VolumeJob";
const { DateTime } = require("luxon");
const { USDMClient, MainClient } = require("binance");

const symbolRouter = express.Router();

//  @desc   Get Symbol Spot Price
//  @route  GET /symbol/spot-price
symbolRouter.post("/spot-price", async (req, res) => {
  try {
    const { symbol } = req.body;
    const binance = new ccxt.binance();

    // Load the market symbols
    await binance.loadMarkets();

    // Fetch the ticker information for the symbol
    const ticker = await binance.fetchTicker(symbol);

    // Get the current price
    const price = ticker.last;
    res.send({ price });
  } catch (error) { }
});

//  @desc   Get Symbol Orderbook
//  @route  GET /symbol/orderbook
symbolRouter.post("/orderbook", async (req, res) => {
  try {
    const { exchange, symbol, limit } = req.body;
    console.log(symbol);
    const exchangeClass = new ccxt[exchange]();
    const since = undefined;
    var orderBook = await exchangeClass.fetchL2OrderBook(symbol);
    // const gate = new HotcoinService();
    // const response = await gate.getOrderbook(symbol);
    // console.log(response);
    // if (response.data) {
    // var orderBook = response.data;
    // }
    res.send(orderBook);
  } catch (error) {
    console.error(error);
  }
});

symbolRouter.post("/binance-futures-data", GetBinanceFuturesSymbol.handle);

symbolRouter.post("/test-symbol", async (req, res) => {
  try {
    const signals = await SignalModel.sequelize.query(`
      SELECT
      signals.id,
      signals.symbol,
      signals.profit,
      signals.percentage_increase,
      signals.created_at,
      signals.updated_at
  FROM
      signals
  WHERE
  DATE(signals.created_at) >= (CURRENT_DATE - INTERVAL '10 days')
  AND DATE(signals.created_at) <= CURRENT_DATE
          AND signals.profit IS NOT NULL
          AND signals.signal_type != 'Volume_Signal'
      `);

    var percentage = 0;
    var profit = 0;
    var balance = req.body.balance ?? 1000;
    var stopLoss = req.body.stop ?? 1;
    var leverage = req.body.leverage ?? 10;
    var capitalDivision = req.body.division ?? 20;

    console.log(req.body.balance, req.body.leverage, req.body.division);

    // Iterate through signals array
    signals[0].forEach((signal) => {
      var orderAmount = balance / capitalDivision;
      var percentageIncrease = parseFloat(signal.percentage_increase);

      if (signal.profit == "loss") {
        if (percentageIncrease > stopLoss) {
          percentageIncrease = stopLoss;
        }
        profit = orderAmount * (percentageIncrease / 100) * leverage;

        balance -= profit; // Update balance after subtracting profit
        percentage -= percentageIncrease;
      } else {
        profit = orderAmount * (percentageIncrease / 100) * leverage;
        balance += profit; // Update balance after adding profit
        percentage += percentageIncrease;
      }
    });

    res.send({ percentage: percentage, profit: profit, balance });
  } catch (error) {
    console.error("Error fetching signals:", error);
  }

  // res.send({
  //   sumExistsExchangesVolume,
  //   filteredExistsExchanges,
  //   binanceExists,
  // });
  // const data = await runGetSymbolsDataJob();
  // res.send(data);
});

symbolRouter.post("/ws", async (req, res) => {
  const data = await runCheckPriceWSJob();
  res.send(data);
});

symbolRouter.get("/volume", async (req, res) => {
  const data = await runVolumeJob();
  res.send(data);
});


symbolRouter.post("/proxy-check", async (req, res) => {
  try {
    const axiosClient = axios.create({
      baseURL: "https://api.binance.com/api/v3/depth",
    });
    const agent = await ProxyService.getProxyAddress();
    console.log(agent);
    const response = await axiosClient.get("", {
      params: {
        symbol: `BTCUSDT`,
        limit: 5000,
      },
      httpsAgent: agent,
    });

    const formattedResponse = {
      asks: response.data.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: response.data.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };
    res.send(formattedResponse);
  } catch (error) {
    console.error(error);
  }
});

symbolRouter.get("/leverageBracket", async (req, res) => {
  try {
    const symbol = req.query.symbol;
    const usdmClient = new USDMClient({
      api_key: apiKey.api_key,
      api_secret: apiKey.api_secret,
    });

    const getNotionalAndLeverageBrackets =
      await usdmClient.getNotionalAndLeverageBrackets({
        symbol,
      });

    res.send(getNotionalAndLeverageBrackets);
  } catch (error) {
    res.status(500).send(error.body);
  }
});

symbolRouter.post("/leverage", async (req, res) => {
  try {
    const usdmClient = new USDMClient({
      api_key: apiKey.api_key,
      api_secret: apiKey.api_secret,
    });

    const leverage_params = {
      symbol: req.body.symbol,
      leverage: req.body.leverage,
    };

    const setLeverageResponse = await usdmClient.setLeverage(leverage_params);

    res.send(setLeverageResponse);
  } catch (error) {
    res.status(500).send(error.body);
  }
});

symbolRouter.post("/margin", async (req, res) => {
  try {
    const usdmClient = new USDMClient({
      api_key: apiKey.api_key,
      api_secret: apiKey.api_secret,
    });

    const setMarginType = await usdmClient.setMarginType({
      symbol: req.body.symbol,
      marginType: req.body.marginType,
      timestamp: new Date().getTime(),
    });

    res.send(setMarginType);
  } catch (error) {
    res.status(500).send(error.body);
  }
});

symbolRouter.get("/exchangeInfo", async (req, res) => {
  try {
    const mainClient = new MainClient({
      api_key: apiKey.api_key,
      api_secret: apiKey.api_secret,
    });

    const getExchangeInfo = await mainClient.getExchangeInfo();
    res.send(getExchangeInfo);
  } catch (error) {
    res.status(500).send(error.body);
  }
});

symbolRouter.get("/account", async (req, res) => {
  try {
    const usdmClient = new USDMClient({
      api_key: apiKey.api_key,
      api_secret: apiKey.api_secret,
    });

    const getAccountInformation = await usdmClient.getAccountInformation();
    res.send(getAccountInformation);
  } catch (error) {
    res.status(500).send(error.body);
  }
});

symbolRouter.get("/test-job", async (req, res) => {
  try {
    //Market cap = Current price x Circulating supply
    // Current price= Circulating supply / Market cap
    const signal = await SignalModel.findOne({
      where: {
        profit: "success",
      },
    });

    // const type = req.query.type ?? "";
    // const symbol = req.query.symbol ?? "ORDIUSDT";
    // if (type == "exit") {
    //   var data = await SignalOrderService.exitOrderForUsers("BAKE", "sell");
    // } else if (type == "enter") {
    //   var data = await SignalOrderService.addOrderForUsers("BAKE", "sell");
    // } else if (type == "price") {
    //   const price = await BinanceService.getFuturesPrice(symbol);
    //   console.log(price);
    //   var data = { price };
    // }
    const signalPayload = JSON.parse(signal.payload);
    const densityDetails = signalPayload.box[0].densityDetails;
    const densityDifference = densityDetails[0].densityDiff;
    const densityVolumeStatus = densityDetails[0].densityVolumeStatus;
    const seventyFivePercent = densityDifference * 0.75;

    res.send({ densityDifference, densityVolumeStatus, seventyFivePercent });
  } catch (error) {
    res.status(500).send(error.body);
  }
});

symbolRouter.get("/ws-kucoin", async (req, res) => {
  const axios = require('axios');
  const WebSocket = require('ws');

  // مرحله 1: دریافت توکن عمومی و سرور WebSocket
  async function getPublicToken() {
    try {
      const response = await axios.post('https://api.kucoin.com/api/v1/bullet-public');
      return response.data.data;
    } catch (error) {
      console.error('Error fetching public token:', error);
    }
  }

  const data = await getPublicToken();
  const { token, instanceServers } = data;
  const endpoint = instanceServers[0].endpoint;

  // مرحله 2: اتصال به WebSocket
  const ws = new WebSocket(`${endpoint}?token=${token}`);

  ws.on('open', () => {
    console.log('WebSocket connected');

    // مرحله 3: اشتراک‌گذاری در موضوع داده‌های کندل
    const subscribeMessage = {
      id: Date.now(),
      type: 'subscribe',
      topic: '/market/candles:BTC-USDT_1day',
      response: true
    };

    ws.send(JSON.stringify(subscribeMessage));
  });

  ws.on('message', (data) => {
    const message = JSON.parse(data);
    console.log('Received message:', message);

    if (message.subject === 'trade.candles.update') {
      const { candles } = message.data;
      console.log('Candles data:', candles);
    }
  });

  ws.on('close', () => {
    console.log('WebSocket disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
})

symbolRouter.get("/candle", async (req, res) => {
  const url = 'https://api.kucoin.com/api/v1/market/candles';
  const days = req.query.days ?? 1;
  let endAt = parseFloat(req.query.startAt) + (86400 * parseFloat(days));
  
  const params = {
    type: req.query.type,
    symbol: req.query.symbol,
    startAt: req.query.startAt,
    endAt
  };

  const array = [];

  try {
    const response = await axios.get(url, { params });
    let data = response.data.data.reverse();

    let sum = 0;
    let foundIndex = -1;
    let initialCandle = null;

    for (let i = 0; i < data.length; i++) {
      sum += parseFloat(data[i][5]);


      if (sum >= parseFloat(req.query.sum) * 0.20) {
        foundIndex = i;
        initialCandle = data[i];
        const timestamp = parseInt(data[i][0]);
        const date = new Date(timestamp * 1000); // تبدیل timestamp به میلی‌ثانیه
        const formattedDate = date.toLocaleString(); // تبدیل به قالب خوانا

        array.push({
          formattedDate,
          sum,
          open: data[i][1],
          close: data[i][2],
          timestamp: data[i][0],
        });
        break;
      }
    }

    if (foundIndex !== -1 && initialCandle) {
      const closePrice = parseFloat(initialCandle[2]);
      const threshold = closePrice * req.query.percent; // 20% بیشتر از قیمت close

      for (let j = foundIndex + 1; j < data.length; j++) {
        
        if (parseFloat(data[j][3]) > threshold) {
          const timestamp = parseInt(data[j][0]);
          const date = new Date(timestamp * 1000); // تبدیل timestamp به میلی‌ثانیه
          const formattedDate = date.toLocaleString(); // تبدیل به قالب خوانا
          array.push({
            formattedDate,
            open: data[j][1],
            close: data[j][2],
          });
          break;
        }
      }
    }

    res.send(array);
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).send('Error fetching data');
  }
});

symbolRouter.post("/test-symbol-candle", async (req, res) => {
  try {
    const symbolVolumesFirst = await SymbolVolumeModel.findOne();

    const startDate = new Date(symbolVolumesFirst.createdAt);
    startDate.setUTCMinutes(0, 0, 0);

    const endDate = new Date(); // Example end date and time (current time)

    // Loop through each hour
    let currentHour = new Date(startDate);
    const hourInterval = 60 * 60 * 1000; // 1 hour in milliseconds

    const symbolVolumes = [];

    while (currentHour < endDate) {
      try {
        // Calculate the start and end of the current hour
        const hourStart = currentHour.toISOString(); // Convert to ISO string
        const hourEnd = new Date(currentHour.getTime() + hourInterval).toISOString(); // Convert to ISO string

        const symbolVolumesHourly = await SymbolVolumeModel.sequelize.query(`
          SELECT s.id,
                 s.symbol,
                 SUM(CASE
                       WHEN (symbol_volumes.payload::json -> 'tenThousandth' ->> 'saleTen') = 'sell'
                           THEN CAST((symbol_volumes.payload::json -> 'tenThousandth' ->> 'differenceTen') AS DECIMAL)
                       ELSE 0
                   END) AS sum_sell_difference_ten,
                 SUM(CASE
                       WHEN (symbol_volumes.payload::json -> 'tenThousandth' ->> 'saleTen') = 'buy'
                           THEN CAST((symbol_volumes.payload::json -> 'tenThousandth' ->> 'differenceTen') AS DECIMAL)
                       ELSE 0
                   END) AS sum_buy_difference_ten
          FROM symbol_volumes
          JOIN symbols s ON s.id = symbol_volumes.symbol_id
          WHERE symbol_volumes.created_at >= '${hourStart}'
            AND symbol_volumes.created_at < '${hourEnd}'
          GROUP BY s.id, s.symbol
        `, { type: SymbolVolumeModel.sequelize.QueryTypes.SELECT });

        symbolVolumes.push(symbolVolumesHourly);

        currentHour.setTime(currentHour.getTime() + hourInterval);
        console.log(hourStart, hourEnd);
        res.send(symbolVolumesHourly);
        return;
      } catch (err) {
        console.error("Error executing query:", err);
      }
    }

    res.send(symbolVolumes);
  } catch (error) {
    console.error(error.message);
    res.status(500).send("Internal Server Error");
  }
});


module.exports = symbolRouter;
