const axios = require("axios");
const ProxyService = require("./ProxyService");

class HotcoinService {
  static async getOrderbook(symbol) {
    var symbolName = symbol.toLowerCase();

    const axiosClient = axios.create({
      baseURL: "https://api.hotcoinfin.com/v1/trade",
    });

    const agent = await ProxyService.getProxyAddress();

    const response = await axiosClient.get("", {
      params: {
        symbol: `${symbolName}_usdt`,
        count: 1000,
      },
      httpsAgent: agent,
    });

    var data = null;

    if (response.data) {
      const asks = [];
      const bids = [];

      response.data.data.trades.forEach((trade) => {
        if (trade.en_type === "ask") {
          asks.push([parseFloat(trade.price), parseFloat(trade.amount)]);
        } else if (trade.en_type === "bid") {
          bids.push([parseFloat(trade.price), parseFloat(trade.amount)]);
        }
      });
      data = { bids, asks };
    }

    response.data = data;
    return data;
  }
}

module.exports = HotcoinService;
