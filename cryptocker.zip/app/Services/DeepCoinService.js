const axios = require("axios");
const ProxyService = require("./ProxyService");

class DeepCoinService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.deepcoin.com/deepcoin/market/books",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        instId: `${symbol}-USDT`,
        sz: 400,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = DeepCoinService;
