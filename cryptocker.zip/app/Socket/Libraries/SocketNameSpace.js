class Router {
    constructor() {
      this.namespace = [];
    }

    // register route
    register(event_name, handler) {
      this.routes.push({ event_name, handler });
      return this;
    }
  
    // get all routes with even name and middlewares and namespace
    all() {
      const handler = [...this.routes];
      return handler;
    }
  }
  
  
  export default Router;