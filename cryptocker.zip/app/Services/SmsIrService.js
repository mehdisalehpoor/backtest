const axios = require("axios");
const { smsir } = require("../../config/configs");

class SmsIrService {
  static async sendOtpCode(mobile, code) {
    try {
      const url = "https://api.sms.ir/v1/send/verify";
      const payload = {
        mobile,
        templateId: "100000",
        parameters: [
          {
            name: "CODE",
            value: String(code),
          },
        ],
      };
      const headers = {
        "User-Agent":
          "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:105.0) Gecko/20100101 Firefox/105.0",
        Accept: "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "content-type": "application/json",
        "X-API-KEY": smsir.api_key,
        Connection: "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        TE: "trailers",
      };
      const response = await axios.post(url, payload, {
        headers,
      });
      console.log(response.data);

      return response.data;
    } catch (e) {
      console.log(e);
      return null;
    }
  }
  static async sendBoxSignal(mobile, symbol, rate, status, price) {
    try {
      const url = "https://api.sms.ir/v1/send/verify";
      const payload = {
        mobile,
        templateId: "738873",
        parameters: [
          {
            name: "SYMBOL",
            value: String(symbol),
          },
          {
            name: "RATE",
            value: String(rate),
          },
          {
            name: "STATUS",
            value: String(status),
          },
          {
            name: "CLOSE_PRICE",
            value: String(price),
          },
        ],
      };
      const headers = {
        "User-Agent":
          "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:105.0) Gecko/20100101 Firefox/105.0",
        Accept: "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "content-type": "application/json",
        "X-API-KEY": smsir.api_key,
        Connection: "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        TE: "trailers",
      };
      const response = await axios.post(url, payload, {
        headers,
      });
      console.log(response.data);

      return response.data;
    } catch (e) {
      console.log(e);
      return null;
    }
  }
  static async sendFifteenSignal(mobile, symbol, price, rate, status, bsum, asum, max) {
    try {
      const url = "https://api.sms.ir/v1/send/verify";
      const payload = {
        mobile,
        templateId: "720304",
        parameters: [
          {
            name: "SYMBOL",
            value: String(symbol),
          },
          {
            name: "PRICE",
            value: String(price),
          },
          {
            name: "RATE",
            value: String(rate),
          },
          {
            name: "STATUS",
            value: String(status),
          },
          {
            name: "BSUM",
            value: String(bsum),
          },
          {
            name: "ASUM",
            value: String(asum),
          },
          {
            name: "MAX",
            value: String(max),
          },
        ],
      };
      const headers = {
        "User-Agent":
          "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:105.0) Gecko/20100101 Firefox/105.0",
        Accept: "*/*",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "content-type": "application/json",
        "X-API-KEY": smsir.api_key,
        Connection: "keep-alive",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-origin",
        TE: "trailers",
      };
      const response = await axios.post(url, payload, {
        headers,
      });
      console.log(response.data);

      return response.data;
    } catch (e) {
      console.log(e);
      return null;
    }
  }
}

module.exports = SmsIrService;
