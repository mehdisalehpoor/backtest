const ioredis = require("ioredis");
require("dotenv").config();

class CacheService {
  constructor() {
    this.redisClient = null;
    this.connectToRedis();
  }

  async readFromCache(key) {
    const isExists = await this.isExists(key);
    if (isExists) {
      const cachedData = await this.get(key);
      return JSON.parse(cachedData);
    } else {
      return null;
    }
  }

  async set(key, value) {
    try {
      return await this.redisClient.set(key, JSON.stringify(value));
    } catch (error) {
      console.error(error);
    }
  }

  async get(key) {
    try {
      return await this.redisClient.get(key);
    } catch (error) {
      console.error(error);
    }
  }

  async scan() {
    // Implement your scan logic here
  }

  async isExists(key) {
    try {
      return await this.redisClient.exists(key);
    } catch (error) {
      console.error(error);
    }
  }

  async connectToRedis() {
    try {
      if (!this.redisClient || this.redisClient.status === "end") {
        this.redisClient = new ioredis({
          port: +process.env.REDIS_PORT,
          host: process.env.REDIS_HOST,
        });
        await this.redisClient.connect(); // Ensure connection is established
      } else if (
        this.redisClient.status === "connecting" ||
        this.redisClient.status === "connected"
      ) {
        console.log("Redis client is already connecting/connected.");
      }
    } catch (error) {
      console.error("Error connecting to Redis:", error);
    }
  }
}

module.exports = new CacheService();
