const { DataTypes } = require("sequelize");
const sequelize = require("../../config/database");
const ExchangeModel = require("./ExchangeModel");
const SymbolModel = require("./SymbolModel");

const SymbolExchangeModel = sequelize.define(
  "symbol_exchange",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    symbolId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    exchangeId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    timestamps: true,
    underscored: true,
  }
);

// Define the association
SymbolExchangeModel.belongsTo(ExchangeModel, {
  foreignKey: "exchangeId", // Use the correct foreign key name
  as: "exchange",
});

SymbolExchangeModel.belongsTo(SymbolModel, {
  foreignKey: "symbolId", // Use the correct foreign key name
  as: "symbol",
});

// Export the intermediary table model along with the SymbolModel and ExchangeModel
module.exports = SymbolExchangeModel;
