const axios = require("axios");
const ProxyService = require("./ProxyService");

class ProbitService {
  static async getOrderBook(symbol) {
    const agent = await ProxyService.getProxyAddress();
    const axiosClient = axios.create({
      baseURL: "https://api.probit.com/api/exchange/v1/order_book",
    });

    const orderBookResponse = await axiosClient.get("", {
      params: {
        market_id: `${symbol}-USDT`,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const asks = orderBook
      .filter((entry) => entry.side === "sell")
      .map((entry) => [parseFloat(entry.price), parseFloat(entry.quantity)]);
    const bids = orderBook
      .filter((entry) => entry.side === "buy")
      .map((entry) => [parseFloat(entry.price), parseFloat(entry.quantity)]);
    const formattedResponse = { asks, bids };

    return formattedResponse;
  }
}

module.exports = ProbitService;
