module.exports = {
  apps: [
    {
      name: "get-binance-candles-symbols",
      script: "./app/Jobs/VolumeJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "0 0 * * *", // Restart every day at 00:00
      watch: false,
      max_memory_restart: "400M",
    },
    {
      name: "signal-volume-check",
      script: "./app/Jobs/VolumeDailyJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "0 */2 * * *", // Execute every 2 hours
      watch: false,
      max_memory_restart: "800M",
    }    
  ],
};
