import bcrypt from "bcryptjs";

class PasswordService {
  static async verifyPassword(password, hashedPassword) {
    const result = await bcrypt.compare(password, hashedPassword);
    return result;
  }
}

export default PasswordService;
