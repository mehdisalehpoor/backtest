import SymbolModel from "../Models/SymbolModel";
import TelegramBotService from "../Services/TelegramBotService";

export const runGetSymbolsDataJob = async () => {
  try {
    const symbols = await SymbolModel.findAll({
      where: {
        futures: true,
      }
    });
    
    return symbols;
  } catch (error) {
    TelegramBotService.futuresSignalSend("OrderBookJob " + error);
  }
};
