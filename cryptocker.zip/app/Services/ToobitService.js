const axios = require("axios");
const ProxyService = require("./ProxyService");

class TooBitService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.toobit.com/quote/v1/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol}USDT`,
        limit: 200,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;

    const formattedResponse = {
      asks: orderBook.a.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.b.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = TooBitService;
