"use strict";

module.exports = {
  up: function (queryInterface, DataTypes) {
    return queryInterface.createTable("imdb_ids_for_jobs", {
      id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
      },
      imdb_id: {
        type: DataTypes.STRING(30),
        unique: true,
        allowNull: false,
      },
      status: {
        type: DataTypes.ENUM('published', 'pending'),
        allowNull: false,
      },
      created_at: {
        allowNull: false,
        type: DataTypes.DATE,
      },
      updated_at: {
        allowNull: true,
        type: DataTypes.DATE,
      },
      deleted_at: {
        type: DataTypes.DATE,
        allowNull: true,
      },
    });
  },

  down: function (queryInterface, DataTypes) {
    return queryInterface.dropTable("imdb_ids_for_jobs");
  },
};
