exports.getConfig = async (symbol) => {
  return {
    exchange: "bybit",
    symbol: await fixSymbolName(symbol),
    url: `wss://stream.bybit.com/v5/public/spot`,
    getSubscribeMessage: (symbol) => {
      return {
        op: "subscribe",
        args: [`orderbook.50.${symbol}`],
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      return {
        asks: message?.data?.a || [],
        bids: message?.data?.b || [],
      };
    },
  };
};

const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + quote.toUpperCase();
};
