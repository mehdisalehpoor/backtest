const ccxt = require("ccxt");
class Helpers {
  static async symbolName(symbol) {
    const position = 4;
    const new_string =
      symbol.slice(0, -position) + "/" + symbol.slice(-position);
    return new_string;
  }

  static async getSpotPrice(symbol) {
    const binance = new ccxt.binance();
    const ticker = await binance.fetchTicker(symbol);
    console.log(symbol,ticker.last);
    return ticker.last; // Adjust the property name based on the API response structure
  }

  static async convertToShortForm(str) {
    const number = parseFloat(str);
    
    if (number >= 1000000) {
      const shortened = (number / 1000000).toFixed(1) + "m";
      return shortened;
    } else if (number >= 1000) {
      const shortened = (number / 1000).toFixed(1) + "k";
      return shortened;
    } else {
      return str;
    }
  }
}

module.exports = Helpers;
