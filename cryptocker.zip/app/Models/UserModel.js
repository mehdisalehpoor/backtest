const { DataTypes } = require("sequelize");
const bcrypt = require("bcryptjs");
const sequelize = require("../../config/database");

const UserModel = sequelize.define(
  "users",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
      allowNull: false,
    },
    username: {
      type: DataTypes.STRING(150),
      unique: true,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING(150),
      allowNull: false,
    },
    telegramId: {
      type: DataTypes.STRING(150),
      allowNull: true,
    },
    ip: {
      type: DataTypes.STRING(30),
      unique: true,
      allowNull: false,
    },
    mobile: {
      type: DataTypes.STRING(14),
      unique: true,
      allowNull: true,
    },
    capitalDivision: {
      type: DataTypes.INTEGER(),
      allowNull: true,
    },
    balance: {
      type: DataTypes.DECIMAL(),
      allowNull: true,
    },
    marginPerOrder: {
      type: DataTypes.INTEGER(),
      allowNull: true,
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  },
  {
    timestamps: true,
    underscored: true,
    hooks: {
      beforeCreate: async (user) => {
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(user.password, salt);
      },
      beforeUpdate: async (user) => {
        if (user.changed("password")) {
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
        }
      },
    },
  }
);

UserModel.prototype.toJSON = function () {
  var values = Object.assign({}, this.get());
  delete values.password;
  return values;
};

module.exports = UserModel;
