const binance = require("./binance");
const orangex = require("./orangex");
const bybit = require("./bybit");
const bitmart = require("./bitmart");
const bitrue = require("./bitrue");
const hotcoin = require("./hotcoin");
const kucoin = require("./kucoin");
const mexc = require("./mexc");
// const bingx = require("./bingx");
// const okx = require("./okx");

const exchangeModules = {
  binance,
  orangex,
  bybit,
  bitmart,
  //   bitrue,
  //   hotcoin,

  // bingx
  // okx
  kucoin,
  mexc,
};

const loadExchangeConfig = (exchange) => {
  return exchangeModules[exchange] || null;
};

module.exports = {
  loadExchangeConfig,
  exchangeModules,
};