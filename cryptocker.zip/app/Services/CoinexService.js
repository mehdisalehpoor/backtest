const axios = require("axios");
const ProxyService = require("./ProxyService");

class CoinexService {
  static async getOrderbook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.coinex.com/v1/market/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        market: `${symbol}USDT`,
        merge: "0.000001",
        limit: 50,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = CoinexService;
