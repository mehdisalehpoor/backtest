import { Op } from "sequelize";
import SymbolQueryHelpers from "../../../Helpers/SymbolQueryHelpers";

class SignalListController {
  static async handle(req, res, next) {
    try {
      const signals = await SymbolQueryHelpers.getLastFourHourSignal();

      res.response(signals);
    } catch (error) {
      next(error);
    }
  }
}

export default SignalListController;
