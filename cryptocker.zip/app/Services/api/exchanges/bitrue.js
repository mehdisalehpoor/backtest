const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://openapi.bitrue.com/api/v1/market/",
        symbol: baseSymbol + quoteSymbol,
        exchange: "bitrue",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            let step = "1D";
            if (timeframe === "1d") {
                step = "1D";
            }
            const params = {
                symbol: symbol,
                scale: step,
                fromIdx: endTime,
                limit: 1440
            };

            const response = await axios.get(url + "kline", { params });
            const data = response.data.data;

            return data.map(kline => ([
                kline.i * 1000,//timestamp
                kline.o,//open
                kline.h,//high
                kline.l,//low
                kline.c,//close
                kline.v,//volume
            ]));
        },
    };
};
