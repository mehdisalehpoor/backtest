import path from "path";
import fs from "fs";

const loadExchangeConfig = (exchange) => {
    const configPath = path.join(__dirname, "exchanges", `${exchange}.js`);
    if (fs.existsSync(configPath)) {
        return import(configPath);
    } else {
        console.error(`Configuration file for ${exchange} does not exist.`);
        return null;
    }
};

export default loadExchangeConfig;