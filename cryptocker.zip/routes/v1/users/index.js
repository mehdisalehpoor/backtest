import express from "express";
import AuthorizationMiddleware from "../../../app/Http/Middlewares/AuthorizationMiddleware";
import { EditUserProfileController, GetUserInformationController } from "../../../app/Http/Controllers/User";

const usersRouter = express.Router();

//  @desc   Edit User Profile
//  @route  PUT /users/edit-profile
usersRouter.put(
  "/edit-profile",
  AuthorizationMiddleware.handle,
  EditUserProfileController.handle
);

//  @desc   Get User Information
//  @route  GET /users/edit-profile
usersRouter.get(
  "/user-information",
  AuthorizationMiddleware.handle,
  GetUserInformationController.handle
);

module.exports = usersRouter;
