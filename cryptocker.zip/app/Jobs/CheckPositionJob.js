const OrderModel = require("../Models/OrderModel");
const TelegramBotService = require("../Services/TelegramBotService");

// CheckPositionJob.js
const type = process.argv
  .find((arg) => arg.startsWith("--type="))
  .split("=")[1];
const orderId = process.argv
  .find((arg) => arg.startsWith("--orderId="))
  .split("=")[1];

const runCheckPositionJob = async () => {
  try {
    const order = await OrderModel.findOne({
      where: { id: orderId },
    });
    console.log(order.symbol);
    var text = `Symbol=${order.symbol}\nType=${type}\nOrderId=${orderId}`;
 
    if (type == "enter") {
      TelegramBotService.futuresSignalSend(text);
    }
    if (type == "exit") {
      TelegramBotService.futuresSignalSend(text);
    }

    console.log("Job stopped successfully", process.env.pm_id, process.argv[1]);
    // Stop the PM2 process only if the job completes successfully

    const pm2 = require("pm2");
    pm2.stop(process.env.pm_id || process.argv[1], (err, proc) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log("Job stopped successfully");
    });

    return "done";
  } catch (error) {
    console.error(error);
    return [];
  }
};

runCheckPositionJob();
