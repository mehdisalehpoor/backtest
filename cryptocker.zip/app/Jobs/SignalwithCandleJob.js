const axios = require("axios");
const ProxyService = require("../Services/ProxyService");
const TelegramBotService = require("../Services/TelegramBotService");
const SymbolModel = require("../Models/SymbolModel");

const handleCandleSymbolsCheck = async (symbols) => {
  const candles = [];
  for (const symbol of symbols) {
    try {
      // Binance API endpoint for kline/candlestick data
      const apiUrl = "https://api.binance.com/api/v3/klines";

      // Interval for the candlestick (1 hour in this case)
      const interval = "1h";

      // Construct the request URL
      const requestUrl = `${apiUrl}?symbol=${symbol.symbol}USDT&interval=${interval}&limit=2`;

      const agent = await ProxyService.getProxyAddress();

      const axiosClient = axios.create({
        baseURL: requestUrl,
      });

      const binanceResponse = await axiosClient
        .get("", {
          httpsAgent: agent,
        })
        .then((response) => {
          // Extract the last candlestick data from the response
          const lastCandlestick = response.data[0];

          const openPrice = parseFloat(lastCandlestick[1]);
          const highPrice = parseFloat(lastCandlestick[2]);
          const lowPrice = parseFloat(lastCandlestick[3]);
          const closePrice = parseFloat(lastCandlestick[4]);

          if (closePrice >= lowPrice + lowPrice * 0.02) {
            console.log("Close price is greater than 2% of low price.");
          }

          if (closePrice <= highPrice - highPrice * 0.02) {
            console.log("High price is greater than 2% of close price.");
          }

          candles.push({
            symbol: symbol.symbol,
            openTime: new Date(lastCandlestick[0]),
            timestamp: lastCandlestick[0],
            openPrice: parseFloat(lastCandlestick[1]),
            highPrice: parseFloat(lastCandlestick[2]),
            lowPrice: parseFloat(lastCandlestick[3]),
            closePrice: parseFloat(lastCandlestick[4]),
            volume: parseFloat(lastCandlestick[5]),
          });
        });
    } catch (error) {
      console.log(error);
      TelegramBotService.futuresSignalSend("SignalwithCandleJob " + error);
    }
  }
  return candles;
};

export const runCandleSymbolsCheckJob = async () => {
  try {
    const symbols = await SymbolModel.findAll();

    const data = await handleCandleSymbolsCheck(symbols);
    return data;
  } catch (error) {
    TelegramBotService.futuresSignalSend("SignalwithCandleJob " + error);
  }
};
