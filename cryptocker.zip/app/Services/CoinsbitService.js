const axios = require("axios");
const ProxyService = require("./ProxyService");

class CoinsbitService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://api.coinsbit.io/api/v1/public/depth/result",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        market: `${symbol}_USDT`,
        limit: 1000,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}

module.exports = CoinsbitService;
