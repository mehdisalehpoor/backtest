const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://api.binance.com/api/v3/",
        symbol: baseSymbol + quoteSymbol,
        exchange: "binance",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {
            const params = {
                symbol: symbol,
                interval: timeframe,
                startTime: startTime * 1000,
                endTime: endTime * 1000
            };

            const response = await axios.get(url + "klines", { params });
            const data = response.data;

            return data.map(kline => ([
                kline[0],//timestamp
                kline[1],//open
                kline[2],//high
                kline[3],//low
                kline[4],//close
                kline[5],//volume
            ]));
        },
    };
};
