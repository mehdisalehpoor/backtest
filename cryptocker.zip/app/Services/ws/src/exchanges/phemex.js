const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "phemex",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.phemex.com`,
    getSubscribeMessage: (symbol) => {
      return { id: 0, method: "orderbook.subscribe", params: ["s" + symbol] };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.book?.asks || [];
      const bids = message?.book?.bids || [];
      return { asks, bids };
    },
  };
};
