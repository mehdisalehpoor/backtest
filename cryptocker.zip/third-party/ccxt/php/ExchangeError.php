<?php

namespace ccxt;

require_once PATH_TO_CCXT . 'BaseError.php';

class ExchangeError extends BaseError {};
