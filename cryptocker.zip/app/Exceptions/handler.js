import { getError } from "./errorCode";
class Handler extends Error {
  constructor(errorCode, customMessage) {
    super();

    this.errorCode = errorCode;
    this.errorMessage = customMessage || getError(errorCode)[1];
  }

  getStatus() {
    return getError(this.errorCode)[0];
  }

  toJSON() {
    return {
      errors: this.errorMessage,
    };
  }
}

export default Handler;
