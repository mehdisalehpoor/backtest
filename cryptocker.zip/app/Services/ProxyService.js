const DomainModel = require("../Models/DomainModel");
const { HttpsProxyAgent } = require("https-proxy-agent");

class ProxyService {

  static async parseProxyAddress(proxy) {
    const [host, port] = proxy.split(":");
    return { host, port: parseInt(port, 10) };
  }

  static async getProxyAddress() {
    const proxyList = await DomainModel.findAll({ where: { status: true } });

    // Get a random index from the proxyList array
    const randomIndex = Math.floor(Math.random() * proxyList.length);

    // Use the random index to select a random host
    const randomHost = proxyList[randomIndex];
    
    const agent = new HttpsProxyAgent(
      `http://${randomHost.host}:${randomHost.port}`
    );
    return agent;
  }
}

module.exports = ProxyService;
