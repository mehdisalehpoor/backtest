const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toLowerCase() + quote.toLowerCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "bitstamp",
    symbol: await fixSymbolName(symbol),
    url: `wss://ws.bitstamp.net`,
    getSubscribeMessage: (symbol) => {
      return {
        event: "bts:subscribe",
        data: {
          channel: `order_book_${symbol}`,
        },
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = message?.data?.asks || [];
      const bids = message?.data?.bids || [];
      return { asks, bids };
    },
  };
};
