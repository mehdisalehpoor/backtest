module.exports = {
  apps: [
    {
      name: "signal-check",
      script: "./app/Jobs/OrderBookJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "*/1 * * * *", // Execute every 1 minutes
      watch: false,
      max_memory_restart: "800M",
    },
    {
      name: "get-binance-futuers-symbols",
      script: "./app/Jobs/GetBinanceFuturesSymbolsJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "0 0 * * *", // Restart every day at 00:00
      watch: false,
      max_memory_restart: "400M",
    },
    {
      name: "set-leverage",
      script: "./app/Jobs/SetLeverageJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "30 0 * * *", // Restart every day at 00:30
      watch: false,
      max_memory_restart: "800M",
    },
    {
      name: "set-marginType",
      script: "./app/Jobs/MarginTypeJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "30 0 * * *", // Restart every day at 00:30
      watch: false,
      max_memory_restart: "800M",
    },
    {
      name: "get-symbol-data",
      script: "./app/Jobs/GetSymbolsDataFromBinanceJob.js",
      instances: 1,
      autorestart: true,
      cron_restart: "30 0 * * *", // Restart every day at 00:30
      watch: false,
      max_memory_restart: "800M",
    },
    {
      name: "check-position",
      script: "./app/Jobs/CheckPositionJob.js",
      args: ["--type=your_type_value", "--orderId=your_order_id_value"],
    },
  ],
};
