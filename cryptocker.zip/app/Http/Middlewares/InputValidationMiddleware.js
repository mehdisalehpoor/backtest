import Handler from "../../Exceptions/handler";
import { validationResult } from "express-validator";
import { ErrorCode } from "../../Exceptions/errorCode";

class InputValidationMiddleware {
  static handle(req, res, next) {
    try {
      const result = validationResult(req);

      if (!result.isEmpty()) {
        const errorMessage = result.errors;
        console.log(result.errors);
        throw new Handler(ErrorCode.VALIDATION_FAILED, errorMessage);
      } else {
        next();
      }
    } catch (err) {
      next(err);
    }
  }
}

export default InputValidationMiddleware;
