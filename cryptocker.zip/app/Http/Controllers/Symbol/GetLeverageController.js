const { USDMClient } = require("binance");
const { apiKey } = require("../../../../config/configs");

class GetLeverageController {
  static async handle(req, res, next) {
    const symbol = req.body.symbol ?? null;
    try {
      const usdmClient = new USDMClient({
        api_key: apiKey.api_key,
        api_secret: apiKey.api_secret,
      });

      const getNotionalAndLeverageBrackets =
        await usdmClient.getNotionalAndLeverageBrackets({
          symbol,
        });

      res.send(getNotionalAndLeverageBrackets);
    } catch (error) {}
  }
}

module.exports = GetLeverageController;
