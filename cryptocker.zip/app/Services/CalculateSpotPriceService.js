
class CalculateSpotPriceService {
    static async handle(symbol,exchange){
        const spotPrice = await exchange.fetchTicker(symbol); // Fetching spot price of the symbol
        const spotPriceValue = spotPrice.last; // Extracting the last price of the spot price
      
        // Calculating 7% above and 7% below spot price
        const sevenPercentAboveSpotPrice = spotPriceValue * 1.07;
        const sevenPercentBelowSpotPrice = spotPriceValue * 0.93;
    }
}