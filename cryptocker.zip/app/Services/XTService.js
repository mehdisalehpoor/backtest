const axios = require("axios");
const ProxyService = require("./ProxyService");

class XTService {
  static async getOrderBook(symbol) {
    const axiosClient = axios.create({
      baseURL: "https://sapi.xt.com/v4/public/depth",
    });

    const agent = await ProxyService.getProxyAddress();

    const orderBookResponse = await axiosClient.get("", {
      params: {
        symbol: `${symbol.toLowerCase()}_usdt`,
        size: 500,
      },
      httpsAgent: agent,
    });

    const orderBook = orderBookResponse.data.result;

    const formattedResponse = {
      asks: orderBook.asks.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
      bids: orderBook.bids.map((item) => [
        parseFloat(item[0]),
        parseFloat(item[1]),
      ]),
    };

    return formattedResponse;
  }
}
module.exports = XTService;
