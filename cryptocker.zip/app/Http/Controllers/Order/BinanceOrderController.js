const { MainClient, USDMClient } = require("binance");
const { apiKey } = require("../../../../config/configs");

export class BinanceOrderController {

  static getPositionRisk = async (req, res, next) => {
    try {
      const { symbol } = req.body;

      // Example usage
      const client = new USDMClient({
        api_key: apiKey.api_key,
        api_secret: apiKey.api_secret,
      });

      // Get Position Rsik for Liquidation Price
      const getPositionRisk = await client.getPositions({
        symbol,
        timestamp: new Date().getTime(),
      });

      res.send(getPositionRisk);
    } catch (error) {
      res.status(500).send(error.body);
    }
  };

  static getAllOpenOrders = async (req, res, next) => {
    try {
      const { symbol, side } = req.body;
      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });
      // Get All Open Orders
      const getAllOrders = await client.getAllOpenOrders({
        symbol,
        timestamp: new Date().getTime(),
      });

      res.send(getAllOrders);
    } catch (error) {
      res.status(500).send(error.body);
    }
  };

  static getOrder = async (req, res, next) => {
    try {
      const { symbol, orderId } = req.body;
      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });
      // Get All Open Orders
      const getOrder = await client.getOrder({
        symbol,
        orderId,
        timestamp: new Date().getTime(),
      });

      res.send(getOrder);
    } catch (error) {
      res.status(500).send(error.body);
    }
  };

  static async addOrder(req, res, next) {
    try {
      // const orderParams = {
      //   symbol: req.body.symbol,
      //   side: req.body.side, // BUY or SELL
      //   positionSide: req.body.positionSide, // SHORT or LONG
      //   type: req.body.type ?? "MARKET", // MARKET or LIMIT
      //   quantity: req.body.quantity,
      //   stopPrice: req.body.stopPrice ?? null,
      //   price: req.body.price ?? null,
      //   timestamp: new Date().getTime(),
      // };

      req.body.timestamp = new Date().getTime();

      // Example usage
      const client = new USDMClient({
        api_key: apiKey.api_key,
        api_secret: apiKey.api_secret,
      });

      const submitNewOrder = await client.submitNewOrder(req.body);

      res.send(submitNewOrder);
    } catch (error) {
      res.status(500).send(error.body);
    }
  }

  static async closePosition(req, res, next) {
    try {
      const { symbol, side, type, positionSide, quantity } = req.body;

      const exitParams = {
        symbol: symbol,
        side: side,
        positionSide: positionSide,
        type: type,
        quantity: quantity,
        timestamp: new Date().getTime(),
      };

      console.log(exitParams);
      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });
      var newOrder = null;
      const submitNewOrder = await client
        .submitNewOrder(exitParams)
        .then((result) => {
          newOrder = result;
        });

      res.send(newOrder);
    } catch (error) {
      res.status(500).send(error.body);
    }
  }

  static async cancelOrder(req, res, next) {
    try {
      const { symbol, orderId } = req.body;

      const cancelParams = {
        symbol: symbol,
        orderId: orderId,
        timestamp: new Date().getTime(),
      };

      console.log(cancelParams);

      const API_KEY = apiKey.api_key;
      const API_SECRET = apiKey.api_secret;

      // Example usage
      const client = new USDMClient({
        api_key: API_KEY,
        api_secret: API_SECRET,
      });

      const cancel = await client.cancelOrder(cancelParams);

      res.send("Successful order cancel");
    } catch (error) {
      res.status(500).send(error.body);
    }
  }

  static async cancelAllOrders(req, res, next) {
    try {
      const { symbol } = req.body;

      const cancelParams = {
        symbol: symbol,
        timestamp: new Date().getTime(),
      };

      // Example usage
      const client = new USDMClient({
        api_key: apiKey.api_key,
        api_secret: apiKey.api_secret,
      });

      const cancel = await client.cancelAllOpenOrders(cancelParams);

      res.send(cancel);
    } catch (error) {
      res.status(500).send(error.body);
    }
  }
}
