import routes from "./Routes/SocketRoutes";

class SocketHandler {
  constructor(socket, io) {
    this.io = io;
    this.socket = socket;
    
    this.routes = routes.all();

    this.fetchRoutes();
  }

  async fetchRoutes() {

    this.routes.forEach(async (route, index) => {

      let event_name = route.event_name;

      this.routeHandler(event_name, route);
    });

  }

  async routeHandler(event_name, route) {
    this.socket.on(event_name, async (data) => {
      // get validation name and validate data
      const EventValidation = route.middlewares;

      let validation = await new EventValidation(
        this.io,
        this.socket,
        event_name,
        data
      );

      let validate = await validation.handle();

      if (validate) {
        // get event name and run event handler
        await this.eventHandler(route, event_name, data);
      }
    });
  }

  async eventHandler(route, event_name, data) {
    let event = await new route.handler(
      this.io,
      this.socket,
      event_name,
      data
    );
    event.handle();
  }
}

export default SocketHandler;
