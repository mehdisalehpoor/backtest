const RedisClientService = require("../../../RedisClientService");

const exchangeData = {};

const boxCalculate = async (data, baseSymbol, exchange) => {
  const step = 100;
  const percent = 0.1;
  const redis = new RedisClientService();
  const price = parseFloat(
    await redis.get(`${baseSymbol.toLowerCase()}usdt_price`)
  );

  const asks = await data.asks.map((item) => [
    parseFloat(item[0]),
    parseFloat(item[1]),
  ]);

  const bids = await data.bids.map((item) => [
    parseFloat(item[0]),
    parseFloat(item[1]),
  ]);
  // Initialize the exchangeData structure
  if (!exchangeData[baseSymbol]) {
    exchangeData[baseSymbol] = {
      totalBids: 0,
      totalAsks: 0,
      side: "",
      difference: 0,
      exchanges: {},
    };
  }

  if (!exchangeData[baseSymbol].exchanges[exchange]) {
    exchangeData[baseSymbol].exchanges[exchange] = {
      totalBids: 0,
      totalAsks: 0,
      asks: [],
      bids: [],
    };
  }

  // Check and add new asks if they don't already exist
  asks.forEach((newAsk) => {
    const askExists = exchangeData[baseSymbol].exchanges[exchange].asks.some(
      (existingAsk) =>
        existingAsk[0] === newAsk[0] && existingAsk[1] === newAsk[1]
    );
    if (!askExists) {
      exchangeData[baseSymbol].exchanges[exchange].asks.push(newAsk);
    }
  });

  // Check and add new bids if they don't already exist
  bids.forEach((newBid) => {
    const bidExists = exchangeData[baseSymbol].exchanges[exchange].bids.some(
      (existingBid) =>
        existingBid[0] === newBid[0] && existingBid[1] === newBid[1]
    );
    if (!bidExists) {
      exchangeData[baseSymbol].exchanges[exchange].bids.push(newBid);
    }
  });

  exchangeData[baseSymbol].exchanges[exchange].totalBids = bids.length;
  exchangeData[baseSymbol].exchanges[exchange].totalAsks = asks.length;
  exchangeData[baseSymbol].exchanges[exchange].asks = asks;
  exchangeData[baseSymbol].exchanges[exchange].bids = bids;

  exchangeData[baseSymbol].totalAsks = Object.values(
    exchangeData[baseSymbol].exchanges
  ).reduce((sum, { totalAsks }) => sum + totalAsks, 0);
  exchangeData[baseSymbol].totalBids = Object.values(
    exchangeData[baseSymbol].exchanges
  ).reduce((sum, { totalBids }) => sum + totalBids, 0);

  exchangeData[baseSymbol].side =
    exchangeData[baseSymbol].totalAsks >= exchangeData[baseSymbol].totalBids
      ? "sell"
      : "buy";
  exchangeData[baseSymbol].difference =
    exchangeData[baseSymbol].totalAsks >= exchangeData[baseSymbol].totalBids
      ? exchangeData[baseSymbol].totalAsks - exchangeData[baseSymbol].totalBids
      : exchangeData[baseSymbol].totalBids - exchangeData[baseSymbol].totalAsks;

  // Merge all asks and bids from different exchanges
  exchangeData[baseSymbol].asks = Object.values(
    exchangeData[baseSymbol].exchanges
  ).flatMap((exchange) => exchange.asks);

  exchangeData[baseSymbol].bids = Object.values(
    exchangeData[baseSymbol].exchanges
  ).flatMap((exchange) => exchange.bids);

  let belowSpotPrice = price;
  let aboveSpotPrice = price;
  const box = [];

  if (
    exchangeData[baseSymbol] &&
    (exchangeData[baseSymbol].asks.length > 0 ||
      exchangeData[baseSymbol].bids.length > 0)
  ) {
    for (let i = 0; i < step; i++) {
      var below = exchangeData[baseSymbol].bids.filter(
        ([price]) =>
          price <= belowSpotPrice &&
          price > belowSpotPrice - (belowSpotPrice * percent) / 100
      );

      var above = exchangeData[baseSymbol].asks.filter(
        ([price]) =>
          price >= aboveSpotPrice &&
          price < aboveSpotPrice + (aboveSpotPrice * percent) / 100
      );

      const bidLowestPrice =
        below.length > 0 ? Math.min(...below.map((item) => item[0])) : 0;
      const bidBiggestPrice =
        below.length > 0 ? Math.max(...below.map((item) => item[0])) : 0;
      const askLowestPrice =
        above.length > 0 ? Math.min(...above.map((item) => item[0])) : 0;
      const askBiggestPrice =
        above.length > 0 ? Math.max(...above.map((item) => item[0])) : 0;

      var sumBelow =
        below.reduce((total, [price, volume]) => total + volume * price, 0) ||
        1;

      var sumAbove =
        above.reduce((total, [price, volume]) => total + volume * price, 0) ||
        1;

      belowSpotPrice = belowSpotPrice - (belowSpotPrice * percent) / 100;
      aboveSpotPrice = aboveSpotPrice + (aboveSpotPrice * percent) / 100;

      if (below.length > 0 || above.length > 0) {
        box.push({
          i,
          price,
          side: sumBelow >= sumBelow ? "buy" : "sell",
          bidLowestPrice,
          bidBiggestPrice,
          askLowestPrice,
          askBiggestPrice,
          belowLength: below.length,
          aboveLength: above.length,
          sumBelow: sumBelow ?? 0,
          sumAbove: sumAbove ?? 0,
        });
      }
    }
  }
  exchangeData[baseSymbol].box = box;
  return exchangeData;
};

module.exports = boxCalculate;
