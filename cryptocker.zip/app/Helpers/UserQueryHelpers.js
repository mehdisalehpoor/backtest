
const UserModel = require("./../Models/UserModel");
// const OtpCodeModel = require("./../Models/OtpCodeModel");
class UserQueryHelpers {
    static async findUserWithMobile(mobile) {
        const user = await UserModel.findOne({
            where: {
                mobile: mobile,
            },
        });
        return user;
    }

    // static async findOtpCode(mobile, otp) {
    //     const otpData = await OtpCodeModel.findOne({
    //         where: {
    //             mobile: mobile,
    //             otp: otp
    //         },
    //     });
    //     return otpData;
    // }

    static async updateOtpCode(id) {
        const otpData = await OtpCodeModel.update(
            {
                used_at: Date.now(),
            },
            {
                where: { id: id },
            }
        );

        return otpData;
    }
}

module.exports = UserQueryHelpers;