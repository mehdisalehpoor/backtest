import express from "express";
import { SendCodeController, VerifyCodeController } from "../../../app/Http/Controllers/Auth";
import { SendCodeRequest } from "../../../app/Http/Requests/Auth/SendCodeRequest";
import { VerifyCodeRequest } from "../../../app/Http/Requests/Auth/VerifyCodeRequest";

const authRouter = express.Router();

//  @desc   Send Code to User
//  @route  POST /auth/send-code
authRouter.post("/send-code", SendCodeRequest, SendCodeController.handle);

//  @desc   Verify Code to User
//  @route  POST /auth/verify-code
authRouter.post("/verify-code", VerifyCodeRequest, VerifyCodeController.handle);

module.exports = authRouter;
