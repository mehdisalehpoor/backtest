const UserModel = require("../Models/UserModel");
const DateHelpers = require("./DateHelpers");
const { Op } = require("sequelize");
const TelegramBotService = require("../Services/TelegramBotService");
const CoinmarketcapService = require("../Services/CoinmarketcapService");
const { convertToShortForm } = require("./Helpers");
const SignalModel = require("../Models/SignalModel");
const SymbolModel = require("../Models/SymbolModel");
const SymbolQueryHelpers = require("./SymbolQueryHelpers");
const ApiService = require("../Services/ApiService");
const OrderModel = require("../Models/OrderModel");
const SymbolVolumeModel = require("../Models/SymbolVolumeModel");
class OrderbookHelpers {
  static async futuresFifteenBoxEnterSignalOrderbook(
    exchangeSuccessFull,
    symbol,
    symbolId,
    orderBooks,
    spotPrice,
    step,
    percent = 7,
    customRate = 4.5,
    getVolume = false
  ) {
    try {
      const { bids, asks } = orderBooks;
      const boxAsks = [];
      const densityAskForBox = [];
      const boxBids = [];
      const densityBidForBox = [];
      const boxFiveAsks = [];
      const boxFiveBids = [];

      const sortedBids = [...bids].sort((a, b) => b[0] - a[0]);
      const sortedAsks = [...asks].sort((a, b) => a[0] + b[0]);

      let aboveSpotPrice = spotPrice;
      let belowSpotPrice = spotPrice;

      ({ aboveSpotPrice, belowSpotPrice } =
        OrderbookHelpers.calculateBoxAsksBids(
          step,
          sortedAsks,
          aboveSpotPrice,
          percent,
          sortedBids,
          belowSpotPrice,
          boxAsks,
          boxFiveAsks,
          boxBids,
          boxFiveBids,
          densityAskForBox,
          densityBidForBox
        ));

      const box = { boxAsks, boxBids };
      const calculateBox = [];

      if (boxAsks.length > 0 && boxBids.length > 0) {
        let exAsks = 0;
        let exBids = 0;
        let exFivePercentAsks = 0;
        let exFivePercentBids = 0;
        const boxData = [];

        ({ exAsks, exBids } =
          await OrderbookHelpers.calculateFifteenBoxForFutures(
            boxAsks,
            boxBids,
            exAsks,
            exBids,
            boxData,
            symbol,
            spotPrice,
            calculateBox,
            boxFiveAsks,
            boxFiveBids,
            exFivePercentAsks,
            exFivePercentBids,
            densityAskForBox,
            densityBidForBox
          ));

        const volumeOfExAsks = boxData
          .slice(0, 5)
          .reduce((total, obj) => total + obj.exAsks, 0);

        const densityAsks = boxData
          .slice(0, 5)
          .reduce((total, obj) => total + obj.densityAsks, 0);

        const volumeOfExBids = boxData
          .slice(0, 5)
          .reduce((total, obj) => total + obj.exBids, 0);

        const densityBids = boxData
          .slice(0, 5)
          .reduce((total, obj) => total + obj.densityBids, 0);

        var startCandleVolume = null;

        var { message, BigFConditionIn, BigFConditionOut } =
          OrderbookHelpers.messageForLogs(
            symbol,
            spotPrice,
            boxData,
            volumeOfExAsks,
            volumeOfExBids,
            densityAsks,
            densityBids,
            startCandleVolume,
            step
          );

        TelegramBotService.futuresLogsSend(`[FUTURES]\n${message}`);

        const volumeCondition =
          parseFloat(boxData[0].difference) >= 2700000 ? true : false;

        const firstItem = boxData[0].densityDetails;
        const secondItem = boxData[1].densityDetails;
        const status = boxData[0].sale;

        const minDensityDiffIndex = firstItem.reduce(
          (minIndex, box, currentIndex) => {
            return box.densityDiff >= firstItem[minIndex].densityDiff
              ? currentIndex
              : minIndex;
          },
          0
        );

        const payloadExcepOne = boxData.slice(1);
        const countDensityVolumeStatus = payloadExcepOne.reduce(
          (count, box) => {
            if (box.sale === status) {
              return count + 1;
            }
            return count;
          },
          0
        );

        const twoDensityBox = firstItem.concat(secondItem);

        const countTwoDensityVolumeStatus = twoDensityBox.reduce(
          (count, box) => {
            if (box.densityBoxStatus !== status) {
              return count + 1;
            }
            return count;
          },
          0
        );

        const countTwoVolumeStatus = twoDensityBox.reduce((count, box) => {
          if (box.densityVolumeStatus == status) {
            return count + 1;
          }
          return count;
        }, 0);

        var conditionVolume = false;
        var conditionDB = false;
        var conditionDensityBox = false;
        // first volume condition
        conditionVolume = OrderbookHelpers.volumeConditionCheck(
          minDensityDiffIndex,
          countDensityVolumeStatus,
          countTwoDensityVolumeStatus,
          firstItem,
          status,
          conditionVolume,
          volumeCondition
        );

        // db check condition 8 in direction volume boxes(0.5) and 6 in direction density boxes
        conditionDB = OrderbookHelpers.conditionDbCheck(
          status,
          conditionDB,
          firstItem,
          minDensityDiffIndex
        );
        if (countTwoVolumeStatus == 8 && countTwoDensityVolumeStatus <= 2)
          conditionDensityBox = true;

        const lastTwoHours = DateHelpers.lastHours(2);

        const symbolExists = await SymbolModel.findOne({
          where: { symbol: symbol },
        });

        var signalCount = await SignalModel.count({
          where: {
            symbol_id: symbolExists.id,
            exit: false,
            created_at: {
              [Op.between]: [
                lastTwoHours.startOfLastHours,
                lastTwoHours.endOfLastHours,
              ],
            },
          },
        });

        const getSymbol = await SymbolModel.findOne({
          where: {
            symbol: symbol,
          },
        });

        const extractedData = boxData.map((item) => {
          const data = {
            sale: status,
            difference: parseFloat(item.difference),
            exAsks: parseFloat(item.exAsks),
            exBids: parseFloat(item.exBids),
            densityAsks: parseFloat(item.densityAsks),
            densityBids: parseFloat(item.densityBids),
            densityDetails: item.densityDetails,
          };

          return data;
        });

        const payload = extractedData;
        // try {
        //   var symbolVolumeModel = await SymbolVolumeModel.create({
        //     symbolId: getSymbol.id,
        //     spotPrice: spotPrice,
        //     asksVolume: Math.floor(parseFloat(volumeOfExAsks)), // Convert to integer
        //     bidsVolume: Math.floor(parseFloat(volumeOfExBids)),
        //     bidsDensityVolume: Math.floor(parseFloat(densityBids)),
        //     asksDensityVolume: Math.floor(parseFloat(densityAsks)),
        //     payload: JSON.stringify(payload),
        //     exchangesVolume: 0,
        //     signalType: "",
        //     begin: false,
        //   });
        // } catch (error) {
        //   console.log("OrderbookHelper SymbolVolumeModel" + error);
        // }

        var signalType = "";
        signalType =
          conditionVolume && signalType == ""
            ? "Volume_Signal"
            : conditionDB && signalType == ""
            ? "DB_Signal"
            : countTwoVolumeStatus && signalType == ""
            ? "DBox_Signal"
            : "";

        if (
          (conditionDB && signalCount == 0) ||
          (conditionDensityBox && signalCount == 0) ||
          (conditionVolume && signalCount == 0)
        ) {
          const {
            coinmarketcapSale,
            depthPositiveTwoSum,
            depthUsdNegativeTwo,
            coinmarketcapRate,
            exchanges,
            coinmarketcapNotExistsExchangesSale,
            diffExistsExchangesDepthPositiveTwo,
            diffExistsExchangesDepthNegativeTwo,
            sumNotExistsExchangesDepthPositiveTwo,
            sumNotExistsExchangesDepthNegativeTwo,
            sumExistsExchangesVolume,
          } = await OrderbookHelpers.coinmarketcapCalculate(
            symbolExists,
            exchangeSuccessFull
          );

          if (sumExistsExchangesVolume < 90) {
            var underNintyErrorMessage = `[ERROR]\nSignal Type=${signalType}\nmessage=Volume Under 90\nsymbol=${symbol}\nCMCVolume=${sumExistsExchangesVolume.toFixed(
              0
            )}`;
            TelegramBotService.futuresSignalSend(underNintyErrorMessage);
          }
          // try {
          //   await SymbolVolumeModel.update(
          //     {
          //       exchangesVolume: Math.floor(
          //         parseFloat(sumExistsExchangesVolume)
          //       ),
          //       signalType: signalType,
          //     },
          //     { where: { id: symbolVolumeModel.id } }
          //   );
          // } catch (error) {
          //   TelegramBotService.futuresSignalSend(
          //     "OrderbookHelper SymbolVolumeModel Update" + error
          //   );
          // }

          if (
            status == coinmarketcapSale &&
            sumExistsExchangesVolume >= 85 &&
            signalCount == 0
          ) {
            var textSignal = `[FUTURES]\n#signal\nSignalType=${signalType}\nCMCVolume=${sumExistsExchangesVolume.toFixed(
              0
            )}\n${message}`;

            //   // if (condition >= 1 && condition <= 5) {
            //   //   ApiService.call(`${symbol}USDT`, boxData[0].sale, condition);
            //   // }

            TelegramBotService.futuresSend(textSignal);

            //   if (signalCount == 0) {
            //     // await SignalModel.create({
            //     //   symbol_id: symbolExists.id,
            //     //   coinmarketcap_status: coinmarketcapSale,
            //     //   coinmarketcap_rate: coinmarketcapRate,
            //     //   symbol_status: boxData[0].sale,
            //     //   symbol_rate: boxData[0].rate,
            //     //   rsi: null,
            //     // });
            //   }
          }
        }
      }

      return box;
    } catch (error) {
      console.log(error);
      var message = symbol + " " + error;
      TelegramBotService.futuresSignalSend("OrderBookHelpers " + message);
    }
  }

  static conditionDbCheck(status, conditionDB, firstItem, minDensityDiffIndex) {
    const countStatus = firstItem.reduce((count, box) => {
      if (box.densityVolumeStatus == status) {
        return count + 1;
      }
      return count;
    }, 0);

    console.log(
      minDensityDiffIndex,
      countStatus,
      firstItem[0].densityBoxRate,
      status,
      firstItem[0].densityBoxStatus,
      firstItem[0].densityVolumeStatus,
      firstItem
    );

    conditionDB =
      firstItem[0].densityBoxRate >= 80 &&
      status == firstItem[0].densityBoxStatus &&
      status == firstItem[0].densityVolumeStatus &&
      countStatus == 4 &&
      minDensityDiffIndex == 0
        ? true
        : false;
    return conditionDB;
  }

  static volumeConditionCheck(
    minDensityDiffIndex,
    countDensityVolumeStatus,
    countTwoDensityVolumeStatus,
    firstItem,
    status,
    conditionVolume,
    volumeCondition
  ) {
    const firstCondition =
      minDensityDiffIndex !== 2 &&
      countDensityVolumeStatus >= 1 &&
      countTwoDensityVolumeStatus < 6;

    const secondCondition =
      (firstCondition && parseFloat(firstItem[0].densityDiff) < 900000) ||
      (firstCondition &&
        parseFloat(firstItem[0].densityDiff) > 900000 &&
        parseFloat(firstItem[0].densityBoxRate) > 10 &&
        firstItem[0].densityVolumeStatus === status &&
        firstItem[1].densityBoxStatus === status);

    const thirdCondition =
      (firstCondition && parseFloat(firstItem[1].densityDiff) < 900000) ||
      (firstCondition &&
        parseFloat(firstItem[1].densityDiff) > 900000 &&
        firstItem[1].densityBoxStatus === status &&
        firstItem[1].densityVolumeStatus === status &&
        parseFloat(firstItem[1].densityBoxRate) > 10);

    conditionVolume = volumeCondition && secondCondition && thirdCondition;
    return conditionVolume;
  }

  static messageForLogs(
    symbol,
    spotPrice,
    boxData,
    volumeOfExAsks,
    volumeOfExBids,
    densityAsks,
    densityBids,
    startCandleVolume,
    step
  ) {
    var message = `Symbol Name = ${symbol}\nSpot Price = ${spotPrice}\nStatus = ${
      boxData[0].sale == "buy" ? "buy 🔼" : "sell 🔽"
    }\nVolume Diff = ${boxData[0].difference.toFixed(
      2
    )}\nSum of Asks = ${boxData[0].exAsks.toFixed(
      2
    )}\nSum of Bids = ${boxData[0].exBids.toFixed(2)}\n`;

    message += `Asks Volume in 10% = ${volumeOfExAsks.toFixed(
      0
    )}\nBids Volume in 10% =${volumeOfExBids.toFixed(0)}\n`;

    message += `Asks Density in 10% = ${densityAsks.toFixed(
      0
    )}\nBids Density in 10% =${densityBids.toFixed(0)}\n`;

    if (startCandleVolume != null) {
      message += `First Asks Volume in 10% = ${startCandleVolume.asksVolume}\nFirst Bids Volume in 10% =${startCandleVolume.bidsVolume}\n`;

      message += `First Asks Density in 10% = ${startCandleVolume.asksDensityVolume}\nFirst Bids Density in 10% =${startCandleVolume.bidsDensityVolume}\n`;
    }

    var BigFConditionIn = boxData[0].bigF.BigFConditionIn;
    var BigFConditionOut = boxData[0].bigF.BigFConditionOut;

    if (BigFConditionIn == true) message += `\nBig F In The Direction\n`;
    if (BigFConditionOut == true) message += `\nBig F Out of Direction\n`;

    var densityTitleMessage = "";
    var boxMessage = "";
    for (let i = 0; i < step && i < boxData.length; i++) {
      const densityInBox = boxData[i].densityDetails;

      if (i == 0 || i == 1) {
        var densityMessage = "";
        densityTitleMessage += `\nDensity in Box ${i + 1}`;
        for (let index = 0; index < densityInBox.length; index++) {
          const densityBoxStatus = densityInBox[index].densityBoxStatus ?? null;
          const densityBoxRate = densityInBox[index].densityBoxRate ?? null;
          const densityVolumeStatus =
            densityInBox[index].densityVolumeStatus ?? null;
          const densitydDiff = densityInBox[index].densityDiff ?? null;

          const priceRangeUp =
            densityInBox[index].priceRange.upperPrice ?? null;
          const priceRangeLow =
            densityInBox[index].priceRange.lowerPrice ?? null;
          densityMessage += `DB${
            index + 1
          } = ${densityBoxStatus}, ${densityBoxRate.toFixed(
            2
          )}, ${densityVolumeStatus}, ${densitydDiff.toFixed(
            0
          )}, ${priceRangeUp} | ${priceRangeLow}\n`;
        }
        densityTitleMessage += `\n${densityMessage}`;
      }

      boxMessage += `\nBox[${i + 1}] = ${boxData[i].difference.toFixed(2)} , ${
        boxData[i].sale == "buy" ? "buy 🔼" : "sell 🔽"
      }`;
    }

    message += densityTitleMessage;
    message += "\n";
    message += boxMessage;
    message += "\n";
    return { message, BigFConditionIn, BigFConditionOut };
  }

  static calculateBoxAsksBids(
    step,
    sortedAsks,
    aboveSpotPrice,
    percent,
    sortedBids,
    belowSpotPrice,
    boxAsks,
    boxFiveAsks,
    boxBids,
    boxFiveBids,
    densityAskForBox,
    densityBidForBox
  ) {
    for (let i = 0; i < step; i++) {
      const densityStep = percent / 0.5;
      const densityAskBox = [];
      const densityBidBox = [];
      try {
        if (i != step) {
          var above = sortedAsks.filter(
            ([price]) =>
              price >= aboveSpotPrice &&
              price <= aboveSpotPrice + (aboveSpotPrice * percent) / 100
          );
          var below = sortedBids.filter(
            ([price]) =>
              price <= belowSpotPrice &&
              price >= belowSpotPrice - (belowSpotPrice * percent) / 100
          );

          var aboveDensitySpotPrice = aboveSpotPrice;
          var belowDensitySpotPrice = belowSpotPrice;
          for (let j = 0; j < densityStep; j++) {
            var aboveDensity = sortedAsks.filter(
              ([price]) =>
                price >= aboveDensitySpotPrice &&
                price <=
                  aboveDensitySpotPrice + (aboveDensitySpotPrice * 0.5) / 100
            );

            var belowDensity = sortedBids.filter(
              ([price]) =>
                price <= belowDensitySpotPrice &&
                price >=
                  belowDensitySpotPrice - (belowDensitySpotPrice * 0.5) / 100
            );

            densityAskBox.push(aboveDensity);
            densityBidBox.push(belowDensity);

            if (densityAskBox.length > 0) {
              aboveDensitySpotPrice =
                aboveDensitySpotPrice + (aboveDensitySpotPrice * 0.5) / 100;
            } else {
              aboveDensitySpotPrice = undefined;
            }

            if (densityBidBox.length > 0) {
              belowDensitySpotPrice =
                belowDensitySpotPrice - (belowDensitySpotPrice * 0.5) / 100;
            } else {
              belowDensitySpotPrice = undefined;
            }
          }
        } else {
          var above = sortedAsks.filter(
            ([price]) =>
              price >= aboveSpotPrice &&
              price <= aboveSpotPrice + (aboveSpotPrice * 56) / 100
          );
          var below = sortedBids.filter(
            ([price]) =>
              price <= belowSpotPrice &&
              price >= belowSpotPrice - (belowSpotPrice * 56) / 100
          );
        }

        if (i === 0) {
          var aboveFivePercent = sortedAsks.filter(
            ([price]) =>
              price >= aboveSpotPrice + (aboveSpotPrice * 2) / 100 &&
              price <= aboveSpotPrice + (aboveSpotPrice * percent) / 100
          );

          var belowFivePercent = sortedBids.filter(
            ([price]) =>
              price <= belowSpotPrice - (belowSpotPrice * 2) / 100 &&
              price >= belowSpotPrice - (belowSpotPrice * percent) / 100
          );
        } else {
          var aboveFivePercent = [];
          var belowFivePercent = [];
        }

        boxAsks.push(above);
        densityAskForBox.push(densityAskBox);

        boxFiveAsks.push(aboveFivePercent);

        boxBids.push(below);
        densityBidForBox.push(densityBidBox);
        boxFiveBids.push(belowFivePercent);

        if (above.length > 0) {
          aboveSpotPrice = aboveSpotPrice + (aboveSpotPrice * percent) / 100;
        } else {
          aboveSpotPrice = undefined;
        }

        if (below.length > 0) {
          belowSpotPrice = belowSpotPrice - (belowSpotPrice * percent) / 100;
        } else {
          belowSpotPrice = undefined;
        }
      } catch (error) {
        console.log(i, aboveSpotPrice);
        console.log(error);
      }
    }
    return { aboveSpotPrice, belowSpotPrice };
  }

  static getTextData(
    signalStatus,
    logsText,
    symbol,
    spotPrice,
    boxData,
    depthPositiveTwoSum,
    depthUsdNegativeTwo,
    coinmarketcapRate,
    coinmarketcapSale,
    textSignal,
    text,
    // rsiNumber,
    // rsiSide,
    farBoxMessage,
    sumNotExistsExchangesDepthPositiveTwo,
    sumNotExistsExchangesDepthNegativeTwo,
    BigFConditionIn,
    BigFConditionOut,
    sumExistsExchangesVolume = null,
    densityBoxMessage = null
  ) {
    var textMainData = `${signalStatus}\n${logsText}Symbol Name = ${symbol}\nSpot Price = ${spotPrice}\nRate = ${boxData[0].rate.toFixed(
      2
    )}\nStatus = ${boxData[0].sale}\nSum of Asks = ${boxData[0].exAsks.toFixed(
      2
    )}\nSum of Bids = ${boxData[0].exBids.toFixed(
      2
    )}\nCMCapAsks = ${depthPositiveTwoSum.toFixed(
      2
    )}\nCMCapBids = ${depthUsdNegativeTwo.toFixed(
      2
    )}\nCMCapNotExistsAsks = ${sumNotExistsExchangesDepthPositiveTwo.toFixed(
      2
    )}\nCMCapNotExistsBids = ${sumNotExistsExchangesDepthNegativeTwo.toFixed(
      2
    )}\nCMCapRate = ${coinmarketcapRate.toFixed(
      2
    )}\nCMCapSale = ${coinmarketcapSale}\n`;
    // textMainData += `\nRSI = ${rsiNumber}\nRSI Side = ${rsiSide}\n`;
    if (sumExistsExchangesVolume != null)
      textMainData += `CMCapExistsVolume = ${sumExistsExchangesVolume.toFixed(
        2
      )}\n`;
    if (BigFConditionIn == true) textMainData += `Big F In The Direction\n`;
    if (BigFConditionOut == true) textMainData += `Big F Out of Direction\n`;

    textMainData += "Boxes\n";
    textSignal += textMainData;
    textSignal += text;
    text += "\n";
    textSignal += "\nFarBoxes\n";
    textSignal += farBoxMessage;
    if (densityBoxMessage) {
      textSignal += "\nDensityBoxes\n";
      textSignal += densityBoxMessage;
    }
    return { textSignal, text };
  }

  static async getFifteenPressure(
    boxData,
    depthPositiveTwoSum,
    depthUsdNegativeTwo,
    text,
    pressureArray,
    signal
  ) {
    for (let i = 0; i < 15 && i < boxData.length; i++) {
      var pressure;
      ({ pressure } = OrderbookHelpers.calculatePressure(
        i,
        boxData,
        depthPositiveTwoSum,
        depthUsdNegativeTwo,
        pressure,
        signal
      ));

      if (
        pressure != null &&
        pressure != undefined &&
        pressure != NaN &&
        pressure != 0
      ) {
        text += `\n${i + 1} ${boxData[i].sale} | R${boxData[i].rate.toFixed(
          2
        )} | P${pressure.toFixed(2)} `;
      } else {
        text += `\n${i + 1} ${boxData[i].sale} | R${boxData[i].rate.toFixed(
          2
        )} `;
      }
      const volume = await convertToShortForm(boxData[i].volumeCount);
      pressureArray.push(pressure);

      text += `| V${volume},$ ${boxData[i].volumePrice}`;
    }
    return text;
  }

  static async checkToExit(boxData, signal, pressureArray, coinmarketcapSale) {
    const checkCondition = (startIndex, endIndex) => {
      const selectedItems = boxData.slice(startIndex, endIndex);
      if (signal)
        return selectedItems.every((item) => item.sale == signal.symbol_status);
      else return false;
    };

    const checkPressure = (startIndex, endIndex) => {
      const selectedItems = pressureArray.slice(startIndex, endIndex);
      return selectedItems.every((item) => item >= 0);
    };

    const conditions = signal.symbol_status == coinmarketcapSale ? true : false;
    const logsText = `#Logs\n`;
    const signalStatus = conditions ? "#Status = KeepMoving" : "#Status = Exit";
    const signalExit = conditions ? true : false;

    if (!conditions) {
      await SignalModel.update(
        {
          exit: true,
        },
        { where: { id: signal.id, exit: false } }
      );
    }
    return { signalStatus, logsText, signalExit };
  }

  static calculatePressure(
    i,
    boxData,
    depthPositiveTwoSum,
    depthUsdNegativeTwo,
    pressure,
    signal
  ) {
    var area, force;
    if (i === 0) {
      if (boxData[i].sale === "buy" && boxData[i + 1]) {
        const sumBidsFive = boxData[i].exFivePercentBids + depthUsdNegativeTwo;
        const sumAsksFive = boxData[i].exFivePercentAsks + depthPositiveTwoSum;
        area = sumBidsFive - sumAsksFive;
        force =
          boxData[i + 1].sale === boxData[0].sale
            ? boxData[i + 1].exBids - boxData[i + 1].exAsks
            : boxData[i + 1].exAsk - boxData[i + 1].exBids;
        const num = force / area;

        pressure = boxData[i + 1].sale !== signal ? num * -1 : num;
      } else if (boxData[i].sale === "sell" && boxData[i + 1]) {
        const sumBidsFive = boxData[i].exFivePercentBids + depthUsdNegativeTwo;
        const sumAsksFive = boxData[i].exFivePercentAsks + depthPositiveTwoSum;
        area = sumAsksFive - sumBidsFive;
        force =
          boxData[i + 1].sale === boxData[0].sale
            ? boxData[i + 1].exAsks - boxData[i + 1].exBids
            : boxData[i + 1].exBids - boxData[i + 1].exAsks;
        const num = force / area;
        pressure = boxData[i + 1].sale !== signal ? num * -1 : num;
      } else {
        pressure = 0;
      }
    } else {
      if (boxData[i].sale === "buy" && boxData[i + 1]) {
        area = boxData[i].exBids - boxData[i].exAsks;
        force =
          boxData[i + 1].sale === signal
            ? boxData[i + 1].exBids - boxData[i + 1].exAsks
            : boxData[i + 1].exAsk - boxData[i + 1].exBids;
        const num = force / area;
        pressure = boxData[i + 1].sale !== signal ? num * -1 : num;
      } else if (boxData[i].sale === "sell" && boxData[i + 1]) {
        area = boxData[i].exAsks - boxData[i].exBids;
        force =
          boxData[i + 1].sale === signal
            ? boxData[i + 1].exAsks - boxData[i + 1].exBids
            : boxData[i + 1].exBids - boxData[i + 1].exAsks;
        const num = force / area;
        pressure = boxData[i + 1].sale !== signal ? num * -1 : num;
      } else {
        pressure = 0;
      }
    }

    return { pressure };
  }

  static async coinmarketcapCalculate(symbolExists, exchangeSuccessFull) {
    const coinmarketcap = await CoinmarketcapService.getLatestMarketPairs(
      symbolExists.name
    );

    const exchanges = coinmarketcap.data.marketPairs;

    const depthPositiveTwoSum = coinmarketcap.data.marketPairs.reduce(
      (sum, pair) => sum + pair.depthUsdPositiveTwo,
      0
    );

    const depthUsdNegativeTwo = coinmarketcap.data.marketPairs.reduce(
      (sum, pair) => sum + pair.depthUsdNegativeTwo,
      0
    );

    const coinmarketcapRate =
      depthPositiveTwoSum >= depthUsdNegativeTwo
        ? depthPositiveTwoSum / depthUsdNegativeTwo
        : depthUsdNegativeTwo / depthPositiveTwoSum;

    const coinmarketcapSale =
      depthPositiveTwoSum >= depthUsdNegativeTwo ? "sell" : "buy";

    const myExchanges = exchangeSuccessFull;

    const filteredExistsExchanges = exchanges.filter((exchange) => {
      // Check if exchangeId exists in myExchanges
      const matchingExchange = myExchanges.find(
        (myExchange) => myExchange.exchangeId === exchange.exchangeId
      );

      // Check if quoteSymbol is "USDT"
      return matchingExchange && exchange.quoteSymbol === "USDT";
    });

    const filteredNotExistsExchanges = exchanges.filter((exchange) => {
      // Check if exchangeId does not exist in myExchanges
      const exchangeIdNotInMyExchanges = !myExchanges.some(
        (myExchange) => myExchange.exchangeId === exchange.exchangeId
      );

      // Check if quoteSymbol is not "USDT"
      const quoteSymbolNotUSDT = exchange.quoteSymbol !== "USDT";

      // Return true if both conditions are met (i.e., exchangeId is not in myExchanges and quoteSymbol is not USDT)
      return exchangeIdNotInMyExchanges && quoteSymbolNotUSDT;
    });

    const sumExistsExchangesDepthPositiveTwo = filteredExistsExchanges.reduce(
      (sum, pair) => sum + pair.depthUsdPositiveTwo,
      0
    );

    const sumExistsExchangesDepthNegativeTwo = filteredExistsExchanges.reduce(
      (sum, pair) => sum + pair.depthUsdNegativeTwo,
      0
    );

    const sumExistsExchangesVolume = filteredExistsExchanges.reduce(
      (sum, pair) => sum + pair.volumePercent,
      0
    );

    const sumNotExistsExchangesDepthPositiveTwo =
      filteredNotExistsExchanges.reduce(
        (sum, pair) => sum + pair.depthUsdPositiveTwo,
        0
      );

    const sumNotExistsExchangesDepthNegativeTwo =
      filteredNotExistsExchanges.reduce(
        (sum, pair) => sum + pair.depthUsdNegativeTwo,
        0
      );

    const diffExistsExchangesDepthPositiveTwo =
      (sumExistsExchangesDepthPositiveTwo * 100) / depthPositiveTwoSum;
    const diffExistsExchangesDepthNegativeTwo =
      (sumExistsExchangesDepthNegativeTwo * 100) / depthUsdNegativeTwo;

    const coinmarketcapNotExistsExchangesSale =
      sumNotExistsExchangesDepthPositiveTwo >=
      sumNotExistsExchangesDepthNegativeTwo
        ? "sell"
        : "buy";

    var message = `Symbol Name = ${symbolExists.symbol}\nCMCAPSale = ${coinmarketcapSale}\n`;
    message += `CMCAPRate = ${coinmarketcapRate}\nCMCapNESale = ${coinmarketcapNotExistsExchangesSale}\n`;
    message += `CMCAPAsksDiff = ${diffExistsExchangesDepthPositiveTwo}\n`;
    message += `CMCAPBidsDiff = ${diffExistsExchangesDepthNegativeTwo}\n`;

    diffExistsExchangesDepthPositiveTwo;
    diffExistsExchangesDepthNegativeTwo;
    return {
      coinmarketcapSale,
      depthPositiveTwoSum,
      depthUsdNegativeTwo,
      coinmarketcapRate,
      exchanges,
      coinmarketcapNotExistsExchangesSale,
      diffExistsExchangesDepthPositiveTwo,
      diffExistsExchangesDepthNegativeTwo,
      sumNotExistsExchangesDepthPositiveTwo,
      sumNotExistsExchangesDepthNegativeTwo,
      sumExistsExchangesVolume,
    };
  }

  static calculateFifteenBoxForFutures(
    boxAsks,
    boxBids,
    exAsks,
    exBids,
    boxData,
    symbol,
    spotPrice,
    calculateBox,
    boxFiveAsks,
    boxFiveBids,
    exFivePercentAsks,
    exFivePercentBids,
    densityAskForBox,
    densityBidForBox
  ) {
    for (let orderIndex = 0; orderIndex < boxAsks.length; orderIndex++) {
      const densityAskForBoxOrderIndex = densityAskForBox[orderIndex];
      const densityBidForBoxOrderIndex = densityBidForBox[orderIndex];

      const currentAsks = boxAsks[orderIndex];
      const currentBids = boxBids[orderIndex];
      const currentFiveAsks = boxFiveAsks[orderIndex];
      const currentFiveBids = boxFiveBids[orderIndex];
      const densityDetails = [];

      if (currentAsks.length > 0) {
        for (
          let desnsityOrderIndex = 0;
          desnsityOrderIndex < densityAskForBoxOrderIndex.length;
          desnsityOrderIndex++
        ) {
          var densityAsk = densityAskForBoxOrderIndex[desnsityOrderIndex];
          var densityBid = densityBidForBoxOrderIndex[desnsityOrderIndex];
          var densityBoxStatus =
            densityAsk.length >= densityBid.length ? "sell" : "buy";
          var densityBoxRate =
            densityAsk.length >= densityBid.length
              ? densityAsk.length - densityBid.length
              : densityBid.length - densityAsk.length;

          const sortedDensityAsksData = [
            ...densityAskForBoxOrderIndex[desnsityOrderIndex],
          ].sort((a, b) => b[0] - a[0]);

          const firstElementDensityAsk = sortedDensityAsksData[0] ?? [0, 0];
          const lastElementDensityAsk = sortedDensityAsksData[
            sortedDensityAsksData.length - 1
          ] ?? [0, 0];

          const sortedDensityBidsData = [
            ...densityBidForBoxOrderIndex[desnsityOrderIndex],
          ].sort((a, b) => b[0] - a[0]);

          const sumDensityAsks =
            sortedDensityAsksData.reduce(
              (total, [value0, value1]) => total + value1 * value0,
              0
            ) || 1;

          const sumDensityBids =
            sortedDensityBidsData.reduce(
              (total, [value0, value1]) => total + value1 * value0,
              0
            ) || 1;

          const firstElementDensityBid = sortedDensityBidsData[0] ?? [0, 0];
          const lastElementDensityBid = sortedDensityBidsData[
            sortedDensityBidsData.length - 1
          ] ?? [0, 0];

          const densityVolumeStatus =
            sumDensityAsks >= sumDensityBids ? "sell" : "buy";

          const densityDiff =
            densityVolumeStatus == "sell"
              ? sumDensityAsks - sumDensityBids
              : sumDensityBids - sumDensityAsks;

          const index0Values = [
            firstElementDensityAsk[0] ?? 0,
            lastElementDensityAsk[0] ?? 0,
            firstElementDensityBid[0] ?? 0,
            lastElementDensityBid[0] ?? 0,
          ];

          const minPriceIndex = Math.min(...index0Values);
          const maxPriceIndex = Math.max(...index0Values);

          densityDetails.push({
            densityBoxStatus,
            densityBoxRate,
            densityDiff,
            densityVolumeStatus,
            priceRange:
              densityBoxStatus == "sell"
                ? {
                    upperPrice: maxPriceIndex,
                    lowerPrice: minPriceIndex,
                  }
                : {
                    upperPrice: minPriceIndex,
                    lowerPrice: maxPriceIndex,
                  },
          });
        }

        const sortedAsksData = [...currentAsks].sort((a, b) => b[1] - a[1]);
        const sortedBidsData = [...currentBids].sort((a, b) => b[1] - a[1]);

        const top5AskElements = sortedAsksData.slice(0, 5);
        const top5BidElements = sortedBidsData.slice(0, 5);

        exAsks =
          currentAsks.reduce(
            (total, [value0, value1]) => total + value1 * value0,
            0
          ) || 1;

        const densityAsks = currentAsks.length;
        const densityBids = currentBids.length;

        exBids =
          currentBids.reduce(
            (total, [value0, value1]) => total + value1 * value0,
            0
          ) || 1;

        exFivePercentAsks =
          currentFiveAsks.reduce(
            (total, [price, volume]) => total + volume * price,
            0
          ) || 1;
        exFivePercentBids =
          currentFiveBids.reduce(
            (total, [price, volume]) => total + volume * price,
            0
          ) || 1;

        const rate = exAsks >= exBids ? exAsks / exBids : exBids / exAsks;
        const difference = exAsks >= exBids ? exAsks - exBids : exBids - exAsks;

        const maxElement = Math.max(...currentAsks.map((item) => item[0]));
        const minElement = Math.max(...currentBids.map((item) => item[0]));

        const sale = exAsks >= exBids ? "sell" : "buy";

        var BigFConditionIn = false;
        var BigFConditionOut = false;

        if (orderIndex == 0) {
          let maxAskIndex = -1;
          let maxAskValue = -Infinity;

          for (let i = 0; i < currentAsks.length; i++) {
            if (currentAsks[i][0] * currentAsks[i][1] > maxAskValue) {
              maxAskValue = currentAsks[i][0] * currentAsks[i][1];
              maxAskIndex = i;
            }
          }

          var conditionAskPassed = false;
          if (maxAskIndex !== -1) {
            // Check if 4.5 conditions are true
            for (let i = 0; i < currentAsks.length; i++) {
              if (
                i !== maxAskIndex &&
                maxAskValue / (currentAsks[i][0] * currentAsks[i][1]) >= 4.5
              ) {
                conditionAskPassed = true;
                break;
              }
            }
          }

          let maxBidIndex = -1;
          let maxBidValue = -Infinity;
          for (let i = 0; i < currentBids.length; i++) {
            if (currentBids[i][0] * currentBids[i][1] > maxBidValue) {
              maxBidValue = currentBids[i][0] * currentBids[i][1];
              maxBidIndex = i;
            }
          }

          var conditionBidPassed = false;
          if (maxBidIndex !== -1) {
            // Check if 4.5 conditions are true
            for (let i = 0; i < currentBids.length; i++) {
              if (
                i !== maxBidIndex &&
                maxBidValue / (currentBids[i][0] * currentBids[i][1]) >= 4.5
              ) {
                conditionBidPassed = true;
                break;
              }
            }
          }

          if (sale == "buy") {
            if (conditionBidPassed) {
              BigFConditionIn = maxBidValue / maxAskValue >= 2 ? true : false;
            }
            if (conditionAskPassed) {
              BigFConditionOut = maxAskValue / maxBidValue >= 2 ? true : false;
            }
          }
          if (sale == "sell") {
            if (conditionAskPassed) {
              BigFConditionIn = maxAskValue / maxBidValue >= 2 ? true : false;
            }
            if (conditionBidPassed) {
              BigFConditionOut = maxBidValue / maxAskValue >= 2 ? true : false;
            }
          }
        }

        const biggestOrder =
          sale === "buy" ? top5BidElements[0] : top5AskElements[0];

        const data = {
          bigF: { BigFConditionIn, BigFConditionOut },
          topElements: { top5AskElements, top5BidElements },
          sumAsksAndBids: { exAsks, exBids },
          minAndMaxElement: { minElement, maxElement },
          rate,
          difference,
          saleStatus: sale,
          volumeCount: biggestOrder[1],
          volumePrice: biggestOrder[0],
          densityDetails,
        };

        boxData.push({
          bigF: { BigFConditionIn, BigFConditionOut },
          orderIndex,
          sale,
          rate,
          difference,
          exAsks,
          exBids,
          densityAsks,
          densityBids,
          volumeCount: biggestOrder[1],
          volumePrice: biggestOrder[0],
          exFivePercentAsks,
          exFivePercentBids,
          densityDetails,
        });

        calculateBox.push(data);
      }
    }
    return { exAsks, exBids };
  }

  static calculateFifteenBox(
    boxAsks,
    boxBids,
    exAsks,
    exBids,
    boxData,
    symbol,
    spotPrice,
    calculateBox
  ) {
    for (let orderIndex = 0; orderIndex < boxAsks.length; orderIndex++) {
      const currentAsks = boxAsks[orderIndex];
      const currentBids = boxBids[orderIndex];

      if (currentAsks.length > 0) {
        const sortedAsksData = [...currentAsks].sort((a, b) => b[1] - a[1]);
        const sortedBidsData = [...currentBids].sort((a, b) => b[1] - a[1]);

        const top5AskElements = sortedAsksData.slice(0, 5);
        const top5BidElements = sortedBidsData.slice(0, 5);

        exAsks =
          currentAsks.reduce(
            (total, [value0, value1]) => total + value1 * value0,
            0
          ) || 1;

        exBids =
          currentBids.reduce(
            (total, [value0, value1]) => total + value1 * value0,
            0
          ) || 1;

        const rate = exAsks >= exBids ? exAsks / exBids : exBids / exAsks;

        const maxElement = Math.max(...currentAsks.map((item) => item[0]));
        const minElement = Math.max(...currentBids.map((item) => item[0]));

        const sale = exAsks >= exBids ? "sell" : "buy";
        const biggestOrder =
          sale === "buy" ? top5BidElements[0] : top5AskElements[0];

        const data = {
          topElements: { top5AskElements, top5BidElements },
          sumAsksAndBids: { exAsks, exBids },
          minAndMaxElement: { minElement, maxElement },
          rate,
          saleStatus: sale,
          volumeCount: biggestOrder[1],
          volumePrice: biggestOrder[0],
        };

        boxData.push({
          orderIndex,
          sale,
          rate,
          exAsks,
          exBids,
          volumeCount: biggestOrder[1],
          volumePrice: biggestOrder[0],
        });

        console.log(
          `===== ABOVE ${exAsks.toFixed(2)} AND BELOW ${exBids.toFixed(
            2
          )} FOR ${symbol} PRICE ${spotPrice} RATE ${rate.toFixed(
            2
          )} STATUS ${sale} BIGGEST ORDER PRICE ${biggestOrder[0]} VOLUME ${
            biggestOrder[1]
          } IN BOX${orderIndex} =====`
        );

        calculateBox.push(data);
      }
    }
    return { exAsks, exBids };
  }
}

module.exports = OrderbookHelpers;
