import express from "express";
import http from "http";
import socketIO from "socket.io";
import fs from "fs";
import SocketHandler from "./app/Socket/SocketHandler";
import SocketAuthorizationMiddleware from "./app/Socket/Middlewares/SocketAuthorizationMiddleware";

const options = {
  key: fs.readFileSync(process.env.SSLCERTPATH),
  cert: fs.readFileSync(process.env.SSLKEYPATH),
};

class SocketServer {
  constructor() {
    this.port = process.env.WS_PORT || 3014;
    this.app = express();
    this.httpServer = http.Server(this.app);
    this.io = socketIO(this.httpServer);

    // this.setupMiddlewares();
    this.setupSocketEvents();
  }

  // Setup Middlewares
  setupMiddlewares = () => {
    // Check User Authentication
    SocketAuthorizationMiddleware.authenticate(this.io);
  };

  // Run and Setup Socket Events
  setupSocketEvents() {

    // const orderNamespace = this.io.of("/all");
    // console.log(Object.keys(io.nsps));
    this.io.on("connection", (socket) => {
      // Check User Authentication
      // SocketAuthorizationMiddleware.authorize(socket, this.io);
      // Socket Handler
      new SocketHandler(socket, this.io);

      // Disconnect Socket
      socket.on("disconnect", () => {
        // Remove Client When Disconnected
        // SocketAuthorizationMiddleware.removeClient(socket, this.io);
      });
    });

    // Run Socket Server
    this.httpServer.listen(this.port, () => {
      console.log(`Socket.IO server running at ${this.port}`);
    });
  }
}

module.exports = SocketServer;
