const axios = require('axios');

class CoinmarketcapService {
    static async getLatestMarketPairs(symbol) {

        var config = {
            method: 'get',
            url: `https://api.coinmarketcap.com/data-api/v3/cryptocurrency/market-pairs/latest?slug=${symbol}&start=1&category=spot&centerType=all&sort=volume_24h_strict&direction=desc`,
            headers: {
                "accept": "application/json, text/plain, */*",
                "accept-language": "en-US,en;q=0.9,fa;q=0.8,ar;q=0.7",
                "cache-control": "no-cache",
                "platform": "web",
                "sec-ch-ua": "\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Google Chrome\";v=\"114\"",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "x-request-id": "997c0e56219940ec88eb911a1d344efd",
                "Referer": "https://coinmarketcap.com/",
                "Referrer-Policy": "origin-when-cross-origin"
            }
        };

        var data = null;

        await axios(config)
            .then(function (response) {
                data = response.data;
            })
            .catch(function (error) {
                console.log(error);
            });
        return data;
    }
}

module.exports = CoinmarketcapService;