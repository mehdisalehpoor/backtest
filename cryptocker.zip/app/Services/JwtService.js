import jwt from "jsonwebtoken";
import { password } from "../../config/configs";
import Handler from "../Exceptions/handler";
import { ErrorCode } from "../Exceptions/errorCode";
class JwtService {
  static create(userId) {
    const newJwt = jwt.sign(
      {
        id: userId,
      },
      password.secret_key,
      {
        expiresIn: "8640h",
      }
    );

    return newJwt;
  }

  static verify(token) {
    try {
      return jwt.verify(token, password.secret_key);
    } catch (error) {
      throw new Handler(ErrorCode.INVALID_JWT);
    }
  }
}

export default JwtService;
