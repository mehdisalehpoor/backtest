const dotenv = require("dotenv");
const { I18n } = require("i18n");
const path = require("path");
const crypto = require("crypto");

dotenv.config();

const i18n = new I18n({
  locales: ["en", "fa"],
  defaultLocale: process.env.DEFAULT_LANGUAGE,
  directory: path.join(__dirname, "../resources/lang"),
});

// You may use this as a boolean value for different situations
const env = {
  development: process.env.NODE_ENV === "development",
  test: process.env.NODE_ENV === "test",
  staging: process.env.NODE_ENV === "staging",
  production: process.env.NODE_ENV === "production",
};

const encrypt = {
  algorithm: process.env.ALGORITH,
  key: crypto.randomBytes(32),
  iv: crypto.randomBytes(16),
};

const database = {
  database_name: process.env.DATABASE_NAME,
  database_username: process.env.DATABASE_USERNAME,
  database_password: process.env.DATABASE_PASSWORD,
  database_host: process.env.DATABASE_HOST,
  database_port: process.env.DATABASE_PORT,
  database_url: process.env.DATABASE_URL,
};

const password = {
  secret_key: process.env.JWT_SECRET_KEY,
};

const smsir = {
  api_key: process.env.SMSIR_KEY,
};

const telegram = {
  futures_signal: process.env.TELEGRAM_FUTURES_BOT_TOKEN,
  futures_signal_logs: process.env.TELEGRAM_FUTURES_LOGS_BOT_TOKEN,
  spot_logs: process.env.TELEGRAM_BOT_TOKEN,
};

const apiKey = {
  api_key: process.env.BINANCE_API_KEY,
  api_secret: process.env.BINANCE_API_SECRET_KEY,
  userId: process.env.USER_ID,
  mexc_api_key: process.env.MEXC_ACCESS_KEY,
  mexc_secret_key: process.env.MEXC_SECRET_KEY,
  bingx_api_key: process.env.BINGX_API_KEY,
  bingx_key_secret: process.env.BINGX_SECRET_KEY,
  bitforex_api_key: process.env.BITFOREX_API_KEY,
  bitforex_secret_key: process.env.BITFOREX_SECRECT_KEY
};

module.exports = {
  i18n,
  env,
  encrypt,
  database,
  password,
  smsir,
  telegram,
  apiKey,
};
