const calculateTotalValue = require("./calculateTotalValue");

const calculateTotalValues = (asks, bids) => {
  const totalAskValue = calculateTotalValue(asks);
  const totalBidValue = calculateTotalValue(bids);
  return { totalAskValue, totalBidValue };
};

module.exports = calculateTotalValues;
