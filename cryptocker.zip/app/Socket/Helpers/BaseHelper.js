class BaseHelper {
  static sendError(conn, message, statusCode, disconnect = false) {
    if (conn) {
      conn.send(
        ParserHelper.encode({
          event: "error",
          status: statusCode,
          data: {
            message: [message],
          },
        })
      );
      if (disconnect) conn.close();
      return false;
    } else {
      return {
        event: "error",
        status: statusCode,
        data: {
          message: [message],
        },
      };
    }
  }
}

export default BaseHelper;
