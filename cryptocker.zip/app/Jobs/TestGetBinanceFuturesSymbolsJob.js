const TelegramBotService = require("../Services/TelegramBotService");
const ExchangeModel = require("../Models/ExchangeModel");
const SymbolExchangeModel = require("../Models/SymbolExchangeModel");
const CoinmarketcapHelpers = require("../Helpers/CoinmarketcapHelpers");
const BinanceService = require("../Services/BinanceService");
const SymbolModel = require("../Models/SymbolModel");

export const runTestJobToGetBinanceFuturesSymbols = async () => {
  try {
    // Create a request to get all futures symbols
    const [coinmarketcapResponse] = await Promise.all([
      // BinanceService.getFuturesSymbols(),
      CoinmarketcapHelpers.coinmarketcapSymbolsList(),
    ]);

    // if (binanceResponse.status !== 200) {
    //   console.error("Failed to fetch futures symbols");
    //   return;
    // }

    // const tradingSymbols = binanceResponse.data.symbols.filter(
    //   (symbolInfo) => symbolInfo.status == "TRADING"
    // );

    // const binanceSymbols = tradingSymbols.map(
    //   (symbolInfo) => symbolInfo.symbol
    // );

    // const usdtSymbols = binanceSymbols.filter((symbol) =>
    //   symbol.endsWith("USDT")
    // );

    const coinmarketcapSymbols = coinmarketcapResponse.data.data;
    var data = null;
    // await SymbolModel.truncate();
    // await SymbolExchangeModel.truncate();
    const usdtSymbols = [
      { id: 21700, symbol: "SRBP" },
      { id: 28039, symbol: "AIMX" },
      { id: 10929, symbol: "ZPAY" },
      { id: 23362, symbol: "HIVALHALLA" },
      { id: 27223, symbol: "MMM" },
      { id: 6607, symbol: "MXT" },
      { id: 27634, symbol: "MM" },
      { id: 21741, symbol: "MC" },
      // { id: , symbol: "KPOL" },
      { id: 7677, symbol: "REAP" },
      { id: 10404, symbol: "ITGR" },
      { id: 11278, symbol: "TXA" },
      { id: 21610, symbol: "TKB" },
      // { id: , symbol: "AOS" },
      { id: 19460, symbol: "SPUME" },
      { id: 11240, symbol: "HI" },
      { id: 10929, symbol: "ZPAY" },
      { id: 6607, symbol: "MXT" },
      { id: 24899, symbol: "SALD" },
      { id: 24063, symbol: "LSD" },
      { id: 9119, symbol: "TLM" },
      { id: 24841, symbol: "OCTAVUS" },
      { id: 11289, symbol: "SPELL" },
      { id: 1684, symbol: "QTUM" },
      { id: 24350, symbol: "SHOOTER" },
      { id: 22461, symbol: "HFT" },
      { id: 3945, symbol: "ONE" },
      { id: 23635, symbol: "BNX" },
    ];
    for (const symbol of usdtSymbols) {
      try {
        await new Promise((resolve) => setTimeout(resolve, 1500));

        const findSymbol = await SymbolModel.findOne({
          where: {
            symbol: symbol.symbol,
          },
        });

        const cmcSymbol = coinmarketcapSymbols.find(
          (cmcSymbol) => cmcSymbol.id === symbol.id
        );

        console.log(symbol.id, cmcSymbol);

        const { sumExistsExchangesVolume, filteredExistsExchanges } =
          await CoinmarketcapHelpers.coinmarketcapCalculate(cmcSymbol.slug);
        data = filteredExistsExchanges;

        if (findSymbol) {
          SymbolModel.update(
            {
              exchangeVolume: parseFloat(sumExistsExchangesVolume.toFixed(0)),
            },
            { where: { id: findSymbol.id } }
          );

          if (parseFloat(sumExistsExchangesVolume.toFixed(0)) >= 80) {
            for (const exchange of filteredExistsExchanges) {
              const exchangeData = await ExchangeModel.findOne({
                where: { exchangeId: exchange.exchangeId },
              });

              const findSymbolExchange = await SymbolExchangeModel.findOne({
                where: {
                  exchangeId: exchangeData.id,
                  symbolId: findSymbol.id,
                },
              });
              if (!findSymbolExchange) {
                SymbolExchangeModel.create({
                  exchangeId: exchangeData.id,
                  symbolId: findSymbol.id,
                });
              }
            }
          }
        } else {
          if (cmcSymbol) {
            const symbolCreated = await SymbolModel.create({
              symbol: symbol.symbol,
              name: cmcSymbol.slug,
              futures: false,
              spot: true,
              exchangeVolume: parseFloat(sumExistsExchangesVolume.toFixed(0)),
            });
            if (parseFloat(sumExistsExchangesVolume.toFixed(0)) >= 80) {
              for (const exchange of filteredExistsExchanges) {
                const exchangeData = await ExchangeModel.findOne({
                  where: { exchangeId: exchange.exchangeId },
                });
                SymbolExchangeModel.create({
                  exchangeId: exchangeData.id,
                  symbolId: symbolCreated.id,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error(error);
        var message = symbol + error;
        TelegramBotService.futuresSignalSend(message);
      }
    }

    return data;
  } catch (error) {
    console.error(error);
    var message = symbol + error;
    TelegramBotService.futuresSignalSend(message);
  }
};
