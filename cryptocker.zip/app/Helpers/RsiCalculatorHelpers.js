const axios = require("axios");
const ta = require("ta-lib");

class RsiCalculator {
  constructor() {
    this.binanceApiBaseUrl = "https://api.binance.com/api/v1/klines";
  }

  async fetchHistoricalData(symbol, interval) {
    const params = {
      symbol: symbol,
      interval: interval,
      limit: 1000,
    };

    try {
      const response = await axios.get(this.binanceApiBaseUrl, { params });
      return response.data;
    } catch (error) {
      throw new Error(
        "Error fetching historical data from Binance API: " + error.message
      );
    }
  }

  calculateRSI(data) {
    const closePrices = data.map((entry) => parseFloat(entry[4]));

    const gains = [];
    const losses = [];

    for (let i = 1; i < closePrices.length; i++) {
      const priceDiff = closePrices[i] - closePrices[i - 1];
      if (priceDiff > 0) {
        gains.push(priceDiff);
        losses.push(0);
      } else {
        gains.push(0);
        losses.push(Math.abs(priceDiff));
      }
    }

    const avgGain = gains.reduce((sum, value) => sum + value, 0) / 14;
    const avgLoss = losses.reduce((sum, value) => sum + value, 0) / 14;

    const rs = avgGain / avgLoss;
    const rsi = 100 - (100 / (1 + rs));
    
    return rsi;
  }

  async getRSI(tradingPair, timeframe) {
    try {
      const historicalData = await this.fetchHistoricalData(
        tradingPair,
        timeframe
      );
      const rsiValues = this.calculateRSI(historicalData);
      return rsiValues;
    } catch (error) {
      throw new Error("Error calculating RSI: " + error.message);
    }
  }
}

module.exports = RsiCalculator;
