import ccxt from "ccxt";
class OrderBookService {
  static async hanlde(symbol) {
    const exchanges = await ExchangeModel.findAll();

    const orderBooks = {};

    for (const exchangeData of exchanges) {
      var limit = 5000;
      try {
        const exchange = new ccxt[exchangeData.name]();

        if (exchangeData.name === "kucoin") limit = 100;
        if (
          exchangeData.name === "coinex" ||
          exchangeData.name === "huobi" ||
          exchangeData.name === "bitmart" ||
          exchangeData.name === "wavesexchange"
        ) {
          // CoinEx uses fetchL2OrderBook method for fetching order books
          const orderBook = await exchange.fetchL2OrderBook(symbol);
          orderBooks[exchangeData.name] = orderBook;
        } else {
          const orderBook = await exchange.fetchOrderBook(symbol, limit);
          orderBooks[exchangeData.name] = orderBook;
        }
      } catch (error) {
        console.log(
          `Failed to fetch order book from ${exchangeData.name}: ${error.message}`
        );
      }
    }
    return orderBooks;
  }
}

export default OrderBookService;
