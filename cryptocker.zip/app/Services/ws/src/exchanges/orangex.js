const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toUpperCase() + "-" + quote.toUpperCase();
};

exports.getConfig = async (symbol) => {
  return {
    exchange: "orangex",
    symbol: await fixSymbolName(symbol),
    url: `wss://api.orangex.com/ws/api/v1`,
    getSubscribeMessage: (symbol) => {
      return {
        jsonrpc: "2.0",
        id: 1,
        method: "/public/subscribe",
        params: {
          channels: [`book.${symbol}.raw`],
        },
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      const asks = [];
      const bids = [];

      message?.params?.data?.asks.forEach((item) => {
        if (item[0] === "new") {
          asks.push([item[1], item[2]]);
        }
      });

      message?.params?.data?.bids.forEach((item) => {
        if (item[0] === "new") {
          bids.push([item[1], item[2]]);
        }
      });

      return { asks, bids };
    },
  };
};
