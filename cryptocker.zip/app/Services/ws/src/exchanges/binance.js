const fixSymbolName = async (symbol) => {
  const [base, quote] = symbol.split("/");

  return base.toLowerCase() + quote.toLowerCase();
};

exports.getConfig = async (symbol) => {
  return {
    url: "wss://stream.binance.com:9443/ws",
    symbol: await fixSymbolName(symbol),
    exchange: "binance",
    getSubscribeMessage: (symbol) => {
      return {
        method: "SUBSCRIBE",
        params: [`${symbol}@depth`],
        id: 1,
      };
    },
    parseMessage: (data) => {
      const message = JSON.parse(data);
      return {
        asks: message?.a || [],
        bids: message?.b || [],
      };
    },
  };
};
