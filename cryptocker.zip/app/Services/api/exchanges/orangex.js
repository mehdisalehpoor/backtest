const axios = require("axios");

exports.getConfig = async (baseSymbol, quoteSymbol) => {
    return {
        url: "https://api.orangex.com/api/v1/public/",
        symbol: baseSymbol + "-" + quoteSymbol,
        exchange: "binance",
        getKlines: async (url, symbol, timeframe, startTime, endTime) => {

            let timeframeCandle = "1440";
            if (!timeframe == "1d") {
                let timeframeCandle = "1440";
            }

            const now = new Date();

            now.setHours(0, 0, 0, 0);

            const midnightTimestamp = now.getTime() / 1000;

            const params = {
                instrument_name: symbol,
                resolution: timeframeCandle,
                start_timestamp: midnightTimestamp,
                end_timestamp: now.getTime() / 1000
            };

            if (startTime){
                params.start_timestamp = startTime;
            }
            if (endTime){
                params.end_timestamp = midnightTimestamp;
            }

            console.log(params);
            const response = await axios.get(url + "get_tradingview_chart_data", { params });
            const data = response.data.result;
            
            return data.map(kline => ([
                kline.tick,//timestamp
                kline.open,//open
                kline.high,//high
                kline.low,//low
                kline.close,//close
                kline.volume,//volume
            ]));
        },
    };
};
