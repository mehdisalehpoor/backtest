const CoinmarketcapHelpers = require("../../../Helpers/CoinmarketcapHelpers");
const ExchangeModel = require("../../../Models/ExchangeModel");
const SymbolExchangeModel = require("../../../Models/SymbolExchangeModel");
const SymbolModel = require("../../../Models/SymbolModel");
const BinanceService = require("../../../Services/BinanceService");

class GetBinanceFuturesSymbol {
  static async handle(req, res, next) {
    const symbol = req.body.symbol ?? null;
    try {
      // Create a request to get all futures symbols
      const [binanceResponse, coinmarketcapResponse] = await Promise.all([
        BinanceService.getFuturesSymbols(),
        CoinmarketcapHelpers.coinmarketcapSymbolsList(),
      ]);

      if (binanceResponse.status !== 200) {
        console.error("Failed to fetch futures symbols");
        return;
      }

      const tradingSymbols = binanceResponse.data.symbols.filter(
        (symbolInfo) => symbolInfo.status == "TRADING"
      );

      const binanceSymbols = tradingSymbols.map(
        (symbolInfo) => symbolInfo.symbol
      );

      if (symbol) {
        var usdtSymbols = binanceSymbols.filter(
          (symbolName) => symbolName == `${symbol}USDT`
        );
      } else {
        var usdtSymbols = binanceSymbols.filter((symbol) =>
          symbol.endsWith("USDT")
        );
      }

      const coinmarketcapSymbols = coinmarketcapResponse.data.data;

      for (const symbol of usdtSymbols) {
        try {
          console.log(symbol);
          const symbolWithoutUsdt = symbol.replace("USDT", "");

          const cmcSymbol = coinmarketcapSymbols.find(
            (cmcSymbol) => cmcSymbol.symbol === symbolWithoutUsdt
          );

          if (cmcSymbol) {
            const { sumExistsExchangesVolume, filteredExistsExchanges } =
              await CoinmarketcapHelpers.coinmarketcapCalculate(cmcSymbol.slug);

            const [symbolCreated, created] = await SymbolModel.upsert({
              symbol: symbolWithoutUsdt, // Condition for finding the existing record
              name: cmcSymbol.slug,
              futures: true,
              spot: false,
              exchangeVolume: parseFloat(sumExistsExchangesVolume.toFixed(0)),
            });

            if (parseFloat(sumExistsExchangesVolume.toFixed(0)) >= 80) {
              for (const exchange of filteredExistsExchanges) {
                const exchangeData = await ExchangeModel.findOne({
                  where: { exchangeId: exchange.exchangeId },
                });

                const [symbolExchangeCreated, created] =
                  await SymbolExchangeModel.findOrCreate({
                    where: {
                      exchangeId: exchangeData.id,
                      symbolId: symbolCreated.id,
                    },
                    defaults: {
                      exchangeId: exchangeData.id,
                      symbolId: symbolCreated.id,
                    },
                  });
              }
            }
          }
        } catch (error) {
          console.error(symbol + " " + error);
        }
      }

      res.send("DONE");
    } catch (error) {
      console.error(error);
      var message = symbol + error;
    }
  }
}

module.exports = GetBinanceFuturesSymbol;
